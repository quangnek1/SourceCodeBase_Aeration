import { Toaster } from "@/components/ui/sonner"

import { RouterProvider } from "react-router-dom";
import { router } from "./routes/router";


export default function App() {
  return (
    <>
      <RouterProvider router={router} />
      <Toaster position="top-right" />
    </>
  );
}

