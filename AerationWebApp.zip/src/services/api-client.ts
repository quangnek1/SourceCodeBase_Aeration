import axios from "axios"

// Base URL settings
const DEFAULT_API_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api/v1"

export const getApiUrl = () => localStorage.getItem("api_url") || DEFAULT_API_URL

export const setApiUrl = (url: string) => {
  localStorage.setItem("api_url", url)
}

// Global API client instance
export const apiClient = axios.create({
  get baseURL() {
    return getApiUrl()
  },
  timeout: 5000,
  headers: {
    "Content-Type": "application/json",
  },
})

// Check api availability status
export const checkApiConnection = async (): Promise<boolean> => {
  try {
    await axios.get(`${getApiUrl()}/Products`, { timeout: 1000 })
    return true
  } catch {
    return false
  }
}
