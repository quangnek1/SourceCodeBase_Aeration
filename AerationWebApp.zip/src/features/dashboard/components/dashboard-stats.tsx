import { Skeleton } from "@/components/ui/skeleton";
import type { RemixiconComponentType } from "@remixicon/react";

export interface StatItem {
  label: string;
  value: string;
  desc: string;
  type: string;
  icon: RemixiconComponentType;
}

interface DashboardStatsProps {
  stats: StatItem[];
  isLoading: boolean;
}

export function DashboardStats({ stats, isLoading }: DashboardStatsProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat, i) => {
        const Icon = stat.icon;
        return (
          <div key={i} className="rounded-xl border border-border bg-card p-5 shadow-xs transition-all duration-200 hover:shadow-md dark:bg-slate-900/50">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{stat.label}</span>
              <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                stat.type === "primary" ? "bg-primary/10 text-primary dark:bg-primary/20" :
                stat.type === "sky" ? "bg-sky-500/10 text-sky-600 dark:text-sky-400 dark:bg-sky-500/20" :
                stat.type === "emerald" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 dark:bg-emerald-500/20" :
                "bg-green-500/10 text-green-600 dark:text-green-400 dark:bg-green-500/20"
              }`}>
                <Icon className="h-5 w-5" />
              </div>
            </div>
            <div className="mt-4 flex items-baseline gap-2">
              {isLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : (
                <span className="text-3xl font-black tracking-tight text-foreground">{stat.value}</span>
              )}
            </div>
            <div className="mt-2 flex items-center gap-1">
               {isLoading ? (
                <Skeleton className="h-4 w-32" />
               ) : (
                <p className="text-xs font-medium text-muted-foreground">{stat.desc}</p>
               )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
