import { useBatches } from "../../batches/hooks/useBatches"
import { useAerationMonitorData } from "../../aeration-monitor/hooks/useAerationMonitorData"
import { usePlans } from "../../plans/hooks/usePlans"
import {
  RiStackLine,
  RiDashboard3Line,
  RiCheckboxCircleLine,
  RiAlertLine
} from "@remixicon/react"
import { DashboardStats, type StatItem } from "./dashboard-stats"
import { RecentBatches } from "./recent-batches"
import { AerationSummary } from "./aeration-summary"

export function DashboardView() {
  // 1. Fetch Batches (get recent ones)
  const { data: batchesData, isLoading: isBatchesLoading } = useBatches(1, 10);
  const batches = batchesData?.items || [];
  
  // 2. Fetch Aeration Monitor Data
  const { data: columns, isLoading: isColumnsLoading } = useAerationMonitorData();
  
  // 3. Fetch Plans Data
  const { data: ptcaPlans, isLoading: isPtcaLoading } = usePlans("ptca");
  const { data: cagPlans, isLoading: isCagLoading } = usePlans("cag");

  const isLoading = isBatchesLoading || isColumnsLoading || isPtcaLoading || isCagLoading;

  // --- Calculate Statistics ---
  
  // Aeration Slots Stats
  let totalSlots = 0;
  let emptySlots = 0;
  let aeratingSlots = 0;

  columns?.forEach(col => {
    col.aerationPositionDtos?.forEach(slot => {
      totalSlots++;
      const itemsCount = slot.batchInAerationPositionDataDtos?.length || 0;
      if (itemsCount === 0) {
        emptySlots++;
      } else {
        aeratingSlots++;
      }
    });
  });

  // Plans Stats
  const totalPtca = ptcaPlans?.length || 0;
  const totalCag = cagPlans?.length || 0;
  const totalPlans = totalPtca + totalCag;

  // Batches Stats
  const activeBatchesCount = batchesData?.totalCount || 0;

  const stats: StatItem[] = [
    { 
      label: "Batches tổng cộng", 
      value: `${activeBatchesCount} lô`, 
      desc: "Total lô đang quản lý", 
      type: "primary", 
      icon: RiStackLine 
    },
    { 
      label: "Vị trí sục khí trống", 
      value: `${emptySlots} / ${totalSlots}`, 
      desc: `Đang sục khí: ${aeratingSlots} positions`, 
      type: "sky", 
      icon: RiDashboard3Line 
    },
    { 
      label: "Kế hoạch cần xử lý", 
      value: `${totalPlans}`, 
      desc: `PTCA: ${totalPtca} | CAG: ${totalCag}`, 
      type: "emerald", 
      icon: RiCheckboxCircleLine 
    },
    { 
      label: "Status hệ thống", 
      value: "Bình thường", 
      desc: "Tất cả kết nối ổn định", 
      type: "success", 
      icon: RiAlertLine 
    },
  ]

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Title */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Xin chào, Admin!</h1>
        <p className="text-sm text-muted-foreground">Dưới đây là thông số vận hành thời gian thực của hệ thống Aeration & Khử trùng.</p>
      </div>

      {/* Stats Grid */}
      <DashboardStats stats={stats} isLoading={isLoading} />

      {/* Main Sections */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column: Recent Batches */}
        <RecentBatches batches={batches} isLoading={isLoading} />

        {/* Right Column: Aeration Status Summary */}
        <AerationSummary columns={columns} isLoading={isLoading} />
      </div>
    </div>
  )
}
