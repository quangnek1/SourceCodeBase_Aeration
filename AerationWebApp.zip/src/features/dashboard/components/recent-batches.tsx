import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { RiArrowRightUpLine } from "@remixicon/react";
import { useNavigate } from "react-router-dom";
import { PLAN_STATUS_COLORS, PLAN_STATUS_TRANSLATIONS, DEFAULT_STATUS_COLOR } from "../../plans/types/plans.types";
import type { Batch } from "../../batches/types/batches.types";

interface RecentBatchesProps {
  batches: Batch[];
  isLoading: boolean;
}

export function RecentBatches({ batches, isLoading }: RecentBatchesProps) {
  const navigate = useNavigate();

  return (
    <div className="rounded-xl border border-border bg-card shadow-sm lg:col-span-2 overflow-hidden flex flex-col dark:bg-slate-900/40">
      <div className="flex items-center justify-between border-b border-border p-5 bg-muted/10">
        <h3 className="font-bold text-foreground">Recent Processing Batches</h3>
        <Button size="sm" variant="outline" className="h-8 gap-1 dark:border-slate-700" onClick={() => navigate("/batches")}>
          Xem tất cả lô hàng <RiArrowRightUpLine className="h-3.5 w-3.5" />
        </Button>
      </div>
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="bg-muted/30 border-b border-border text-xs text-muted-foreground">
              <th className="px-5 py-3 font-semibold uppercase tracking-wider">Batch No</th>
              <th className="px-5 py-3 font-semibold uppercase tracking-wider">Created Date</th>
              <th className="px-5 py-3 font-semibold uppercase tracking-wider">Vị trí</th>
              <th className="px-5 py-3 font-semibold uppercase tracking-wider text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {isLoading ? (
              Array.from({ length: 5 }).map((_, idx) => (
                <tr key={idx} className="hover:bg-muted/20 transition-colors">
                  <td className="px-5 py-4"><Skeleton className="h-4 w-32" /></td>
                  <td className="px-5 py-4"><Skeleton className="h-4 w-24" /></td>
                  <td className="px-5 py-4"><Skeleton className="h-4 w-16" /></td>
                  <td className="px-5 py-4 flex justify-end"><Skeleton className="h-5 w-24 rounded-full" /></td>
                </tr>
              ))
            ) : batches.length > 0 ? (
              batches.slice(0, 7).map((batch) => {
                const statusDesc = batch.status || "";
                const colorConfig = PLAN_STATUS_COLORS[statusDesc] || DEFAULT_STATUS_COLOR;
                const translatedDesc = PLAN_STATUS_TRANSLATIONS[statusDesc] || statusDesc || "Kế hoạch";

                return (
                  <tr key={batch.id} className="hover:bg-muted/40 transition-colors">
                    <td className="px-5 py-4 font-bold text-foreground">{batch.batchNo}</td>
                    <td className="px-5 py-4 text-muted-foreground font-medium">{batch.createdDate}</td>
                    <td className="px-5 py-4 font-mono text-xs">
                      {batch.batchInAerationPositionDtos?.map(p => p.aerationPosition.positionCode).join(", ")}
                    </td>
                    <td className="px-5 py-4 text-right">
                      <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-bold tracking-wide border shadow-sm ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${colorConfig.dot}`} />
                        {translatedDesc}
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={4} className="px-5 py-8 text-center text-muted-foreground text-sm font-medium">
                  Không có lô hàng nào gần đây.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
