import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { RiDashboard3Line } from "@remixicon/react";
import { useNavigate } from "react-router-dom";
import type { MonitorAerationColumnDto } from "../../aeration-monitor/types/aeration-monitor.types";

interface AerationSummaryProps {
  columns?: MonitorAerationColumnDto[];
  isLoading: boolean;
}

export function AerationSummary({ columns, isLoading }: AerationSummaryProps) {
  const navigate = useNavigate();

  return (
    <div className="rounded-xl border border-border bg-card shadow-sm flex flex-col dark:bg-slate-900/40">
      <div className="flex items-center justify-between border-b border-border p-5 bg-muted/10">
        <h3 className="font-bold text-foreground">Status Room sục khí</h3>
        <span className="text-[10px] bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300 px-2 py-0.5 rounded font-black uppercase tracking-wider">
          {columns?.length || 0} Column
        </span>
      </div>

      <div className="p-4 flex-1 overflow-y-auto max-h-[400px] space-y-3 custom-scrollbar">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="flex items-center gap-3 p-3 rounded-xl border border-border/40">
              <Skeleton className="h-10 w-10 rounded-lg shrink-0" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-3 w-32" />
              </div>
            </div>
          ))
        ) : columns && columns.length > 0 ? (
          columns.map((col, idx) => {
            const slots = col.aerationPositionDtos || [];
            const used = slots.filter(s => (s.batchInAerationPositionDataDtos?.length || 0) > 0).length;
            const total = slots.length;
            const isFull = used === total && total > 0;
            const isEmpty = used === 0;

            return (
              <div key={idx} className="flex items-center justify-between p-3 rounded-xl border border-border/60 hover:border-border hover:shadow-sm transition-all bg-white dark:bg-slate-950">
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">Column {col.columnName}</p>
                  <p className="text-[11px] text-muted-foreground font-semibold">Capacity: {total} positions</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-[9px] px-2 py-1 rounded font-black uppercase tracking-wider ${isFull ? "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-400" :
                      isEmpty ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400" :
                        "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400"
                    }`}>
                    {isFull ? "Full" : isEmpty ? "Completely Empty" : `In Use ${used}/${total}`}
                  </span>
                </div>
              </div>
            );
          })
        ) : (
          <div className="flex flex-col items-center justify-center py-10 text-muted-foreground text-sm gap-3">
            <div className="p-3 bg-muted rounded-full">
              <RiDashboard3Line className="w-6 h-6 opacity-40" />
            </div>
            <span className="font-medium">No aeration room data available</span>
          </div>
        )}
      </div>
      <div className="p-3 border-t border-border bg-muted/5">
        <Button variant="ghost" className="w-full text-sm font-semibold text-primary hover:bg-primary/10" onClick={() => navigate("/aerationroom")}>
          Open Visual Map
        </Button>
      </div>
    </div>
  );
}
