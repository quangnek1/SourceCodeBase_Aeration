import { axiosInstance } from "@/lib/axios";
import type { AuthResponse, AuthUser, LoginRequest, RegisterRequest } from "../types/auth.types";

export const authApi = {
    // Login endpoint: POST http://localhost:5000/api/v1/auth/login
    login: async (request: LoginRequest): Promise<AuthResponse> => {
        const res = await axiosInstance.post<AuthResponse>("/auth/login", request);
        return res.data;
    },

    // POST http://localhost:5000/api/v1/auth/register
    register: async (request: RegisterRequest): Promise<AuthResponse> => {
        const res = await axiosInstance.post<AuthResponse>("/auth/register", request);
        return res.data
    },

    // Refresh token endpoint: POST http://localhost:5000/api/v1/auth/refresh-token
    refresh: async (): Promise<AuthResponse> => {
        const res = await axiosInstance.post<AuthResponse>("/auth/refresh-token");
        return res.data;
    },

    logout: async (): Promise<void> => {
        await axiosInstance.post('/auth/logout')
    },

    getCurrentUser: async (): Promise<AuthUser> => {
        const res = await axiosInstance.get<AuthUser>("/auth/me")
        return res.data;
    },
};

