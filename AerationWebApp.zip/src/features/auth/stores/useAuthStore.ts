import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";
import type { AuthUser } from "../types/auth.types";

interface AuthState {
    // State
    user: AuthUser | null;
    isAuthenticated: boolean;

    // Actions
    setUser: (user: AuthUser) => void;
    clearUser: () => void;
}

export const useAuthStore = create<AuthState>()(
    devtools(
        persist(
            (set) => ({
                // Initial state
                user: null,
                isAuthenticated: false,

                // Actions
                setUser: (user) =>
                    set({ user, isAuthenticated: true }, false, "auth/setUser"),

                clearUser: () =>
                    set({ user: null, isAuthenticated: false }, false, "auth/clearUser"),
            }),
            {
                name: "auth-storage", // Tên key lưu trong localStorage
            }
        ),
        { name: "AuthStore" }
    )
);

// Selector helpers — tránh re-render không cần thiết
export const selectUser = (state: AuthState) => state.user;
export const selectIsAuthenticated = (state: AuthState) => state.isAuthenticated;