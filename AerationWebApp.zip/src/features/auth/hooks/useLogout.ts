import { useNavigate } from "react-router-dom";
import { toast } from 'sonner'

import { authApi } from "../api/auth.api";
import { useAuthStore } from "../stores/useAuthStore";
import { tokenUtils } from "../utils/token.utils";
import { useState } from "react";

export function useLogout() {
    const navigate = useNavigate();
    const clearUser = useAuthStore((state) => state.clearUser);
    const [isLoading, setIsLoading] = useState(false);

    const logout = async () => {
        console.log("1. logout() được gọi"); // ← Có thấy log này không?
        setIsLoading(true);
        try {
            console.log("2. Trước khi gọi API");
            await authApi.logout(); // Gọi API báo server
            console.log("3. API thành công");
        } catch (err) {
            // Bỏ qua lỗi — vẫn logout client
            console.log("4. Catch:", err);
        } finally {
            // Luôn luôn chạy dù thành công hay thất bại
            console.log("5. Finally chạy");
            clearUser();
            tokenUtils.clear();
            toast.success("Signed out successfully");
            navigate("auth/login");
            setIsLoading(false);
        }
    };

    return { logout, isLoading }
}