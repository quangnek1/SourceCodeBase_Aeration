import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { toast } from 'sonner'

import { authApi } from "../api/auth.api";
import { useAuthStore } from "../stores/useAuthStore";
import { tokenUtils } from "../utils/token.utils";
import type { LoginRequest } from "../types/auth.types";
import { getErrorMessage } from "@/lib/error.utils";

export function useLogin() {
    const navigate = useNavigate();
    const setUser = useAuthStore((state) => state.setUser);

    const { mutate, isPending, isError, error } = useMutation({
        mutationFn: (request: LoginRequest) => authApi.login(request),

        onSuccess: (data) => {
            // 1. Lưu tokens vào localStorage
            tokenUtils.save(data);
            // 2. Lưu user vào global store
            setUser(data.user!);
            // 3. Thông báo thành công
            toast.success(`Welcome back, ${data.user!.fullName}!`);
            // 4. Điều hướng
            navigate("/");
        },

        onError: (err: Error) => {
            // Xử lý lỗi từ backend trả về
            //toast.error(err.message || "Login failed. Please try again.");
            toast.error(getErrorMessage(err));
        },
    });

    return {
        login: mutate,
        isLoading: isPending,
        isError,
        error,
    };
}