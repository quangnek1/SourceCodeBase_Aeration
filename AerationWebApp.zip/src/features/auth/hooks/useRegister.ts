import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { toast } from 'sonner'

import { authApi } from "../api/auth.api";
import { useAuthStore } from "../stores/useAuthStore";
import { tokenUtils } from "../utils/token.utils";
import type { RegisterRequest } from "../types/auth.types";

export function useRegister() {
    const navigate = useNavigate();
    const setUser = useAuthStore((state) => state.setUser);

    const { mutate, isPending } = useMutation({
        mutationFn: (request: RegisterRequest) => authApi.register(request),

        onSuccess: (data) => {
            tokenUtils.save(data);
            setUser(data.user!);
            toast.success("Đăng ký thành công! Chào mừng bạn.");
            navigate("/dashboard");
        },

        onError: (err: Error) => {
            toast.error(err.message || "Đăng ký thất bại. Vui lòng thử lại.");
        },
    });

    return {
        register: mutate,
        isLoading: isPending,
    };
}