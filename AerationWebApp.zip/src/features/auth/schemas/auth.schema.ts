import { z } from 'zod';

export const loginSchema = z.object({
    userName: z.string()
        .min(4, 'Vui lòng nhập username'),
    password: z.string()
        .min(5, 'Password phải có ít nhất 5 ký tự'),
});

// Infer type tự động từ Zod Schema để dùng cho React Hook Form
export type LoginPayload = z.infer<typeof loginSchema>;

export const registerSchema = z.object({
    userName: z.string()
        .min(3, 'Tên đăng nhập phải có ít nhất 3 ký tự')
        .max(50, 'Tên đăng nhập không được vượt quá 50 ký tự')
        .regex(/^[a-zA-Z0-9_]+$/, 'Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới'),

    email: z.string()
        .min(1, 'Vui lòng nhập email')
        .email('Định dạng email không hợp lệ'),

    password: z.string()
        .min(8, 'Password phải có ít nhất 8 ký tự')
        .regex(/[A-Z]/, 'Password phải chứa ít nhất 1 chữ cái viết hoa')
        .regex(/[a-z]/, 'Password phải chứa ít nhất 1 chữ cái viết thường')
        .regex(/[0-9]/, 'Password phải chứa ít nhất 1 số')
        .regex(/[^A-Za-z0-9]/, 'Password phải chứa ít nhất 1 ký tự đặc biệt'),

    confirmPassword: z.string()
        .min(1, 'Vui lòng xác nhận mật khẩu'),

    fullName: z.string()
        .min(2, 'Họ tên phải có ít nhất 2 ký tự')
        .max(100, 'Họ tên không được vượt quá 100 ký tự'),
}).refine((data) => data.password === data.confirmPassword, {
    message: 'Xác nhận mật khẩu không khớp',
    path: ['confirmPassword'],
});

export type LoginFormValues = z.infer<typeof loginSchema>;
export type RegisterFormValues = z.infer<typeof registerSchema>;