import type { AuthResponse } from "../types/auth.types";

const ACCESS_TOKEN_KEY = "access_token";
const REFRESH_TOKEN_KEY = "refresh_token";

// ===== Storage =====
export const tokenUtils = {

    // Lưu tokens vào localStorage
    save(tokens: AuthResponse): void {
        localStorage.setItem(ACCESS_TOKEN_KEY, tokens.accessToken);
        if (tokens.refreshToken) {
            localStorage.setItem(REFRESH_TOKEN_KEY, tokens.refreshToken);
        }
    },

    getAccessToken(): string | null {
        return localStorage.getItem(ACCESS_TOKEN_KEY);
    },

    getRefreshToken(): string | null {
        return localStorage.getItem(REFRESH_TOKEN_KEY);
    },

    clear(): void {
        localStorage.removeItem(ACCESS_TOKEN_KEY);
        localStorage.removeItem(REFRESH_TOKEN_KEY);
    },
};

// ===== JWT Parser =====
interface JwtPayload {
    sub: string;
    email: string;
    role: string;
    exp: number;
    iat: number;
}
    
export function parseJwt(token: string): JwtPayload | null {
    try {
        const base64Payload = token.split(".")[1];
        const decoded = atob(base64Payload);
        return JSON.parse(decoded) as JwtPayload;
    } catch {
        return null;
    }
}

export function isTokenExpired(token: string): boolean {
    const payload = parseJwt(token);
    if (!payload) return true;
    // exp tính bằng giây, Date.now() tính bằng mili giây
    return payload.exp * 1000 < Date.now();
}