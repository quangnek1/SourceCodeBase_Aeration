export interface LoginRequest {
    userName: string
    password: string
}

export interface RegisterRequest {
    userName: string
    email: string
    password: string
    confirmPassword: string
    fullName: string
}

export interface AuthUser {
    id: string
    userName: string
    fullName: string
    email: string
    avatarUrl?: string
    roles: string[]
}

export interface AuthResponse {
    accessToken: string
    refreshToken?: string
    expiresIn: number
    user: AuthUser | null
}

export const UserRole = {
    ADMIN: "ADMIN",
    USER: "USER",
    MODERATOR: "MODERATOR",
} as const;

export type UserRole = typeof UserRole[keyof typeof UserRole];
