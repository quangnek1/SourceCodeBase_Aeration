import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, LogIn } from "lucide-react";

import { loginSchema, type LoginFormValues } from "../schemas/auth.schema";
import { useLogin } from "../hooks/useLogin";

// Shadcn components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/features/auth/components/password-input";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { cn } from "@/lib/utils";

interface LoginFormProps extends React.HTMLAttributes<HTMLFormElement> {
    redirectTo?: string;
}

export function LoginForm({ className, redirectTo, ...props }: LoginFormProps) {
    const { login, isLoading } = useLogin();

    const form = useForm<LoginFormValues>({
        resolver: zodResolver(loginSchema),
        defaultValues: {
            userName: "",
            password: "",
        },
    });

    const onSubmit = (values: LoginFormValues) => {
        login(values);
    };

    return (
        <Form {...form}>
            <form
                onSubmit={form.handleSubmit(onSubmit)}
                className={cn("grid gap-3", className)}
                {...props}
            >
                {/* CodeID Field */}
                <FormField
                    control={form.control}
                    name="userName"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>CodeID</FormLabel>
                            <FormControl>
                                <Input placeholder="CodeID" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                {/* Password Field */}
                <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                        <FormItem className="relative">
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                                <PasswordInput placeholder="********" {...field} />
                            </FormControl>
                            <FormMessage />
                            <a
                                href="/forgot-password"
                                className="absolute end-0 -top-0.5 text-xs font-medium text-muted-foreground hover:opacity-75 hover:underline"
                            >
                                Forgot password?
                            </a>
                        </FormItem>
                    )}
                />

                {/* Submit Button */}
                <Button className="mt-2 cursor-pointer" disabled={isLoading}>
                    {isLoading ? <Loader2 className="animate-spin" /> : <LogIn />}
                    Sign in
                </Button>
            </form>
        </Form>
    );
}