import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from '@/components/ui/card'
import { AuthLayout } from '@/layouts/auth-layout'
import { ForgotPasswordForm } from '@/features/auth/components/forgot-password-form'

export function ForgotPassword() {
    return (
        <AuthLayout>
            <Card className='gap-4'>
                <CardHeader>
                    <CardTitle className='text-lg tracking-tight'>
                        Forgot Password
                    </CardTitle>
                    <CardDescription>
                        Enter your registered email and <br /> we will send you a link to
                        reset your password.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <ForgotPasswordForm />
                </CardContent>
                <CardFooter className="flex flex-col gap-2">
                    <p className='mx-auto text-center text-sm text-balance text-muted-foreground'>
                        Don't have an account?{' '}
                        {/* <Link
                            to='/sign-up'
                            className='underline underline-offset-4 hover:text-primary'
                        >
                            Sign up
                        </Link>
                        . */}
                    </p>
                    <p className='mx-auto text-center text-sm text-balance text-muted-foreground'>
                        {/* <Link
                            to='/sign-in'
                            className='underline underline-offset-4 hover:text-primary font-medium'
                        >
                            Back to Sign In
                        </Link> */}
                    </p>
                </CardFooter>
            </Card>
        </AuthLayout>
    )
}
