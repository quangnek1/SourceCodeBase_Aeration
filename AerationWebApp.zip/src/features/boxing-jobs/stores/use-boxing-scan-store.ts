import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";
import type { ScanBox, ScanBoxingPosition } from "../types/boxing-jobs-types";

interface BoxingScanState {
    // Vị trí đang được chọn để scan box tiếp theo
    selectedPosition: ScanBoxingPosition | null;
    // Thùng đang mở để scan tag tiếp theo
    selectedBox: ScanBox | null;
    // Số lượng thực tế đang có trong thùng (đồng bộ với currentQty từ server)
    scannedTagCount: number;

    setSelectedPosition: (position: ScanBoxingPosition) => void;
    // Đổi vị trí -> thùng đang chọn (thuộc vị trí cũ) không còn hợp lệ nữa
    clearSelectedPosition: () => void;

    // Khởi tạo scannedTagCount từ currentQty trả về, tránh lệch với dữ liệu thực tế trên server
    setSelectedBox: (box: ScanBox) => void;
    clearSelectedBox: () => void;
    incrementScannedTagCount: () => void;
}

export const useBoxingScanStore = create<BoxingScanState>()(
    devtools(
        persist(
            (set) => ({
                selectedPosition: null,
                selectedBox: null,
                scannedTagCount: 0,

                setSelectedPosition: (position) =>
                    set({ selectedPosition: position }, false, "boxingScan/setSelectedPosition"),

                clearSelectedPosition: () =>
                    set(
                        { selectedPosition: null, selectedBox: null, scannedTagCount: 0 },
                        false,
                        "boxingScan/clearSelectedPosition"
                    ),

                setSelectedBox: (box) =>
                    set({ selectedBox: box, scannedTagCount: box.currentQty }, false, "boxingScan/setSelectedBox"),

                clearSelectedBox: () =>
                    set({ selectedBox: null, scannedTagCount: 0 }, false, "boxingScan/clearSelectedBox"),

                incrementScannedTagCount: () =>
                    set((s) => ({ scannedTagCount: s.scannedTagCount + 1 }), false, "boxingScan/incrementScannedTagCount"),
            }),
            {
                // Giữ trạng thái đang scan qua các lần reload trang, tránh lệch với session phía server
                name: "boxing-scan-storage",
            }
        ),
        { name: "BoxingScanStore" }
    )
);


export const selectSelectedPosition = (state: BoxingScanState) => state.selectedPosition;
export const selectSelectedBox = (state: BoxingScanState) => state.selectedBox;

