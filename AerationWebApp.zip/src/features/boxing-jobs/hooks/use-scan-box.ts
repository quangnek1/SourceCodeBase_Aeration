import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import type { ScanBox } from "../types/boxing-jobs-types";
import { boxingScanApi } from "../api/boxing-job.api";

export type ScanBoxState =
    | { status: "idle" }
    | { status: "loading" }
    | { status: "not_found" }
    | { status: "error"; message: string }
    | { status: "found"; box: ScanBox };

export function useScanBox(boxCode: string | null) {
    const query = useQuery({
        queryKey: ["scan-box", boxCode],
        queryFn: async () => {
            const res = await boxingScanApi.postScanBox(boxCode!);
            return res;
        },
        enabled: !!boxCode,
        retry: false,
        staleTime: 0,         // always re-fetch for fresh scan
        gcTime: 0,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    let state: ScanBoxState = { status: "idle" };

    if (!boxCode) {
        state = { status: "idle" };
    } else if (query.isLoading || query.isFetching) {
        state = { status: "loading" };
    } else if (query.isError) {
        // Backend trả 404 kèm { code, message } khi thùng không tồn tại / không mở được -> không phải lỗi kết nối
        const err = query.error as AxiosError<{ message?: string }>;
        if (err.response?.status === 404) {
            state = { status: "not_found" };
        } else {
            state = { status: "error", message: err.response?.data?.message ?? err.message };
        }
    } else if (query.data) {
        if (query.data.isFailure || !query.data.value) {
            state = { status: "not_found" };
        } else {
            state = { status: "found", box: query.data.value };
        }
    }

    return { state, refetch: query.refetch };
}

