import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { boxingScanApi } from "../api/boxing-job.api";

export type ScanTagState =
    | { status: "idle" }
    | { status: "loading" }
    | { status: "error"; message: string }
    | { status: "success"; message: string };

export function useScanTag(qrCode: string | null) {
    const query = useQuery({
        queryKey: ["scan-tag", qrCode],
        queryFn: async ({ queryKey }) => {
            const currentQrCode = queryKey[1] as string;
            const res = await boxingScanApi.postScanTag(currentQrCode);
            return res;
        },
        enabled: !!qrCode,
        retry: false,
        staleTime: 0,         // always re-fetch for fresh scan
        gcTime: 0,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    let state: ScanTagState = { status: "idle" };

    if (!qrCode) {
        state = { status: "idle" };
    } else if (query.isLoading || query.isFetching) {
        state = { status: "loading" };
    } else if (query.isError) {
        // Backend trả 400 kèm { code, message } khi tag không hợp lệ / đã scan / box đầy...
        const err = query.error as AxiosError<{ message?: string }>;
        state = { status: "error", message: err.response?.data?.message ?? err.message };
    } else if (query.data) {
        state = { status: "success", message: query.data.value ?? "Thành công." };
    }

    return { state, refetch: query.refetch };
}
