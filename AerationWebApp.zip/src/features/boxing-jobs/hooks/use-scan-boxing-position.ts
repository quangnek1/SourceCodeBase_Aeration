import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import type { ScanBoxingPosition } from "../types/boxing-jobs-types";
import { boxingScanApi } from "../api/boxing-job.api";

export type BatchLookupState =
    | { status: "idle" }
    | { status: "loading" }
    | { status: "not_found" }
    | { status: "error"; message: string }
    | { status: "found"; batch: ScanBoxingPosition };

export function useScanBoxingPosition(qrcode: string | null) {
    const query = useQuery({
        queryKey: ["scan-boxing-position", qrcode],
        queryFn: async () => {
            const res = await boxingScanApi.postScanBoxingPosition(qrcode!);
            return res;
        },
        enabled: !!qrcode,
        retry: false,
        staleTime: 0,         // always re-fetch for fresh scan
        gcTime: 0,
        refetchOnWindowFocus: false, // don't re-trigger the same scan on tab/window focus
        refetchOnReconnect: false,
    });

    let state: BatchLookupState = { status: "idle" };

    if (!qrcode) {
        state = { status: "idle" };
    } else if (query.isLoading || query.isFetching) {
        state = { status: "loading" };
    } else if (query.isError) {
        // Backend trả 404 kèm { code, message } khi vị trí không tồn tại -> không phải lỗi kết nối
        const err = query.error as AxiosError<{ message?: string }>;
        if (err.response?.status === 404) {
            state = { status: "not_found" };
        } else {
            state = { status: "error", message: err.response?.data?.message ?? err.message };
        }
    } else if (query.data) {
        if (query.data.isFailure || !query.data.value) {
            state = { status: "not_found" };
        } else {
            state = { status: "found", batch: query.data.value };
        }
    }

    return { state, refetch: query.refetch };
}

