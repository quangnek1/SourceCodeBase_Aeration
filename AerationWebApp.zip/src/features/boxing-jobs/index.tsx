import { useEffect, useRef, useState } from 'react'
import { useQrScan } from '../qr-scan/hooks/use-qr-scan'
import { QrScanner } from '../qr-scan/components/qr-scanner'
import { useScanBoxingPosition } from './hooks/use-scan-boxing-position'
import { useScanBox } from './hooks/use-scan-box'
import { useScanTag } from './hooks/use-scan-tag'
import { getBoxingJobStatusLabel } from './utils/boxing-job-status'
import { playScanErrorSound, playScanSuccessSound } from './utils/scan-sound'
import { useBoxingScanStore } from './stores/use-boxing-scan-store'

export function BoxingScanPage() {
  const [scannedQr, setScannedQr] = useState<string | null>(null)
    const [tagQrCode, setTagQrCode] = useState<string | null>(null)
  const [pdaInput, setPdaInput] = useState('')
  const [tagFeedback, setTagFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null)
  const pdaInputRef = useRef<HTMLInputElement>(null)
    const submittedQrRef = useRef<string | null>(null)

  const selectedPosition = useBoxingScanStore((s) => s.selectedPosition)
  const setSelectedPosition = useBoxingScanStore((s) => s.setSelectedPosition)
  const clearSelectedPosition = useBoxingScanStore((s) => s.clearSelectedPosition)
  const selectedBox = useBoxingScanStore((s) => s.selectedBox)
  const setSelectedBox = useBoxingScanStore((s) => s.setSelectedBox)
  const clearSelectedBox = useBoxingScanStore((s) => s.clearSelectedBox)
  const scannedTagCount = useBoxingScanStore((s) => s.scannedTagCount)
  const incrementScannedTagCount = useBoxingScanStore((s) => s.incrementScannedTagCount)

  const {isScanning,startScanning,  stopScanning,  handleScan, handleError, error: cameraError, reset,} = useQrScan({
      onScanSuccess: (result) => {setScannedQr(result.rawValue)
      stopScanning()
    },
  })

  // Chưa chọn vị trí -> scan boxing position. Đã chọn vị trí, chưa chọn thùng -> scan box. Đã chọn thùng -> scan tag.
  const { state: positionState } = useScanBoxingPosition(!selectedPosition ? scannedQr : null)
  const { state: boxState } = useScanBox(selectedPosition && !selectedBox ? scannedQr : null)
    const { state: tagState } = useScanTag(selectedBox ? tagQrCode : null)

  const scanStep: "position" | "box" | "tag" = selectedBox ? "tag" : selectedPosition ? "box" : "position"
  const scanStepLabel: Record<typeof scanStep, string> = {
    position: "Vị trí (Position)",
    box: "Thùng (Box)",
    tag: "Thẻ (Tag)",
  }

  // Giữ vị trí vừa scan thành công làm vị trí đang chọn cho bước scan box
  useEffect(() => {
    if (positionState.status === "found") {
      setSelectedPosition(positionState.batch)
      handleReset() // xoá mã đã scan, tránh việc mã vị trí bị dùng lại làm mã box ở bước kế tiếp
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [positionState, setSelectedPosition])

  // Giữ thùng vừa scan thành công làm thùng đang mở cho bước scan tag (scannedTagCount tự khởi tạo từ currentQty)
  useEffect(() => {
    if (boxState.status === "found") {
      setSelectedBox(boxState.box)
      handleReset() // xoá mã box vừa scan, tránh việc nó bị dùng lại làm mã tag ở bước kế tiếp
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boxState, setSelectedBox])

  // Mỗi lần scan tag thành công, phát âm báo + hiển thị kết quả rồi dọn input để scan tag kế tiếp
  useEffect(() => {
    if (tagState.status === "success") {
      setTagFeedback({ type: "success", message: tagState.message })
      playScanSuccessSound()
      incrementScannedTagCount()
            if (tagQrCode === submittedQrRef.current) {
                handleReset()
            }
    } else if (tagState.status === "error") {
      setTagFeedback({ type: "error", message: tagState.message })
      playScanErrorSound()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tagState])

  function handleNewScan(value: string) {
    handleScan(value)
    setScannedQr(value)
        submittedQrRef.current = value
        if (selectedBox) setTagQrCode(value)
    setTagFeedback(null)
  }

    function handlePdaScan(value: string) {
        const trimmedValue = value.trim()
        if (!trimmedValue) return

        setScannedQr(trimmedValue)
        submittedQrRef.current = trimmedValue
        if (selectedBox) setTagQrCode(trimmedValue)
        setTagFeedback(null)
    }

  /** PDA: scan sends characters then Enter */
  function handlePdaKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
            const value = e.currentTarget.value.trim()
      if (value) {
                handlePdaScan(value)
        setPdaInput('')
      }
    }
  }

  function handleReset() {
    reset()
    setScannedQr(null)
    setTagQrCode(null)
    setPdaInput('')
    pdaInputRef.current?.focus()
  }

    return (
        <div className="flex flex-col gap-4">
            {/* Header row */}
            <div className="flex items-center justify-between">
                <h1 className="text-lg font-semibold">Boxing Scan</h1>
                <button
                    type="button"
                    onClick={isScanning ? stopScanning : startScanning}
                    className="rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                >
                    {isScanning ? "Stop Camera" : "Open Camera"}
                </button>
            </div>

            {/* Vị trí đang chọn để scan box/tag tiếp theo */}
            {selectedPosition && (
                <div className="flex items-center justify-between rounded-md border border-primary/30 bg-primary/5 px-3 py-2">
                    <span className="text-sm">
                        Đang chọn vị trí: <span className="font-semibold">{selectedPosition.positionCode}</span>
                    </span>
                    <button
                        type="button"
                        onClick={clearSelectedPosition}
                        className="rounded-md border px-2 py-1 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Đổi vị trí
                    </button>
                </div>
            )}

            {/* Thùng đang mở để scan tag tiếp theo */}
            {selectedBox && (
                <div className="flex items-center justify-between rounded-md border border-primary/30 bg-primary/5 px-3 py-2">
                    <span className="text-sm">
                        Đang đóng thùng: <span className="font-semibold">{selectedBox.boxCode}</span>
                        <span className="text-muted-foreground"> ({scannedTagCount} thẻ đã scan)</span>
                    </span>
                    <button
                        type="button"
                        onClick={clearSelectedBox}
                        className="rounded-md border px-2 py-1 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Đổi thùng
                    </button>
                </div>
            )}

            {/* PDA input */}
            <div className="flex flex-col gap-1">
                <label
                    htmlFor="pda-scan-input"
                    className="text-xs font-medium text-muted-foreground uppercase tracking-wide"
                >
                    Đang scan: {scanStepLabel[scanStep]}
                </label>
                <input
                    id="pda-scan-input"
                    ref={pdaInputRef}
                    type="text"
                    value={pdaInput}
                    onChange={(e) => setPdaInput(e.target.value)}
                    onKeyDown={handlePdaKeyDown}
                    placeholder={`Scan mã ${scanStepLabel[scanStep]}…`}
                    className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    autoComplete="off"
                    autoCorrect="off"
                    spellCheck={false}
                />
            </div>

            {/* Camera */}
            <QrScanner isScanning={isScanning} onScan={handleNewScan} onError={handleError} />

            {/* Camera error */}
            {cameraError && (
                <p className="text-sm text-destructive rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2">
                    {cameraError}
                </p>
            )}

            {/* Result area: chưa chọn vị trí -> kết quả scan boxing position */}
            {!selectedPosition && positionState.status === "idle" && (
                <p className="text-sm text-muted-foreground text-center mt-2">
                    Scan a boxing position QR code to begin.
                </p>
            )}

            {!selectedPosition && positionState.status === "loading" && (
                <div className="flex items-center justify-center py-8">
                    <span className="text-sm text-muted-foreground animate-pulse">Đang tìm vị trí…</span>
                </div>
            )}

            {!selectedPosition && positionState.status === "not_found" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-6 text-center">
                    <p className="text-sm font-medium text-destructive">Vị trí không tồn tại</p>
                    <p className="text-xs text-muted-foreground mt-1">QR: {scannedQr}</p>
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Scan lại
                    </button>
                </div>
            )}

            {!selectedPosition && positionState.status === "error" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-4 text-center">
                    <p className="text-sm font-medium text-destructive">Lỗi kết nối</p>
                    <p className="text-xs text-muted-foreground mt-1">{positionState.message}</p>
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Thử lại
                    </button>
                </div>
            )}

            {!selectedPosition && positionState.status === "found" && (
                <div className="rounded-md border bg-muted/20 px-4 py-5 flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold">{positionState.batch.positionCode}</span>
                        <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium">
                            {positionState.batch.hasActiveJob ? "Đang có job" : "Không có job"}
                        </span>
                    </div>

                    {positionState.batch.boxingJobDtos.length > 0 ? (
                        <div className="rounded-md border border-border/50 divide-y divide-border/50 text-xs">
                            {positionState.batch.boxingJobDtos.map((job) => (
                                <div key={job.id} className="flex items-center justify-between px-3 py-2 gap-2">
                                    <span className="text-muted-foreground">Job #{job.id}</span>
                                    <span className="font-medium">{getBoxingJobStatusLabel(job.status)}</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-xs text-muted-foreground">Vị trí chưa có job nào.</p>
                    )}
                </div>
            )}

            {/* Result area: đã chọn vị trí, chưa chọn thùng -> kết quả scan box */}
            {selectedPosition && !selectedBox && boxState.status === "idle" && (
                <p className="text-sm text-muted-foreground text-center mt-2">
                    Scan a box QR code.
                </p>
            )}

            {selectedPosition && !selectedBox && boxState.status === "loading" && (
                <div className="flex items-center justify-center py-8">
                    <span className="text-sm text-muted-foreground animate-pulse">Đang tìm thùng…</span>
                </div>
            )}

            {selectedPosition && !selectedBox && boxState.status === "not_found" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-6 text-center">
                    <p className="text-sm font-medium text-destructive">Thùng không tồn tại</p>
                    <p className="text-xs text-muted-foreground mt-1">QR: {scannedQr}</p>
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Scan lại
                    </button>
                </div>
            )}

            {selectedPosition && !selectedBox && boxState.status === "error" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-4 text-center">
                    <p className="text-sm font-medium text-destructive">Lỗi kết nối</p>
                    <p className="text-xs text-muted-foreground mt-1">{boxState.message}</p>
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Thử lại
                    </button>
                </div>
            )}

            {/* Result area: đã chọn thùng -> kết quả scan tag */}
            {selectedBox && tagState.status === "idle" && tagFeedback?.type === "success" && (
                <div className="rounded-md border border-green-500/30 bg-green-500/10 px-4 py-3 text-center">
                    <p className="text-sm font-medium text-green-600">✓ Scan tag thành công</p>
                    <p className="text-xs text-muted-foreground mt-1">{tagFeedback.message}</p>
                </div>
            )}

            {selectedBox && tagState.status === "idle" && !tagFeedback && (
                <p className="text-sm text-muted-foreground text-center mt-2">
                    Scan a tag QR code.
                </p>
            )}

            {selectedBox && tagState.status === "loading" && (
                <div className="flex items-center justify-center py-8">
                    <span className="text-sm text-muted-foreground animate-pulse">Đang scan tag…</span>
                </div>
            )}

            {selectedBox && tagState.status === "error" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-4 text-center">
                    <p className="text-sm font-medium text-destructive">{tagState.message}</p>
                    {/* <p className="text-xs text-muted-foreground mt-1">QR: {scannedQr}</p> */}
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Scan lại
                    </button>
                </div>
            )}
        </div>
    );
}
