import { axiosInstance } from "@/lib/axios";
import type { ApiResponse } from "@/types/dto";
import type { ScanBox, ScanBoxingPosition } from "../types/boxing-jobs-types";

export const boxingScanApi = {
    postScanBoxingPosition: async (code: string): Promise<ApiResponse<ScanBoxingPosition>> => {
        const res = await axiosInstance.post<ApiResponse<ScanBoxingPosition>>(
            "/BoxingJob/scan-boxing-position",
            null,
            { params: { code } }
        );
        return res.data;
    },

    postScanBox: async (boxCode: string): Promise<ApiResponse<ScanBox>> => {
        const res = await axiosInstance.post<ApiResponse<ScanBox>>(
            "/BoxingJob/scan-box",
            null,
            { params: { boxCode } }
        );
        return res.data;
    },

    postScanTag: async (qrCode: string): Promise<ApiResponse<string>> => {
        const res = await axiosInstance.post<ApiResponse<string>>(
            "/BoxingJob/scan-tag",
            null,
            { params: { qrCode } }
        );
        return res.data;
    },
};
