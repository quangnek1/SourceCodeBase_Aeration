let successAudio: HTMLAudioElement | null = null;
let errorAudio: HTMLAudioElement | null = null;

function playAudio(audio: HTMLAudioElement) {
    audio.currentTime = 0;
    void audio.play();
}

// Âm báo scan thành công
export function playScanSuccessSound(): void {
    successAudio ??= new Audio("/sounds/ok.mp3");
    playAudio(successAudio);
}

// Âm báo scan thất bại
export function playScanErrorSound(): void {
    errorAudio ??= new Audio("/sounds/ng.mp3");
    playAudio(errorAudio);
}
