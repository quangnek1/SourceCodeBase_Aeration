// Mirrors Shared.Emumerations.BoxingJobStatus
const BOXING_JOB_STATUS_LABELS: Record<number, string> = {
    0: "Khởi tạo",
    1: "Đang thao tác",
    2: "Tạm dừng",
    3: "Hoàn thành",
    4: "Hủy bỏ",
};

export function getBoxingJobStatusLabel(status: number): string {
    return BOXING_JOB_STATUS_LABELS[status] ?? `Unknown (${status})`;
}
