export interface ScanBoxingPosition {
    positionId: number;
    positionCode: string;
    hasActiveJob: boolean;
    boxingJobDtos: BoxingJob[];
}

// Mirrors Shared.Emumerations.BoxingJobStatus (serialized as numeric enum)
export interface BoxingJob {
    id: number;
    targetQty: number;
    status: number;
    startedAt: string;
    finishedAt: string | null;
}

export interface BoxingPosition {
    id: number;
    positionCode: string;
    positionStatus: string;
}

export interface ScanBox {
    id: number;
    boxCode: string;
    currentQty: number;
    capacity: number;
}