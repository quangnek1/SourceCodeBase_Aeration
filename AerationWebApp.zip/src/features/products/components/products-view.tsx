import { Button } from "@/components/ui/button"
import { useProducts } from "@/hooks/use-queries"
import { RiAddLine } from "@remixicon/react"

export function ProductsView() {
  const { data: products = [] } = useProducts()

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">Products Catalog</h1>
          <p className="text-sm text-muted-foreground">Define physical configuration, humidity limits, and aeration formulas for each product.</p>
        </div>
        <Button className="gap-1.5 self-start sm:self-auto">
          <RiAddLine className="h-5 w-5" /> Add Product
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => {
          const type = product.name.toLowerCase().includes("gạo") ? "Nông sản - Gạo" : "Hạt sấy khô"
          const moistureMax = product.name.toLowerCase().includes("gạo") ? "14.5%" : "12.0%"
          const density = product.name.toLowerCase().includes("gạo") ? "780 kg/m³" : "550 kg/m³"

          return (
            <div key={product.id} className="rounded-xl border border-border bg-card p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition-shadow">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-md">
                      {type}
                    </span>
                    <h3 className="font-semibold text-base text-foreground mt-1.5">{product.name}</h3>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground bg-muted px-2 py-1 rounded-md">
                    PRD-{product.id.slice(0, 6).toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">{product.description || "No technical description available."}</p>
                
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border/50 text-xs">
                  <div className="bg-muted/40 p-2 rounded-lg">
                    <p className="text-[10px] text-muted-foreground">Độ ẩm tối đa</p>
                    <p className="font-semibold text-foreground mt-0.5">{moistureMax}</p>
                  </div>
                  <div className="bg-muted/40 p-2 rounded-lg">
                    <p className="text-[10px] text-muted-foreground">Grain Density</p>
                    <p className="font-semibold text-foreground mt-0.5">{density}</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-5 pt-3 border-t border-border/50 flex items-center justify-end gap-2">
                <Button variant="outline" size="sm" className="h-8 text-xs">Aeration Config</Button>
                <Button variant="outline" size="sm" className="h-8 text-xs">Edit</Button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
