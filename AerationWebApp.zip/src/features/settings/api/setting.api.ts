import { axiosInstance } from "@/lib/axios";
import type { Setting } from "../types/setting.types";

export const settingApi = {

    getSetting: async (): Promise<Setting> => {
        const res = await axiosInstance.get("/Setting/get-setting");
        return res.data.value;
    },

    updateSetting: async (setting: Setting): Promise<Setting> => {
        const res = await axiosInstance.put<{ value: Setting }>(
            `/Setting/${setting.id}`,
            {
                planCAG: setting.planCAG,
                planPTCA: setting.planPTCA,
                dataAmiQ411: setting.dataAmiQ411,
            },
        );
        return res.data.value;
    },
}
