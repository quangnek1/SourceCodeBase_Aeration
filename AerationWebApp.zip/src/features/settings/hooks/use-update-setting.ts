import { useMutation, useQueryClient } from '@tanstack/react-query'
import { settingApi } from '../api/setting.api'

export function useUpdateSetting() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: settingApi.updateSetting,
    onSuccess: (updatedSetting) => {
      queryClient.setQueryData(['setting'], updatedSetting)
    },
  })
}