import { useQuery } from '@tanstack/react-query'
import { settingApi } from '../api/setting.api'

export function useSetting() {
  return useQuery({
    queryKey: ['setting'],
    queryFn: settingApi.getSetting,
  })
}