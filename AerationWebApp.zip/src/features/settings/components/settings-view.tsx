import { useState } from 'react'
import axios from 'axios'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import {
  RiEditLine,
  RiUserLine,
  RiFolderLine,
} from '@remixicon/react'
import { useSettings } from '@/hooks/useSettings'
import { useTheme } from '@/components/theme-provider'
import { useSetting } from '../hooks/use-setting'
import { useUpdateSetting } from '../hooks/use-update-setting'
import type { Setting } from '../types/setting.types'

export function SettingsView() {
  const { settings, updateSettings } = useSettings()
  const { setTheme } = useTheme()

  const { data: setting } = useSetting()
  console.log('setting:', setting)
  const updateSetting = useUpdateSetting()
  const [settingForm, setSettingForm] = useState<Setting | null>(null)
  const [isEditingPaths, setIsEditingPaths] = useState(false)

  const handleSaveSetting = () => {
    if (!settingForm) return

    updateSetting.mutate(settingForm, {
      onSuccess: () => {
        setIsEditingPaths(false)
        toast.success('Settings saved successfully!')
      },
      onError: (error) => {
        let message = 'Unknown error'

        if (axios.isAxiosError(error)) {
          const responseData = error.response?.data as
            | {
                detail?: string
                errors?: Array<{
                  propertyName?: string
                  errorMessage?: string
                }>
              }
            | undefined
          const validationMessage = responseData?.errors
            ?.map((validationError) =>
              validationError.propertyName && validationError.errorMessage
                ? `${validationError.propertyName}: ${validationError.errorMessage}`
                : validationError.errorMessage,
            )
            .filter(Boolean)
            .join('; ')

          message =
            validationMessage ||
            responseData?.detail ||
            `${error.response?.status ?? 'Network'}: ${error.message}`
        }

        console.error('Update setting failed:', error)
        alert(`Could not save settings. ${message}`)
      },
    })
  }

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-bold tracking-tight">
          System & User Settings
        </h1>
        <p className="text-sm text-muted-foreground">
          Manage operational parameters and personal display settings.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 lg:grid-cols-3">
        {/* User Preferences */}
        <div className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-xs">
          <div className="flex items-center gap-2 border-b border-border pb-3">
            <RiUserLine className="h-5 w-5 text-indigo-500" />
            <h3 className="font-semibold text-foreground">User Preferences</h3>
          </div>

          <div className="space-y-4 text-sm">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                Display Language
              </label>
              <select
                value={settings.language}
                onChange={(e) =>
                  updateSettings({ language: e.target.value as 'vi' | 'en' })
                }
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-hidden"
              >
                <option value="vi">Vietnamese</option>
                <option value="en">English</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                Items per page
              </label>
              <select
                value={settings.pageSize}
                onChange={(e) =>
                  updateSettings({ pageSize: Number(e.target.value) })
                }
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-hidden"
              >
                <option value={10}>10 rows</option>
                <option value={20}>20 rows</option>
                <option value={50}>50 rows</option>
                <option value={100}>100 rows</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                Theme
              </label>
              <select
                value={settings.theme}
                onChange={(e) => {
                  const value = e.target.value as 'light' | 'dark' | 'system'
                  updateSettings({ theme: value })
                  setTheme(value)
                }}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-hidden"
              >
                <option value="system">System (Auto)</option>
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>

            <p className="mt-4 text-xs text-muted-foreground italic">
              * Changes are automatically saved locally in the browser.
            </p>
          </div>
        </div>

        {/* Data Save Paths */}
        <div className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-xs">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div className="flex items-center gap-2">
              <RiFolderLine className="h-5 w-5 text-emerald-500" />
              <h3 className="font-semibold text-foreground">
                Plan Data Save Paths
              </h3>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Edit plan data save paths"
              title="Edit plan data save paths"
              onClick={() => setIsEditingPaths(true)}
            >
              <RiEditLine />
            </Button>
          </div>

          <div className="space-y-4 text-sm">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                CAG Plan Path
              </label>
              <input
                type="text"
                disabled={!isEditingPaths}
                value={settingForm?.planCAG ?? setting?.planCAG ?? ''}
                onChange={(e) =>
                  setSettingForm((current) =>
                    current
                      ? { ...current, planCAG: e.target.value }
                      : setting
                        ? { ...setting, planCAG: e.target.value }
                        : current,
                  )
                }
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-hidden"
                placeholder="C:\Data\PlanCAG"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                PTCA Plan Path
              </label>
              <input
                type="text"
                disabled={!isEditingPaths}
                value={settingForm?.planPTCA ?? setting?.planPTCA ?? ''}
                onChange={(e) =>
                  setSettingForm((current) =>
                    current
                      ? { ...current, planPTCA: e.target.value }
                      : setting
                        ? { ...setting, planPTCA: e.target.value }
                        : current,
                  )
                }
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-hidden"
                placeholder="C:\Data\PlanPTCA"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                AMI Plan Path
              </label>
              <input
                type="text"
                disabled={!isEditingPaths}
                value={
                  settingForm?.dataAmiQ411 ?? setting?.dataAmiQ411 ?? ''
                }
                onChange={(e) =>
                  setSettingForm((current) =>
                    current
                      ? { ...current, dataAmiQ411: e.target.value }
                      : setting
                        ? { ...setting, dataAmiQ411: e.target.value }
                        : current,
                  )
                }
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-hidden"
                placeholder="C:\Data\PlanAMI"
              />
            </div>
            {isEditingPaths && (
              <div className="pt-2">
                <Button
                  size="sm"
                  onClick={handleSaveSetting}
                  disabled={!settingForm || updateSetting.isPending}
                >
                  {updateSetting.isPending ? 'Saving...' : 'Save'}
                </Button>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  )
}
