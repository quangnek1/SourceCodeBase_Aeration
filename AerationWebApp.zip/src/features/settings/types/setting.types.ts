export interface Setting {
    id: number
    planCAG: string
    planPTCA: string
    dataAmiQ411: string
    lastModifiedDate: string
}