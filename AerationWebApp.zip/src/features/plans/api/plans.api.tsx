import { axiosInstance } from "@/lib/axios";
import type { ApiResponse } from "@/types/dto";
import type { DataPlanDto, CreateF6112Command } from "../types/plans.types";


export const plansApi = {
    getDataPlan: async (filter?: string): Promise<ApiResponse<DataPlanDto[]>> => {
        const res = await axiosInstance.get<ApiResponse<DataPlanDto[]>>(`/DataPlan/get-all-dataplan?filter=${filter}`);
        return res.data;
    },
    getDataAmiQ411: async (filter?: string): Promise<ApiResponse<any[]>> => {
        const query = filter ? `?filter=${encodeURIComponent(filter)}` : "";
        const res = await axiosInstance.get<ApiResponse<any[]>>(`/DataPlan/get-all-ami${query}`);
        return res.data;
    },
    syncDataPlan: async (): Promise<ApiResponse<any>> => {
        const res = await axiosInstance.post<ApiResponse<any>>(`/DataPlan/sync-data-plan`);
        return res.data;
    },
    syncDataAmiQ411: async (): Promise<ApiResponse<any>> => {
        const res = await axiosInstance.post<ApiResponse<any>>(`/DataPlan/sync-data-ami`);
        return res.data;
    },
    createF6112: async (command: CreateF6112Command): Promise<ApiResponse<any>> => {
        const res = await axiosInstance.post<ApiResponse<any>>(`/Batch/create-f6112`, command);
        return res.data;
    }
};
