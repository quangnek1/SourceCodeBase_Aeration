export interface DataPlanDto {
    poNo?: string;
    tt?: string;
    materialTypeC?: string;
    pldOrd?: string;
    material: string;
    itemCodeTypeC?: string;
    itemCode?: string;
    drawingListNo?: string;
    itemName?: string;
    internalLot?: string;
    phase?: string;
    externalLot1?: string;
    qty?: number;
    qtyInput?: number;
    keepAeration: number;
    completeDate?: string; // ISO 8601 string mapped from DateTime
    qaTest?: number;
    destination?: string;
    label?: string; // ISO 8601 string mapped from DateTime
    bioburden?: string;
    seal?: string; // ISO 8601 string mapped from DateTime
    ster?: string; // ISO 8601 string mapped from DateTime
    me?: string;
    boxing?: string;
    testEndotoxin?: string;
    testParticle?: string;
    labelData?: number;
    sealData?: number;
    boxingData?: number;
    etd?: string; // ISO 8601 string mapped from DateTime
    family?: string;
    keepStorage?: number;
    meChia?: string;
    statusDescription?: string;
    StatusDescription?: string; // Tạm giữ phòng trường hợp API trả về kiểu cũ
    status?: DataStatus; // integer from backend
}

export const DataStatus = {
    Initial: 0,
    Created: 1,
    ReCreated: 2,
    Aeration: 3,
    AerationDone: 4,
    Boxing: 5,
    BoxingDone: 6,
    Packing: 7,
    PackingDone: 8,
    Done: 9
} as const;

export type DataStatus = typeof DataStatus[keyof typeof DataStatus];

export interface StatusColorConfig {
    bg: string;
    text: string;
    border: string;
    dot: string;
}

export const ProcessStatus = {
    Initial: "Initial",
    Created: "Created",
    ReCreated: "ReCreated",
    Aeration: "Aeration",
    AerationDone: "AerationDone",
    Boxing: "Boxing",
    BoxingDone: "BoxingDone",
    Packing: "Packing",
    PackingDone: "PackingDone",
    Done: "Done"
} as const;

export type ProcessStatus = typeof ProcessStatus[keyof typeof ProcessStatus];

export const PLAN_STATUS_TRANSLATIONS: Record<string, string> = {
    "Initial": "Initial",
    "Created": "Created",
    "ReCreated": "ReCreated",
    "Aeration": "Aeration",
    "AerationDone": "AerationDone",
    "Boxing": "Boxing",
    "BoxingDone": "BoxingDone",
    "Packing": "Packing",
    "PackingDone": "PackingDone",
    "Done": "Done",
    
    // Fallback for old Vietnamese keys if they somehow appear
    "Sục khí": "Sục khí",
    "Đã sục khí": "Đã sục khí",
    "Close hộp": "Close hộp",
    "Đã đóng hộp": "Đã đóng hộp",
    "Close gói": "Close gói",
    "Đã đóng gói": "Đã đóng gói"
};

export const PLAN_STATUS_COLORS: Record<string, StatusColorConfig> = {
    "Initial": { bg: "bg-slate-500/10", text: "text-slate-600 dark:text-slate-400", border: "border-slate-500/20", dot: "bg-slate-500" },
    "Created": { bg: "bg-blue-500/10", text: "text-blue-600 dark:text-blue-400", border: "border-blue-500/20", dot: "bg-blue-500" },
    "ReCreated": { bg: "bg-sky-500/10", text: "text-sky-600 dark:text-sky-400", border: "border-sky-500/20", dot: "bg-sky-500" },
    
    "Aeration": { bg: "bg-amber-500/10", text: "text-amber-600 dark:text-amber-400", border: "border-amber-500/20", dot: "bg-amber-500" },
    "AerationDone": { bg: "bg-emerald-500/10", text: "text-emerald-600 dark:text-emerald-400", border: "border-emerald-500/20", dot: "bg-emerald-500" },
    
    "Boxing": { bg: "bg-violet-500/10", text: "text-violet-600 dark:text-violet-400", border: "border-violet-500/20", dot: "bg-violet-500" },
    "BoxingDone": { bg: "bg-fuchsia-500/10", text: "text-fuchsia-600 dark:text-fuchsia-400", border: "border-fuchsia-500/20", dot: "bg-fuchsia-500" },
    
    "Packing": { bg: "bg-indigo-500/10", text: "text-indigo-600 dark:text-indigo-400", border: "border-indigo-500/20", dot: "bg-indigo-500" },
    "PackingDone": { bg: "bg-teal-500/10", text: "text-teal-600 dark:text-teal-400", border: "border-teal-500/20", dot: "bg-teal-500" },
    
    "Done": { bg: "bg-green-500/10", text: "text-green-600 dark:text-green-400", border: "border-green-500/20", dot: "bg-green-500" },

    // Fallback support for older Vietnamese strings
    "Sục khí": { bg: "bg-amber-500/10", text: "text-amber-600 dark:text-amber-400", border: "border-amber-500/20", dot: "bg-amber-500" },
    "Đã sục khí": { bg: "bg-emerald-500/10", text: "text-emerald-600 dark:text-emerald-400", border: "border-emerald-500/20", dot: "bg-emerald-500" },
    "Close hộp": { bg: "bg-violet-500/10", text: "text-violet-600 dark:text-violet-400", border: "border-violet-500/20", dot: "bg-violet-500" },
    "Đã đóng hộp": { bg: "bg-fuchsia-500/10", text: "text-fuchsia-600 dark:text-fuchsia-400", border: "border-fuchsia-500/20", dot: "bg-fuchsia-500" },
    "Close gói": { bg: "bg-indigo-500/10", text: "text-indigo-600 dark:text-indigo-400", border: "border-indigo-500/20", dot: "bg-indigo-500" },
    "Đã đóng gói": { bg: "bg-teal-500/10", text: "text-teal-600 dark:text-teal-400", border: "border-teal-500/20", dot: "bg-teal-500" }
};

export const DEFAULT_STATUS_COLOR: StatusColorConfig = {
    bg: "bg-gray-500/10",
    text: "text-gray-600 dark:text-gray-400",
    border: "border-gray-500/20",
    dot: "bg-gray-500"
};

export interface CreateF6112Command {
    sterilizeDate: string;
    batchNo: string;
    listBatch?: number[];
}
