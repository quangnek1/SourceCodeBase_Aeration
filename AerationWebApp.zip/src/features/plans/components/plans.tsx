import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import {
  RiAddLine,
  RiSearchLine,
  RiRefreshLine,
  RiCalendarLine,
  RiCloseLine,
  RiFilterOffLine
} from "@remixicon/react"
import { usePlans } from "../hooks/usePlans";
import { useSyncPlans } from "../hooks/useSyncPlans";
import { useCreatePlan } from "../hooks/useCreatePlan";
import { toast } from "sonner";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { type DataPlanDto, PLAN_STATUS_COLORS, PLAN_STATUS_TRANSLATIONS, DEFAULT_STATUS_COLOR } from "../types/plans.types";
import { CreatePlanModal } from "./create-plan-modal";

interface PlansComponentProps {
  filter?: string;
}

export function PlansComponent({ filter }: PlansComponentProps) {
  const { data: plans = [], isLoading } = usePlans(filter);
  const { mutate: syncPlans, isPending: isSyncing } = useSyncPlans();
  const { mutate: createPlan, isPending: isCreatingPlan } = useCreatePlan();

  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterDate, setFilterDate] = useState<Date | undefined>(undefined);
  const [filterMe, setFilterMe] = useState<string>("");
  const [sortKey, setSortKey] = useState<keyof DataPlanDto | "">("");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [hideKeepZero, setHideKeepZero] = useState(true);

  const [selectedPlanIds, setSelectedPlanIds] = useState<string[]>([]);
  const [alertInfo, setAlertInfo] = useState<{
    isOpen: boolean;
    unselectedCount: number;
    alreadyCreatedCount: number;
  }>({ isOpen: false, unselectedCount: 0, alreadyCreatedCount: 0 });

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const getPlanId = (plan: DataPlanDto) => `${plan.poNo || 'no-po'}-${plan.internalLot || 'no-lot'}-${plan.itemCode || 'no-code'}`;

  const handleResetFilter = () => {
    setSearchQuery("");
    setFilterDate(undefined);
    setFilterMe("");
    setSortKey("");
    setSortOrder("asc");
    setHideKeepZero(true);
    setSelectedPlanIds([]);
  };

  const handleCreatePlan = () => {
    const firstSelectedId = selectedPlanIds[0];
    const plan = plans.find(p => getPlanId(p) === firstSelectedId);

    if (!plan) return;

    if (!plan.ster || !plan.meChia) {
      toast.error("Kế hoạch selected không có ngày Ster hoặc ME Chia!");
      return;
    }

    // Chỉ xét các lô cùng ngày Ster, cùng Mẻ và cùng ME Chia vì đó là nhóm dữ liệu được tạo kế hoạch đồng thời.
    let relatedPlans = plans.filter(
      p => p.ster === plan.ster && p.me === plan.me && p.meChia === plan.meChia
    );
    if (hideKeepZero) {
      relatedPlans = relatedPlans.filter(p => p.keepStorage !== 0);
    }
    const unselectedRelatedPlans = relatedPlans.filter(p => !selectedPlanIds.includes(getPlanId(p)));

    // Kiểm tra xem có lô nào đã được tạo không
    const selectedPlansData = plans.filter(p => selectedPlanIds.includes(getPlanId(p)));
    const alreadyCreatedPlans = selectedPlansData.filter(p => {
      const statusDesc = p.statusDescription || p.StatusDescription || "";
      // Các trạng thái khác "Initial", "Initial" và "" đều có nghĩa là đã được tạo
      return statusDesc !== "Initial" && statusDesc !== "Initial" && statusDesc !== "";
    });

    if (unselectedRelatedPlans.length > 0 || alreadyCreatedPlans.length > 0) {
      setAlertInfo({
        isOpen: true,
        unselectedCount: unselectedRelatedPlans.length,
        alreadyCreatedCount: alreadyCreatedPlans.length
      });
      return;
    }

    setIsCreateModalOpen(true);
  };

  const executeCreatePlan = () => {
    const firstSelectedId = selectedPlanIds[0];
    const plan = plans.find(p => getPlanId(p) === firstSelectedId);
    
    if (!plan) return;

    createPlan({
      sterilizeDate: plan.ster!,
      batchNo: plan.meChia!,
      listBatch: []
    }, {
      onSuccess: () => {
        setSelectedPlanIds([]);
        setAlertInfo(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const uniqueMeValues = useMemo(() => {
    let result = [...plans];

    if (hideKeepZero) {
      result = result.filter(plan => plan.keepStorage !== 0);
    }

    if (filterDate) {
      const formattedFilterDate = format(filterDate, "yyyy-MM-dd");
      result = result.filter(plan => {
        if (!plan.ster) return false;
        return plan.ster.startsWith(formattedFilterDate);
      });
    }

    if (searchQuery) {
      const lowerQuery = searchQuery.toLowerCase();
      result = result.filter(plan =>
        plan.poNo?.toLowerCase().includes(lowerQuery) ||
        plan.itemName?.toLowerCase().includes(lowerQuery) ||
        plan.material?.toLowerCase().includes(lowerQuery) ||
        plan.itemCode?.toLowerCase().includes(lowerQuery) ||
        plan.internalLot?.toLowerCase().includes(lowerQuery) ||
        plan.tt?.toLowerCase().includes(lowerQuery)
      );
    }

    const meSet = new Set<string>();
    result.forEach(plan => {
      if (plan.meChia) meSet.add(plan.meChia);
    });
    return Array.from(meSet).sort();
  }, [plans, filterDate, searchQuery, hideKeepZero]);

  const filteredAndSortedPlans = useMemo(() => {
    let result = [...plans];

    if (hideKeepZero) {
      result = result.filter(plan => plan.keepStorage !== 0);
    }

    if (searchQuery) {
      const lowerQuery = searchQuery.toLowerCase();
      result = result.filter(plan =>
        plan.poNo?.toLowerCase().includes(lowerQuery) ||
        plan.itemName?.toLowerCase().includes(lowerQuery) ||
        plan.material?.toLowerCase().includes(lowerQuery) ||
        plan.itemCode?.toLowerCase().includes(lowerQuery) ||
        plan.internalLot?.toLowerCase().includes(lowerQuery) ||
        plan.tt?.toLowerCase().includes(lowerQuery)
      );
    }

    if (filterDate) {
      const formattedFilterDate = format(filterDate, "yyyy-MM-dd");
      result = result.filter(plan => {
        if (!plan.ster) return false;
        return plan.ster.startsWith(formattedFilterDate);
      });
    }

    if (filterMe) {
      result = result.filter(plan => plan.meChia === filterMe);
    }

    if (sortKey) {
      result.sort((a, b) => {
        const valA = a[sortKey];
        const valB = b[sortKey];
        if (valA === valB) return 0;
        if (valA == null) return 1;
        if (valB == null) return -1;

        const comparison = valA < valB ? -1 : 1;
        return sortOrder === "asc" ? comparison : -comparison;
      });
    }

    return result;
  }, [plans, searchQuery, filterDate, filterMe, sortKey, sortOrder, hideKeepZero]);

  const isAllSelected = filteredAndSortedPlans.length > 0 && selectedPlanIds.length === filteredAndSortedPlans.length;

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      if (filteredAndSortedPlans.length === 0) return;

      const firstPlan = filteredAndSortedPlans[0];
      const hasDifferent = filteredAndSortedPlans.some(
        p => p.me !== firstPlan.me || p.meChia !== firstPlan.meChia || p.ster !== firstPlan.ster
      );

      if (hasDifferent) {
        toast.error("Không thể chọn tất cả! Các kế hoạch trong danh sách không cùng Mẻ, ME Chia và Ngày Ster.");
        return;
      }
      setSelectedPlanIds(filteredAndSortedPlans.map(getPlanId));
    } else {
      setSelectedPlanIds([]);
    }
  };

  const handleSelectPlan = (planId: string, checked: boolean) => {
    if (checked) {
      if (selectedPlanIds.length > 0) {
        const firstSelectedId = selectedPlanIds[0];
        const firstPlan = plans.find(p => getPlanId(p) === firstSelectedId);
        const currentPlan = plans.find(p => getPlanId(p) === planId);

        if (firstPlan && currentPlan) {
          if (
            firstPlan.me !== currentPlan.me ||
            firstPlan.meChia !== currentPlan.meChia ||
            firstPlan.ster !== currentPlan.ster
          ) {
            toast.error("Chỉ được phép chọn các kế hoạch có cùng Mẻ, ME Chia và Ngày Ster!");
            return;
          }
        }
      }
      setSelectedPlanIds(prev => [...prev, planId]);
    } else {
      setSelectedPlanIds(prev => prev.filter(id => id !== planId));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">Kế hoạch & Quy trình</h1>
          <p className="text-sm text-muted-foreground">Xây dựng mẫu quy trình vận hành tự động (quy trình sục khí nhiều bước, xông hơi thuốc khử trùng).</p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <Button
            variant="outline"
            className="gap-1.5"
            onClick={() => setIsSyncModalOpen(true)}
            disabled={isSyncing}
          >
            <RiRefreshLine className={`h-5 w-5 ${isSyncing ? "animate-spin" : ""}`} />
            {isSyncing ? "Đang đồng bộ..." : "Sync dữ liệu"}
          </Button>
          <Button
            className="gap-1.5"
            disabled={selectedPlanIds.length === 0 || isCreatingPlan}
            onClick={handleCreatePlan}
          >
            <RiAddLine className={`h-5 w-5 ${isCreatingPlan ? "animate-spin" : ""}`} />
            {isCreatingPlan ? "Đang tạo..." : "Tạo kế hoạch mới"}
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-card p-4 rounded-xl border border-border shadow-xs">
        <div className="relative w-full sm:w-80">
          <RiSearchLine className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Tìm kiếm PO, Lô, Sản phẩm..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-background border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary/50"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center relative">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={`w-[190px] justify-start text-left font-normal ${!filterDate ? "text-muted-foreground" : ""}`}
                  title="Lọc theo ngày Ster"
                >
                  <RiCalendarLine className="mr-2 h-4 w-4" />
                  {filterDate ? format(filterDate, "dd/MM/yyyy") : <span>Ngày Ster...</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={filterDate}
                  onSelect={setFilterDate}
                  locale={vi}
                />
              </PopoverContent>
            </Popover>
            {filterDate && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-2 hover:bg-transparent text-muted-foreground"
                onClick={() => setFilterDate(undefined)}
              >
                <RiCloseLine className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="h-6 w-px bg-border hidden sm:block mx-1"></div>
          <select
            className="text-sm bg-background border border-border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 max-w-[150px]"
            value={filterMe}
            onChange={(e) => setFilterMe(e.target.value)}
            title="Lọc theo ME Chia"
          >
            <option value="">Tất cả ME Chia</option>
            {uniqueMeValues.map(me => (
              <option key={me} value={me}>{me}</option>
            ))}
          </select>

          <div className="h-6 w-px bg-border hidden sm:block mx-1"></div>
          <span className="text-sm text-muted-foreground whitespace-nowrap hidden sm:inline">Sắp xếp:</span>
          <select
            className="text-sm bg-background border border-border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50"
            value={sortKey}
            onChange={(e) => setSortKey(e.target.value as any)}
          >
            <option value="">Mặc định</option>
            <option value="poNo">PO No.</option>
            <option value="qty">Sản lượng</option>
            <option value="completeDate">Ngày hoàn thành</option>
            <option value="keepAeration">Thời gian sục</option>
          </select>
          <Button
            variant="outline"
            size="sm"
            className="h-[38px] px-3 font-mono"
            onClick={() => setSortOrder(prev => prev === "asc" ? "desc" : "asc")}
            title={sortOrder === "asc" ? "Tăng dần" : "Giảm dần"}
          >
            {sortOrder === "asc" ? "ASC" : "DESC"}
          </Button>

          <div className="h-6 w-px bg-border hidden sm:block mx-1"></div>
          <div className="flex items-center gap-1.5 px-2">
            <input
              type="checkbox"
              id="hideKeepZero"
              className="w-4 h-4 rounded border-border accent-primary cursor-pointer"
              checked={hideKeepZero}
              onChange={(e) => setHideKeepZero(e.target.checked)}
            />
            <label htmlFor="hideKeepZero" className="text-sm cursor-pointer whitespace-nowrap text-muted-foreground select-none">
              Ẩn Keep 0 day
            </label>
          </div>

          <div className="h-6 w-px bg-border hidden sm:block mx-1"></div>
          <Button
            variant="ghost"
            size="sm"
            className="h-[38px] px-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
            onClick={handleResetFilter}
            title="Delete bộ lọc"
          >
            <RiFilterOffLine className="h-4 w-4 mr-1" />
            Delete lọc
          </Button>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-muted/40 border-b border-border text-xs text-muted-foreground">
                <th className="px-3 py-2 font-medium w-10 text-center">STT</th>
                {/* <th className="px-3 py-2 font-medium">PO / TT</th> */}
                <th className="px-3 py-2 font-medium">Lô Sản Xuất</th>
                <th className="px-3 py-2 font-medium">Sản phẩm</th>
                <th className="px-3 py-2 font-medium">Phân loại & Đích</th>
                <th className="px-3 py-2 font-medium">Sản lượng</th>
                <th className="px-3 py-2 font-medium">Lịch trình & Thời gian</th>
                <th className="px-3 py-2 font-medium">Kiểm tra (Tests)</th>
                <th className="px-3 py-2 font-medium">Tiến độ SX</th>
                <th className="px-3 py-2 font-medium">Status</th>
                <th className="px-3 py-2 font-medium sticky right-0 bg-muted/40 shadow-[-4px_0_10px_-4px_rgba(0,0,0,0.1)] z-10 text-center w-12">
                  <input
                    type="checkbox"
                    className="w-4 h-4 rounded border-border accent-primary cursor-pointer"
                    checked={isAllSelected}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    title="Select All"
                  />
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, idx) => (
                  <tr key={idx} className="hover:bg-muted/20 transition-colors">
                    <td className="px-3 py-2 text-center">
                      <Skeleton className="h-4 w-4 mx-auto" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-20 mb-1" />
                      <Skeleton className="h-3 w-16" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-16 mb-1" />
                      <Skeleton className="h-3 w-20" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-32 mb-1" />
                      <Skeleton className="h-3 w-40 mb-1" />
                      <Skeleton className="h-3 w-48" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-16 mb-1" />
                      <Skeleton className="h-3 w-12 mb-1" />
                      <Skeleton className="h-3 w-20" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-12 mb-1" />
                      <Skeleton className="h-3 w-8" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-32 mb-1" />
                      <Skeleton className="h-3 w-40" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-24 mb-1" />
                      <Skeleton className="h-3 w-32" />
                    </td>
                    <td className="px-3 py-2">
                      <Skeleton className="h-4 w-40 mb-1" />
                      <Skeleton className="h-3 w-48 mb-1" />
                      <Skeleton className="h-3 w-32" />
                    </td>
                    <td className="px-3 py-2 text-center">
                      <Skeleton className="h-5 w-20 mx-auto rounded-full" />
                    </td>
                    <td className="px-3 py-2 sticky right-0 bg-card border-l border-border/50 z-10 text-center">
                      <Skeleton className="h-4 w-4 mx-auto rounded" />
                    </td>
                  </tr>
                ))
              ) : filteredAndSortedPlans.length > 0 ? (
                filteredAndSortedPlans.map((plan, idx) => (
                  <tr key={idx} className="hover:bg-muted/20 transition-colors">
                    {/* STT */}
                    <td className="px-3 py-2 text-center text-xs text-muted-foreground font-mono">
                      {idx + 1}
                    </td>

                    {/* Lô Sản Xuất */}
                    <td className="px-3 py-2">
                      <div className="font-mono text-xs">{plan.internalLot || "-"}</div>
                      {plan.externalLot1 && <div className="text-[10px] text-muted-foreground font-mono">Ext: {plan.externalLot1}</div>}
                    </td>

                    {/* Sản phẩm */}
                    <td className="px-3 py-2">
                      <div className="font-medium max-w-[200px] truncate text-xs" title={plan.itemName}>
                        {plan.itemName || "-"}
                      </div>
                      <div className="text-[10px] text-muted-foreground truncate max-w-[200px]" title={plan.material}>
                        Material: {plan.material}
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-muted-foreground font-mono mt-0.5">
                      </div>
                    </td>

                    {/* Phân loại & Đích */}
                    <td className="px-3 py-2">
                      {plan.destination && <div className="text-[10px] text-muted-foreground mt-0.5">Dest: {plan.destination}</div>}
                    </td>

                    {/* Sản lượng */}
                    <td className="px-3 py-2">
                      <div className="font-medium text-xs">Q'ty: {plan.qty ?? "-"}</div>
                      {plan.qtyInput != null && <div className="text-[10px] text-muted-foreground">Q'ty In: {plan.qtyInput}</div>}
                    </td>

                    {/* Lịch trình & Thời gian */}
                    <td className="px-3 py-2">
                      <div className="flex gap-3 text-[10px] text-muted-foreground mb-0.5">
                        {plan.keepStorage != null && <span title="Lưu kho">Keep: <span className="font-medium text-foreground">{plan.keepStorage} day</span></span>}
                      </div>
                      <div className="flex gap-3 text-[10px] text-muted-foreground">
                        <span title="Ngày dự kiến hoàn thành">HT: {plan.completeDate ? new Date(plan.completeDate).toLocaleDateString("vi-VN") : "-"}</span>
                        <span title="ETD">ETD: {plan.etd ? new Date(plan.etd).toLocaleDateString("vi-VN") : "-"}</span>
                      </div>
                    </td>

                    {/* Kiểm tra (Tests) */}
                    <td className="px-3 py-2">
                      <div className="flex gap-2 text-[10px] text-muted-foreground mb-0.5">
                        {plan.qaTest != null && <span>QA: <span className="text-foreground">{plan.qaTest}</span></span>}
                        {plan.bioburden && <span>Bio: <span className="text-foreground">{plan.bioburden}</span></span>}
                      </div>
                      <div className="flex gap-2 text-[10px] text-muted-foreground">
                        {/* {plan.testEndotoxin && <span>Endo: <span className="text-foreground">{plan.testEndotoxin}</span></span>} */}
                        {/* {plan.testParticle && <span>Part: <span className="text-foreground">{plan.testParticle}</span></span>} */}
                        {plan.qaTest == null && !plan.bioburden && !plan.testEndotoxin && !plan.testParticle && <span>-</span>}
                      </div>
                    </td>

                    {/* Tiến độ SX */}
                    <td className="px-3 py-2">
                      <div className="flex gap-2 text-[10px] text-muted-foreground mb-0.5">
                        {(plan.seal != null) && <span>Seal: <span className="text-foreground">{plan.seal ? new Date(plan.seal).toLocaleDateString("vi-VN") : ""}</span></span>}
                      </div>
                      <div className="flex gap-2 text-[10px] text-muted-foreground mb-0.5">
                        {plan.ster && <span>Ster: <span className="text-foreground">{new Date(plan.ster).toLocaleDateString("vi-VN")}</span></span>}
                        {(plan.boxing || plan.boxingData != null) }
                      </div>
                      <div className="flex gap-2 text-[10px] text-muted-foreground">
                        {plan.me && <span>ME: <span className="text-foreground">{plan.me}</span></span>}
                        {plan.meChia && <span>ME Chia: <span className="text-foreground">{plan.meChia}</span></span>}
                        {!plan.label && !plan.seal && !plan.ster && !plan.boxing && !plan.me && <span>-</span>}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="px-3 py-2 text-center">
                      {(() => {
                        const statusDesc = plan.statusDescription || plan.StatusDescription || "";
                        const colorConfig = PLAN_STATUS_COLORS[statusDesc] || DEFAULT_STATUS_COLOR;
                        const translatedDesc = PLAN_STATUS_TRANSLATIONS[statusDesc] || statusDesc || "Không xác định";

                        return (
                          <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[10px] font-medium border ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}>
                            <span className={`h-1 w-1 rounded-full ${colorConfig.dot}`} />
                            {translatedDesc}
                          </span>
                        );
                      })()}
                    </td>

                    {/* Actions */}
                    <td className="px-3 py-2 sticky right-0 bg-card shadow-[-4px_0_10px_-4px_rgba(0,0,0,0.1)] text-center border-l border-border/50 z-10">
                      <input
                        type="checkbox"
                        className="w-4 h-4 rounded border-border accent-primary cursor-pointer"
                        checked={selectedPlanIds.includes(getPlanId(plan))}
                        onChange={(e) => handleSelectPlan(getPlanId(plan), e.target.checked)}
                      />
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={10} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    Không có kế hoạch nào.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Sync Confirmation Modal */}
      {isSyncModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-card p-6 rounded-xl border border-border shadow-lg w-full max-w-md mx-4 animate-in fade-in zoom-in-95 duration-200">
            <h3 className="text-lg font-semibold mb-2">Xác nhận đồng bộ</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Bạn có chắc chắn muốn đồng bộ dữ liệu kế hoạch mới nhất từ hệ thống máy chủ không? Quá trình này có thể mất một chút thời gian.
            </p>
            <div className="flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={() => setIsSyncModalOpen(false)}
                disabled={isSyncing}
              >
                Cancel bỏ
              </Button>
              <Button
                onClick={() => {
                  setIsSyncModalOpen(false);
                  syncPlans(undefined, {
                    onSuccess: () => {
                      toast.success("Sync dữ liệu thành công!");
                    },
                    onError: () => {
                      toast.error("Sync dữ liệu thất bại!");
                    }
                  });
                }}
                disabled={isSyncing}
                className="gap-2"
              >
                {isSyncing && <RiRefreshLine className="h-4 w-4 animate-spin" />}
                Đồng ý đồng bộ
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Alert Dialog */}
      <AlertDialog open={alertInfo.isOpen} onOpenChange={(open) => setAlertInfo(prev => ({ ...prev, isOpen: open }))}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Warnings tạo kế hoạch</AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              {alertInfo.unselectedCount > 0 && (
                <p>
                  - Vẫn còn <span className="font-bold text-foreground">{alertInfo.unselectedCount}</span> lô trùng cùng ngày Ster và ME Chia chưa được chọn.
                </p>
              )}
              {alertInfo.alreadyCreatedCount > 0 && (
                <p>
                  - Có <span className="font-bold text-foreground">{alertInfo.alreadyCreatedCount}</span> lô đang chọn đã được tạo kế hoạch trước đó.
                </p>
              )}
              {/* <p className="pt-2">Bạn có chắc chắn muốn tiếp tục tạo (hoặc tạo lại) kế hoạch không?</p> */}
               <p className="pt-2"><b>Bạn cần sửa lại dữ liệu Database và đồng bộ lại.</b></p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel bỏ</AlertDialogCancel>
            {/* <AlertDialogAction onClick={() => setIsCreateModalOpen(true)}>
              Tiếp tục tạo
            </AlertDialogAction> */}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <CreatePlanModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        selectedPlans={plans.filter(p => selectedPlanIds.includes(getPlanId(p)))}
        isCreating={isCreatingPlan}
        onConfirm={(_testConfig) => {
          // TODO: pass testConfig to API when supported
          executeCreatePlan();
          setIsCreateModalOpen(false);
        }}
      />
    </div>
  )
}
