import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RiCloseLine, RiRefreshLine } from "@remixicon/react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import type { DataPlanDto } from "../types/plans.types";

export interface TestConfig {
  beforeEndoLot: string[];
  beforeParticleLot: string[];
  afterEndoLot: string[];
  afterParticleLot: string[];
  qtyTest: string;
}

interface CreatePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlans: DataPlanDto[];
  onConfirm: (config: TestConfig) => void;
  isCreating: boolean;
}

interface MultiLotSelectProps {
  lots: string[];
  value: string[];
  onChange: (value: string[]) => void;
  disabled?: boolean;
}

function MultiLotSelect({ lots, value, onChange, disabled }: MultiLotSelectProps) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          disabled={disabled}
          className="h-auto min-h-9 w-full justify-start overflow-hidden px-2 py-1.5 text-left font-normal"
        >
          <span className={value.length === 0 ? "text-muted-foreground" : "truncate"}>
            {value.length > 0 ? value.join(", ") : "Chọn Lot..."}
          </span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-1" align="start">
        <div className="max-h-48 overflow-y-auto">
          {lots.map(lot => {
            const isSelected = value.includes(lot);

            return (
              <label
                key={lot}
                className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-muted"
              >
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-border accent-primary"
                  checked={isSelected}
                  onChange={() => {
                    onChange(
                      isSelected ? value.filter(selectedLot => selectedLot !== lot) : [...value, lot]
                    );
                  }}
                />
                <span className="truncate">{lot}</span>
              </label>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}

export function CreatePlanModal({
  isOpen,
  onClose,
  selectedPlans,
  onConfirm,
  isCreating
}: CreatePlanModalProps) {
  const [testConfig, setTestConfig] = useState<TestConfig>({
    beforeEndoLot: [],
    beforeParticleLot: [],
    afterEndoLot: [],
    afterParticleLot: [],
    qtyTest: ""
  });

  useEffect(() => {
    const selectedLotsForTest = new Set([
      ...testConfig.beforeEndoLot,
      ...testConfig.beforeParticleLot,
      ...testConfig.afterEndoLot,
      ...testConfig.afterParticleLot
    ]);
    let totalQty = 0;
    selectedLotsForTest.forEach(lotId => {
      const p = selectedPlans.find(plan => plan.internalLot === lotId);
      if (p && p.qtyInput) {
        totalQty += p.qtyInput;
      }
    });

    setTestConfig(prev => ({ ...prev, qtyTest: totalQty > 0 ? totalQty.toString() : "" }));
  }, [testConfig.beforeEndoLot, testConfig.afterEndoLot, testConfig.beforeParticleLot, testConfig.afterParticleLot, selectedPlans]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-card p-6 rounded-xl border border-border shadow-lg w-full max-w-3xl mx-4 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold tracking-tight">Tạo kế hoạch mới</h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <RiCloseLine className="h-5 w-5" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Table 1: Selected Lots */}
          <div>
            <h4 className="text-sm font-semibold mb-2">Danh sách Lot đã chọn</h4>
            <div className="border border-border rounded-lg overflow-hidden">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="bg-muted/40 text-muted-foreground text-xs">
                  <tr>
                    <th className="px-3 py-2 font-medium">Lô Sản Xuất (Lot)</th>
                    <th className="px-3 py-2 font-medium">Q'ty Input</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/60">
                  {selectedPlans.map((plan, idx) => (
                    <tr key={idx} className="hover:bg-muted/10">
                      <td className="px-3 py-2 font-mono">{plan.internalLot || "-"}</td>
                      <td className="px-3 py-2">{plan.qtyInput ?? "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table 2: Test Configuration */}
          <div>
            <h4 className="text-sm font-semibold mb-2">Cấu hình test</h4>
            <div className="border border-border rounded-lg overflow-hidden">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="bg-muted/40 text-muted-foreground text-xs">
                  <tr>
                    <th className="px-3 py-2 font-medium border-b border-r border-border/60">Thời điểm test</th>
                    <th className="px-3 py-2 font-medium border-b border-r border-border/60">Lot test Endotoxin</th>
                    <th className="px-3 py-2 font-medium border-b border-r border-border/60">Lot test particle</th>
                    <th className="px-3 py-2 font-medium border-b border-border/60 w-32 text-center">Q'ty test</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/60">
                  <tr>
                    <td className="px-3 py-2 font-medium border-r border-border/60 bg-muted/10">Trước khử trùng</td>
                    <td className="px-2 py-1.5 border-r border-border/60">
                      <MultiLotSelect
                        lots={selectedPlans.flatMap(plan => plan.internalLot ? [plan.internalLot] : [])}
                        value={testConfig.beforeEndoLot}
                        onChange={(value) => setTestConfig(p => ({ ...p, beforeEndoLot: value }))}
                        disabled={testConfig.afterEndoLot.length > 0}
                      />
                    </td>
                    <td className="px-2 py-1.5 border-r border-border/60">
                      <MultiLotSelect
                        lots={selectedPlans.flatMap(plan => plan.internalLot ? [plan.internalLot] : [])}
                        value={testConfig.beforeParticleLot}
                        onChange={(value) => setTestConfig(p => ({ ...p, beforeParticleLot: value }))}
                        disabled={testConfig.afterParticleLot.length > 0}
                      />
                    </td>
                    <td className="px-2 py-1.5 align-middle bg-muted/5" rowSpan={2}>
                      <div className="flex items-center gap-2 justify-center">
                        <input
                          type="number"
                          className="w-16 text-sm bg-background border border-border rounded-md px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary/50 text-center"
                          value={testConfig.qtyTest}
                          onChange={(e) => setTestConfig(p => ({ ...p, qtyTest: e.target.value }))}
                          placeholder="0"
                          min="0"
                        />
                        <span className="text-muted-foreground text-xs font-medium">pcs</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 font-medium border-r border-border/60 bg-muted/10">Sau khử trùng</td>
                    <td className="px-2 py-1.5 border-r border-border/60">
                      <MultiLotSelect
                        lots={selectedPlans.flatMap(plan => plan.internalLot ? [plan.internalLot] : [])}
                        value={testConfig.afterEndoLot}
                        onChange={(value) => setTestConfig(p => ({ ...p, afterEndoLot: value }))}
                        disabled={testConfig.beforeEndoLot.length > 0}
                      />
                    </td>
                    <td className="px-2 py-1.5 border-r border-border/60">
                      <MultiLotSelect
                        lots={selectedPlans.flatMap(plan => plan.internalLot ? [plan.internalLot] : [])}
                        value={testConfig.afterParticleLot}
                        onChange={(value) => setTestConfig(p => ({ ...p, afterParticleLot: value }))}
                        disabled={testConfig.beforeParticleLot.length > 0}
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-border">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isCreating}
          >
            Cancel bỏ
          </Button>
          <Button
            onClick={() => onConfirm(testConfig)}
            disabled={isCreating}
            className="gap-2"
          >
            {isCreating ? (
              <>
                <RiRefreshLine className="h-4 w-4 animate-spin" />
                Đang tạo...
              </>
            ) : "Xác nhận tạo kế hoạch"}
          </Button>
        </div>
      </div>
    </div>
  );
}
