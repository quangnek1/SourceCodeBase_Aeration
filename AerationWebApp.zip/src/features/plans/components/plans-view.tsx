import { Button } from "@/components/ui/button"
import { usePlans } from "@/hooks/use-queries"
import {
  RiAddLine,
  RiStackLine,
  RiDatabaseLine,
  RiCalendarEventLine,
} from "@remixicon/react"

export function PlansView() {
  const { data: plans = [] } = usePlans()

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">Kế hoạch & Quy trình</h1>
          <p className="text-sm text-muted-foreground">Xây dựng mẫu quy trình vận hành tự động (quy trình sục khí nhiều bước, xông hơi thuốc khử trùng).</p>
        </div>
        <Button className="gap-1.5 self-start sm:self-auto">
          <RiAddLine className="h-5 w-5" /> Tạo kế hoạch mới
        </Button>
      </div>

      <div className="space-y-4">
        {plans.map((plan, idx) => {
          const planId = plan.poNo || `PLAN-00${idx + 1}`
          const name = plan.itemName || `Quy trình sấy & sục khí ${plan.material}`

          return (
            <div key={idx} className="rounded-xl border border-border bg-card p-5 shadow-xs hover:border-primary/40 transition-colors flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-semibold text-muted-foreground bg-muted px-2 py-0.5 rounded-md">{planId}</span>
                  <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase border bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20">
                    Đang áp dụng
                  </span>
                </div>
                <h3 className="font-semibold text-base text-foreground">{name}</h3>
                <div className="flex flex-wrap items-center gap-x-6 gap-y-1.5 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><RiStackLine className="h-4 w-4" /> <strong>Sản phẩm:</strong> {plan.material}</span>
                  <span className="flex items-center gap-1"><RiDatabaseLine className="h-4 w-4" /> <strong>Sản lượng:</strong> {plan.qty || 15} Tấn</span>
                  <span className="flex items-center gap-1"><RiCalendarEventLine className="h-4 w-4" /> <strong>Thời gian sục:</strong> {plan.keepAeration} giờ</span>
                </div>
              </div>
              
              <div className="flex items-center gap-2 border-t border-border/50 pt-3 md:border-none md:pt-0 shrink-0 self-end md:self-auto">
                <Button variant="outline" size="sm">Cấu hình bước</Button>
                <Button variant="outline" size="sm">Nhân bản</Button>
                <Button size="sm">Áp dụng</Button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
