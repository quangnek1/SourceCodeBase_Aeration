import { Button } from "@/components/ui/button";
import { RiRefreshLine, RiDatabase2Line, RiShieldCheckLine } from "@remixicon/react";
import { toast } from "sonner";
import { useAmiQ411Data } from "../hooks/useAmiQ411Data";
import { useSyncAmiQ411 } from "../hooks/useSyncAmiQ411";

export function AmiQ411SyncComponent() {
  const { data: amiData = [], isLoading, isError, refetch } = useAmiQ411Data();
  const { mutate: syncAmiQ411, isPending: isSyncing } = useSyncAmiQ411();

  const handleSyncAmiQ411 = () => {
    syncAmiQ411(undefined, {
      onSuccess: () => {
        toast.success("Đồng bộ dữ liệu AMI Q411 thành công!");
        refetch();
      },
      onError: () => {
        toast.error("Đồng bộ dữ liệu AMI Q411 thất bại!");
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">AMI Q411</h1>
          <p className="text-sm text-muted-foreground">
            Đồng bộ dữ liệu kế hoạch AMI Q411 từ nguồn dữ liệu hệ thống ra cơ sở dữ liệu nội bộ.
          </p>
        </div>

        <Button
          className="gap-1.5 self-start sm:self-auto"
          onClick={handleSyncAmiQ411}
          disabled={isSyncing}
        >
          <RiRefreshLine className={`h-5 w-5 ${isSyncing ? "animate-spin" : ""}`} />
          {isSyncing ? "Đang đồng bộ..." : "Sync AMI Q411"}
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-muted/40 border-b border-border text-xs text-muted-foreground">
                <th className="px-3 py-2 font-medium">#</th>
                <th className="px-3 py-2 font-medium">Tên sản phẩm</th>
                <th className="px-3 py-2 font-medium">Thông tin sản phẩm</th>
                <th className="px-3 py-2 font-medium">Số Drawing</th>
                <th className="px-3 py-2 font-medium">Catalog</th>
                <th className="px-3 py-2 font-medium">Destination</th>
                <th className="px-3 py-2 font-medium">Chamber A</th>
                <th className="px-3 py-2 font-medium">Chamber B</th>
                <th className="px-3 py-2 font-medium">Chamber C</th>
                <th className="px-3 py-2 font-medium">Chamber D</th>
                <th className="px-3 py-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {isLoading ? (
                <tr>
                  <td colSpan={11} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    Đang tải dữ liệu AMI Q411...
                  </td>
                </tr>
              ) : isError ? (
                <tr>
                  <td colSpan={11} className="px-4 py-8 text-center text-destructive text-sm">
                    Không thể tải dữ liệu AMI Q411 từ API.
                  </td>
                </tr>
              ) : amiData.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    Chưa có dữ liệu AMI Q411.
                  </td>
                </tr>
              ) : (
                amiData.map((item, idx) => (
                  <tr key={item.id ?? idx} className="hover:bg-muted/20 transition-colors">
                    <td className="px-3 py-2 text-xs text-muted-foreground">{idx + 1}</td>
                    <td className="px-3 py-2 text-xs font-medium">{item.productName || "-"}</td>
                    <td className="px-3 py-2 text-xs">{item.productInformation || "-"}</td>
                    <td className="px-3 py-2 text-xs font-mono">{item.drawingNumber || "-"}</td>
                    <td className="px-3 py-2 text-xs font-mono">{item.catalogCode || "-"}</td>
                    <td className="px-3 py-2 text-xs">{item.destination || "-"}</td>
                    <td className="px-3 py-2 text-xs">{item.chamberA ?? "-"}</td>
                    <td className="px-3 py-2 text-xs">{item.chamberB ?? "-"}</td>
                    <td className="px-3 py-2 text-xs">{item.chamberC ?? "-"}</td>
                    <td className="px-3 py-2 text-xs">{item.chamberD ?? "-"}</td>
                    <td className="px-3 py-2 text-xs">
                      {item.status === true ? "Active" : item.status === false ? "Inactive" : "-"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
