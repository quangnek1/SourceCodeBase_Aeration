import { useState, useEffect, useCallback } from "react";
import { useSettings } from "@/hooks/useSettings";
import { Button } from "@/components/ui/button";
import { DataTablePagination } from "@/components/data-table-pagination";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import {
    RiFilterLine,
    RiSearchLine,
    RiLoader4Line,
    RiPrinterLine,
    RiFileTextLine,
    RiDeleteBinLine,
    RiCheckboxLine,
    RiCheckboxBlankLine,
} from "@remixicon/react";
import { toast } from "sonner";
import { batchesApi } from "@/features/batches/api/batches.api";
import { PdfModal } from "@/features/batches/components/modals/pdf-modal";
import { useDeleteBatch } from "@/features/batches/hooks/useDeleteBatch";
import type { BatchPrintPdfDto } from "@/features/batches/types/batches.types";
import {
    PLAN_STATUS_COLORS,
    PLAN_STATUS_TRANSLATIONS,
    DEFAULT_STATUS_COLOR,
} from "../types/plans.types";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function PlansPrint() {
    const { settings } = useSettings();
    const pageSize = settings.pageSize;

    const [pageIndex, setPageIndex] = useState(1);
    const [searchTerm, setSearchTerm] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [filterUnprinted, setFilterUnprinted] = useState(false);

    // Debounce search
    useEffect(() => {
        const t = setTimeout(() => setDebouncedSearch(searchTerm), 400);
        return () => clearTimeout(t);
    }, [searchTerm]);

    // Reset page khi filter thay đổi
    useEffect(() => { setPageIndex(1); }, [debouncedSearch, filterUnprinted]);

    const { data, isLoading, refetch } = useQuery({
        queryKey: ["batch-print", debouncedSearch, filterUnprinted, pageIndex, pageSize],
        queryFn: () => batchesApi.getBatchPrint(debouncedSearch || undefined, undefined, "Ascending", pageIndex, pageSize),
    });

    const batches = data?.value?.items || [];
    const pagination = data?.value;

    // Lọc chưa in ở client nếu backend không hỗ trợ filter print=0
    const displayedBatches = filterUnprinted
        ? batches.filter((b) => b.print === 0)
        : batches;

    // ─── Selection ──────────────────────────────────────────────
    const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

    const isAllSelected =
        displayedBatches.length > 0 &&
        displayedBatches.every((b) => selectedIds.has(b.id));

    const isIndeterminate =
        !isAllSelected && displayedBatches.some((b) => selectedIds.has(b.id));

    const toggleAll = useCallback(() => {
        if (isAllSelected) {
            setSelectedIds((prev) => {
                const next = new Set(prev);
                displayedBatches.forEach((b) => next.delete(b.id));
                return next;
            });
        } else {
            setSelectedIds((prev) => {
                const next = new Set(prev);
                displayedBatches.forEach((b) => next.add(b.id));
                return next;
            });
        }
    }, [isAllSelected, displayedBatches]);

    const toggleRow = useCallback((id: number) => {
        setSelectedIds((prev) => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    }, []);

    // Clear selection khi đổi trang / filter
    useEffect(() => { setSelectedIds(new Set()); }, [pageIndex, debouncedSearch, filterUnprinted]);

    // ─── PDF: In 1 mẻ ───────────────────────────────────────────
    const [pdfModalOpen, setPdfModalOpen] = useState(false);
    const [pdfUrl, setPdfUrl] = useState<string | null>(null);
    const [isGeneratingPdf, setIsGeneratingPdf] = useState<number | null>(null);

    const handlePrintSingle = async (batch: BatchPrintPdfDto) => {
        setIsGeneratingPdf(batch.id);
        try {
            const blob = await batchesApi.printAllBatchPdf([batch.id]);
            const url = URL.createObjectURL(blob);
            setPdfUrl(url);
            setPdfModalOpen(true);
            refetch();
        } catch {
            toast.error("Không thể tải file PDF");
        } finally {
            setIsGeneratingPdf(null);
        }
    };

    // ─── PDF: In nhiều mẻ ───────────────────────────────────────
    const [isPrintingAll, setIsPrintingAll] = useState(false);

    const handlePrintSelected = async () => {
        if (selectedIds.size === 0) {
            toast.warning("Vui lòng chọn ít nhất 1 lô để in");
            return;
        }
        setIsPrintingAll(true);
        try {
            const blob = await batchesApi.printAllBatchPdf(Array.from(selectedIds));
            const url = URL.createObjectURL(blob);
            setPdfUrl(url);
            setPdfModalOpen(true);
            refetch();
        } catch {
            toast.error("Không thể tạo file PDF");
        } finally {
            setIsPrintingAll(false);
        }
    };

    // ─── Delete ──────────────────────────────────────────────────
    const [batchToDelete, setBatchToDelete] = useState<BatchPrintPdfDto | null>(null);
    const deleteBatchMutation = useDeleteBatch();

    const handleDelete = () => {
        if (batchToDelete) {
            deleteBatchMutation.mutate(batchToDelete.id, {
                onSuccess: () => {
                    setBatchToDelete(null);
                    refetch();
                },
            });
        }
    };

    return (
        <div className="space-y-6">
            {/* Page Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
                        <RiFileTextLine className="h-6 w-6 text-primary" />
                        In phiếu F-6112
                    </h2>
                    <p className="text-sm text-muted-foreground mt-1">
                        Chọn lô hàng để in phiếu PDF hoặc xóa lô
                    </p>
                </div>

                {/* Print Selected button */}
                <Button
                    className="gap-2 shadow-sm bg-indigo-600 hover:bg-indigo-700 text-white"
                    onClick={handlePrintSelected}
                    disabled={isPrintingAll || selectedIds.size === 0}
                >
                    {isPrintingAll ? (
                        <RiLoader4Line className="h-4 w-4 animate-spin" />
                    ) : (
                        <RiPrinterLine className="h-4 w-4" />
                    )}
                    In {selectedIds.size > 0 ? `${selectedIds.size} ` : ""}PDF
                </Button>
            </div>

            {/* Toolbar / Filters */}
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-card p-3 rounded-xl border border-border shadow-xs">
                <div className="relative w-full sm:max-w-xs">
                    <RiSearchLine className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Tìm số lô..."
                        className="w-full pl-10 pr-4 py-2 border border-border rounded-lg text-sm bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                    />
                </div>
                <div className="flex items-center gap-2">
                    <Button
                        variant={filterUnprinted ? "default" : "outline"}
                        size="sm"
                        className="gap-1.5 text-xs"
                        onClick={() => setFilterUnprinted((v) => !v)}
                    >
                        <RiFilterLine className="h-4 w-4" />
                        {filterUnprinted ? "Chưa in (đang lọc)" : "Lọc chưa in"}
                    </Button>
                    <span className="text-xs text-muted-foreground">
                        Tổng {pagination?.totalCount || batches.length} kết quả
                        {selectedIds.size > 0 && (
                            <span className="ml-1 text-indigo-600 font-medium">
                                · Đã chọn {selectedIds.size}
                            </span>
                        )}
                    </span>
                </div>
            </div>

            {/* Table */}
            <div className="bg-card rounded-xl border border-border shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm border-collapse">
                        <thead>
                            <tr className="bg-muted/40 border-b border-border text-xs text-muted-foreground">
                                {/* Checkbox select-all */}
                                <th className="px-3 py-2 w-10">
                                    <button
                                        onClick={toggleAll}
                                        className="flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                                        title={isAllSelected ? "Bỏ chọn tất cả" : "Chọn tất cả"}
                                    >
                                        {isAllSelected ? (
                                            <RiCheckboxLine className="h-4 w-4 text-indigo-600" />
                                        ) : isIndeterminate ? (
                                            <RiCheckboxLine className="h-4 w-4 text-indigo-400" />
                                        ) : (
                                            <RiCheckboxBlankLine className="h-4 w-4" />
                                        )}
                                    </button>
                                </th>
                                <th className="px-3 py-2 font-medium">Số lô</th>
                                <th className="px-3 py-2 font-medium">Ngày tiệt trùng</th>
                                <th className="px-3 py-2 font-medium">Ngày tạo</th>
                                <th className="px-3 py-2 font-medium text-center">Keep</th>
                                <th className="px-3 py-2 font-medium text-center">Đã in</th>
                                <th className="px-3 py-2 font-medium">Trạng thái</th>
                                <th className="px-3 py-2 font-medium text-right">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border/60">
                            {isLoading ? (
                                Array.from({ length: 5 }).map((_, idx) => (
                                    <tr key={idx} className="hover:bg-muted/20 transition-colors">
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-4" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-32" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-24" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-24" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-10 mx-auto" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-10 mx-auto" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-5 w-24 rounded-full" /></td>
                                        <td className="px-3 py-2">
                                            <div className="flex justify-end gap-1.5">
                                                <Skeleton className="h-8 w-16 rounded-md" />
                                                <Skeleton className="h-8 w-8 rounded-md" />
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            ) : displayedBatches.length > 0 ? (
                                displayedBatches.map((batch) => {
                                    const statusDesc = batch.status || "";
                                    const colorConfig = PLAN_STATUS_COLORS[statusDesc] || DEFAULT_STATUS_COLOR;
                                    const translatedDesc = PLAN_STATUS_TRANSLATIONS[statusDesc] || statusDesc || "—";
                                    const isSelected = selectedIds.has(batch.id);
                                    const isPrinted = batch.print > 0;

                                    return (
                                        <tr
                                            key={batch.id}
                                            className={`hover:bg-muted/20 transition-colors cursor-pointer ${isSelected ? "bg-indigo-50/60 dark:bg-indigo-950/20" : ""}`}
                                            onClick={() => toggleRow(batch.id)}
                                        >
                                            {/* Checkbox */}
                                            <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
                                                <button
                                                    onClick={() => toggleRow(batch.id)}
                                                    className="flex items-center justify-center"
                                                >
                                                    {isSelected ? (
                                                        <RiCheckboxLine className="h-4 w-4 text-indigo-600" />
                                                    ) : (
                                                        <RiCheckboxBlankLine className="h-4 w-4 text-muted-foreground" />
                                                    )}
                                                </button>
                                            </td>
                                            <td className="px-3 py-2 font-medium">{batch.batchNo}</td>
                                            <td className="px-3 py-2 text-muted-foreground text-xs">{batch.sterilizeDate}</td>
                                            <td className="px-3 py-2 text-muted-foreground text-xs">{batch.createdDate}</td>
                                            <td className="px-3 py-2 text-center font-mono text-xs">{batch.keep}</td>
                                            <td className="px-3 py-2 text-center">
                                                <span
                                                    className={`inline-flex items-center justify-center rounded-full px-2 py-0.5 text-[11px] font-medium ${isPrinted ? "bg-green-50 text-green-700 border border-green-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`}
                                                >
                                                    {isPrinted ? `✓ ${batch.print}` : "Chưa in"}
                                                </span>
                                            </td>
                                            <td className="px-3 py-2">
                                                <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium border ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}>
                                                    <span className={`h-1.5 w-1.5 rounded-full ${colorConfig.dot}`} />
                                                    {translatedDesc}
                                                </span>
                                            </td>
                                            <td
                                                className="px-3 py-2 text-right"
                                                onClick={(e) => e.stopPropagation()}
                                            >
                                                <div className="flex items-center justify-end gap-1.5">
                                                    {/* Print PDF đơn */}
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        className="h-8 px-3 gap-1.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border-indigo-200"
                                                        title="In phiếu PDF"
                                                        onClick={() => handlePrintSingle(batch)}
                                                        disabled={isGeneratingPdf === batch.id}
                                                    >
                                                        {isGeneratingPdf === batch.id ? (
                                                            <RiLoader4Line className="h-4 w-4 animate-spin" />
                                                        ) : (
                                                            <RiPrinterLine className="h-4 w-4" />
                                                        )}
                                                        <span className="text-xs hidden sm:inline">In PDF</span>
                                                    </Button>

                                                    {/* Delete */}
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        className="h-8 px-2 text-red-500 hover:text-red-600 hover:bg-red-500/10"
                                                        title="Xóa lô hàng"
                                                        onClick={() => setBatchToDelete(batch)}
                                                        disabled={deleteBatchMutation.isPending}
                                                    >
                                                        <RiDeleteBinLine className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })
                            ) : (
                                <tr>
                                    <td colSpan={8} className="px-4 py-10 text-center text-muted-foreground text-sm">
                                        {filterUnprinted ? "Không có lô nào chưa in." : "Không có dữ liệu lô hàng."}
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                {pagination && (
                    <DataTablePagination
                        pageIndex={pageIndex}
                        pageSize={pageSize}
                        totalCount={pagination.totalCount}
                        totalPages={pagination.totalPages}
                        onPageChange={setPageIndex}
                    />
                )}
            </div>

            {/* PDF Viewer Modal (dùng chung cho in 1 và in nhiều) */}
            <PdfModal
                isOpen={pdfModalOpen}
                onClose={() => {
                    setPdfModalOpen(false);
                    setSelectedIds(new Set());
                }}
                pdfUrl={pdfUrl}
            />

            {/* Delete Confirmation */}
            <AlertDialog
                open={!!batchToDelete}
                onOpenChange={(open) => !open && setBatchToDelete(null)}
            >
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Xác nhận xóa lô hàng</AlertDialogTitle>
                        <AlertDialogDescription>
                            Bạn có chắc muốn xóa lô{" "}
                            <span className="font-bold text-foreground">{batchToDelete?.batchNo}</span>?
                            Thao tác này không thể hoàn tác và toàn bộ dữ liệu liên quan sẽ bị xóa.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel disabled={deleteBatchMutation.isPending}>Hủy</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={(e) => { e.preventDefault(); handleDelete(); }}
                            className="bg-red-500 text-white hover:bg-red-600 focus:ring-red-500"
                            disabled={deleteBatchMutation.isPending}
                        >
                            {deleteBatchMutation.isPending ? "Đang xóa..." : "Xóa lô hàng"}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
