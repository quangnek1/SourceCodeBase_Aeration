import { useQuery } from "@tanstack/react-query";
import { plansApi } from "../api/plans.api";

export function usePlans(filter?: string) {
    return useQuery({
        queryKey: ["plans", filter],
        queryFn: async () => {
            const response = await plansApi.getDataPlan(filter);

            return response.value;
        },
    });
}