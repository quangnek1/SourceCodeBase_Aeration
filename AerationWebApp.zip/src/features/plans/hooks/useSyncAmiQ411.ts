import { useMutation, useQueryClient } from "@tanstack/react-query";
import { plansApi } from "../api/plans.api";

export function useSyncAmiQ411() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      const response = await plansApi.syncDataAmiQ411();
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["plans"] });
    },
  });
}
