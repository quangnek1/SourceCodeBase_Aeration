import { useQuery } from "@tanstack/react-query";
import { plansApi } from "../api/plans.api";

export interface AmiQ411Item {
  id: number;
  productName: string;
  productInformation: string;
  drawingNumber: string;
  catalogCode: string;
  destination: string;
  chamberA?: number | null;
  chamberB?: number | null;
  chamberC?: number | null;
  chamberD?: number | null;
  status?: boolean | null;
}

export function useAmiQ411Data(filter?: string) {
  return useQuery({
    queryKey: ["ami-q411", filter],
    queryFn: async () => {
      const response = await plansApi.getDataAmiQ411(filter);
      return response.value as AmiQ411Item[];
    },
  });
}
