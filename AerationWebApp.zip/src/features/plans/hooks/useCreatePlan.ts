import { useMutation, useQueryClient } from "@tanstack/react-query";
import { plansApi } from "../api/plans.api";
import { toast } from "sonner";
import type { CreateF6112Command } from "../types/plans.types";

export const useCreatePlan = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (command: CreateF6112Command) => plansApi.createF6112(command),
        onSuccess: () => {
            toast.success("Tạo kế hoạch mới thành công!");
            queryClient.invalidateQueries({ queryKey: ["plans"] });
        },
        onError: (error: any) => {
            toast.error(error?.response?.data?.message || "Error khi tạo kế hoạch");
        },
    });
};
