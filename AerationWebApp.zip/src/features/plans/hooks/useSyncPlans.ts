import { useMutation, useQueryClient } from "@tanstack/react-query";
import { plansApi } from "../api/plans.api";

export function useSyncPlans() {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async () => {
            const response = await plansApi.syncDataPlan();
            return response;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["plans"] });
        }
    });
}
