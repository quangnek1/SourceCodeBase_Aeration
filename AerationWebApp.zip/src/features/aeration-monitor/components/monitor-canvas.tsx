import type { MonitorAerationColumnDto } from "../types/aeration-monitor.types";
import { MonitorSlot } from "./monitor-slot";

interface MonitorCanvasProps {
    columns: MonitorAerationColumnDto[];
}

export function MonitorCanvas({ columns }: MonitorCanvasProps) {
    // Kích thước chuẩn
    const SL_W = 195;
    const SL_H = 75;
    
    // Shrink-wrapped layout to maximize scale size on screen
    const PAD_TOP_HG = 32;      // Header Y will be 32 - 32 = 0
    const PAD_TOP_ABCDE = 364;  // Header Y will be 364 - 32 = 332

    // Hardcode X coordinates shifted left by 100px to remove empty left padding
    const COL_X_MAP: Record<string, number> = {
        "H": 0,                                      
        "G": 0 + SL_W + 60, // 255
        "E": 255 + SL_W + 100 + 60, // 610 (G dog-leg adds 100)
        "D": 610 + SL_W + 20, // 825
        "C": 825 + SL_W + 60, // 1080
        "B": 1080 + SL_W + 20, // 1295
        "A": 1295 + SL_W + 60 // 1550
    };

    const safeColumns = Array.isArray(columns) ? columns : [];
    
    // Tính toán lại layout thành list object
    const slotsToRender: React.ReactNode[] = [];
    const laneHeaders: React.ReactNode[] = [];
    
    safeColumns.forEach((col) => {
        const colName = col.columnName || "";
        if (!(colName in COL_X_MAP)) return; // Skip unknown columns

        const currentX = COL_X_MAP[colName];
        const positions = col.aerationPositionDtos || [];
        const isHG = colName === "H" || colName === "G";
        const topY = isHG ? PAD_TOP_HG : PAD_TOP_ABCDE;

        // Vẽ Lane Header
        laneHeaders.push(
            <div
                key={`header-${col.id}`}
                className="absolute flex items-center justify-center bg-slate-800 text-white font-bold rounded-t-md shadow-sm ring-1 ring-slate-900/10"
                style={{
                    left: `${currentX}px`,
                    top: `${topY - 32}px`,
                    width: `${SL_W}px`,
                    height: `32px`,
                    fontSize: "15px",
                    letterSpacing: "0.2em"
                }}
            >
                {col.columnName}
            </div>
        );

        // Vẽ từng Slot dựa trên chỉ số thật của nó thay vì index trong mảng
        positions.forEach((pos) => {
            // Parse "G3" -> 3 -> rowIndex 2
            const numMatch = pos.positionCode?.match(/\d+/);
            const rowIndex = numMatch ? parseInt(numMatch[0], 10) - 1 : 0;
            
            let slotX = currentX;
            let slotY = topY + rowIndex * SL_H;

            if (colName === "G" && rowIndex > 5) {
                // G7-G13 nằm dưới G6 và lệch sang một chút (dog-leg)
                slotX += 100;
                // Y vẫn tiếp tục tăng dần bình thường
            }

            slotsToRender.push(
                <MonitorSlot
                    key={pos.id}
                    slot={pos}
                    x={slotX}
                    y={slotY}
                    w={SL_W}
                    h={SL_H - 10}
                />
            );
        });
    });

    return (
        <div 
            className="relative" 
            style={{ width: "1750px", height: "1000px" }} // Shrink-wrapped canvas size to naturally maximize scale
        >
            {laneHeaders}
            {slotsToRender}
        </div>
    );
}
