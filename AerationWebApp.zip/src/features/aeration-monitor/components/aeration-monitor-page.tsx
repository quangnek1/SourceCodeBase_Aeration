import { useState, useRef, useEffect } from "react";
import { useAerationMonitorData } from "../hooks/useAerationMonitorData";
import { useSignalRAeration } from "../hooks/useSignalRAeration";
import { MonitorCanvas } from "./monitor-canvas";
import { MonitorLegend } from "./monitor-legend";
import { RiLoader4Line, RiFullscreenLine, RiFullscreenExitLine, RiRefreshLine, RiWifiOffLine } from "@remixicon/react";
import { Button } from "@/components/ui/button";
import { TooltipProvider } from "@/components/ui/tooltip";

export function AerationMonitorPage() {
    const { data: initialData, isLoading, refetch, isFetching } = useAerationMonitorData();
    const { isConnected, liveData } = useSignalRAeration();
    const [isFullscreen, setIsFullscreen] = useState(false);

    // Nếu có liveData từ SignalR thì ưu tiên dùng liveData, nếu không thì dùng data từ API
    const columns = liveData || initialData;

    const containerRef = useRef<HTMLDivElement>(null);
    const bodyRef = useRef<HTMLDivElement>(null);
    const [scale, setScale] = useState(1);

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            containerRef.current?.requestFullscreen();
            setIsFullscreen(true);
        } else {
            document.exitFullscreen();
            setIsFullscreen(false);
        }
    };

    // Calculate scale to fit exactly inside the screen, listening to container changes
    useEffect(() => {
        if (isLoading || !bodyRef.current) return;

        const calculateScale = () => {
            if (bodyRef.current) {
                const rect = bodyRef.current.getBoundingClientRect();
                const CANVAS_WIDTH = 1750;
                const CANVAS_HEIGHT = 1000;

                // Keep 20px padding
                const scaleX = (rect.width - 40) / CANVAS_WIDTH;
                const scaleY = (rect.height - 40) / CANVAS_HEIGHT;

                // Use the minimum scale to ensure it fits entirely without scrolling
                setScale(Math.min(scaleX, scaleY, 1.5));
            }
        };

        const observer = new ResizeObserver(() => {
            calculateScale();
        });

        observer.observe(bodyRef.current);
        calculateScale(); // Initial calculation

        return () => {
            observer.disconnect();
        };
    }, [isLoading]);

    if (isLoading) {
        return (
            <div className="flex flex-col items-center justify-center h-[calc(100vh-64px)] gap-3 bg-slate-50 dark:bg-slate-950">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <RiLoader4Line className="w-7 h-7 animate-spin text-blue-600 dark:text-blue-400" />
                </div>
                <p className="text-slate-500 dark:text-slate-400 font-semibold text-sm">Loading Aeration Monitor Data...</p>
            </div>
        );
    }

    return (
        <TooltipProvider>
            <div ref={containerRef} className="relative w-full h-[calc(100vh-130px)] flex flex-col bg-white dark:bg-slate-900 overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
                {/* Header */}
                <div className="flex-none px-5 py-3 flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-10">
                    <div className="flex items-center gap-3">
                        <div className="w-1 h-6 bg-indigo-600 dark:bg-indigo-500 rounded-full" />
                        <h1 className="text-lg font-bold text-slate-800 dark:text-slate-100 tracking-tight">Monitor Aeration Area</h1>
                        <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700 ml-1">
                            <span className="relative flex h-2 w-2">
                                {isConnected && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 dark:bg-emerald-500 opacity-75"></span>}
                                <span className={`relative inline-flex rounded-full h-2 w-2 ${isConnected ? "bg-emerald-500 dark:bg-emerald-400" : "bg-red-500 dark:bg-red-400"}`}></span>
                            </span>
                            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                {isConnected ? "Live" : "Offline"}
                            </span>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        {/* Legend */}
                        <div className="px-3 py-1">
                            {columns && <MonitorLegend columns={columns} />}
                        </div>

                        <div className="h-6 w-px bg-slate-200 dark:bg-slate-800" />

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5">
                            <Button variant="outline" size="icon" onClick={() => refetch()} className="h-8 w-8 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 bg-transparent dark:text-slate-300">
                                <RiRefreshLine className={`w-4 h-4 ${isFetching ? "animate-spin text-indigo-600 dark:text-indigo-400" : "text-slate-600 dark:text-slate-400"}`} />
                            </Button>
                            <Button variant="outline" size="icon" onClick={toggleFullscreen} className="h-8 w-8 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 bg-transparent dark:text-slate-300">
                                {isFullscreen ? <RiFullscreenExitLine className="w-4 h-4 text-slate-600 dark:text-slate-400" /> : <RiFullscreenLine className="w-4 h-4 text-slate-600 dark:text-slate-400" />}
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Main Content Area */}
                <div ref={bodyRef} className="flex-1 overflow-hidden relative bg-slate-50 dark:bg-[#09090b] bg-[radial-gradient(circle,#e2e8f0_1px,transparent_1px)] dark:bg-[radial-gradient(circle,#1e293b_1px,transparent_1px)] bg-[size:22px_22px]">
                    <div className={`absolute inset-0 w-full h-full transition-all duration-500 ${!isConnected ? "opacity-30 grayscale blur-[2px] pointer-events-none" : ""}`}>
                        <div
                            style={{
                                position: "absolute",
                                left: "50%",
                                top: "50%",
                                transform: `translate(-50%, -50%) scale(${scale})`,
                                transformOrigin: "center center",
                                width: "1750px",
                                height: "1000px",
                                transition: "transform 0.1s ease-out"
                            }}
                        >
                            {columns ? <MonitorCanvas columns={columns} /> : null}
                        </div>
                    </div>

                    {/* Offline Overlay */}
                    {!isConnected && (
                        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center pointer-events-none">
                            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-6 rounded-2xl shadow-xl flex flex-col items-center gap-4 border border-slate-200 dark:border-slate-800 pointer-events-auto">
                                <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center relative">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-20"></span>
                                    <RiWifiOffLine className="w-8 h-8 text-red-500 dark:text-red-400 relative z-10" />
                                </div>
                                <div className="text-center">
                                    <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Connection Lost</h3>
                                    <p className="text-sm text-slate-500 dark:text-slate-400 max-w-[250px] mt-1">Trying to reconnect to live data...</p>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </TooltipProvider>
    );
}
