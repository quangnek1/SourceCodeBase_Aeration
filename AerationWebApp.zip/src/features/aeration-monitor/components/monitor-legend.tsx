import type { MonitorAerationColumnDto } from "../types/aeration-monitor.types";

interface MonitorLegendProps {
    columns: MonitorAerationColumnDto[];
}

export function MonitorLegend({ columns }: MonitorLegendProps) {
    const safeColumns = Array.isArray(columns) ? columns : [];
    const allSlots = safeColumns.flatMap(c => c.aerationPositionDtos || []);

    let okCount = 0;
    let waitingCount = 0;
    let emptyCount = 0;

    const getStatusStr = (s: any) => {
        if (!s) return "";
        if (typeof s === 'object' && s.name) return String(s.name).toLowerCase().trim();
        return String(s).toLowerCase().trim();
    };

    allSlots.forEach(slot => {
        const items = slot.batchInAerationPositionDataDtos || [];
        const count = items.length;

        const rawStatus = getStatusStr(slot.status);

        let isOk = rawStatus === "done" || rawStatus === "completed" || rawStatus === "2";
        let isWaiting = rawStatus === "inprogress" || rawStatus === "aerating" || rawStatus === "1";

        if (!isOk && !isWaiting && count > 0) {
            const firstStatus = getStatusStr(items[0].batchDto?.status);
            if (firstStatus === "done" || firstStatus === "completed") {
                isOk = true;
            } else {
                isWaiting = true;
            }
        }

        if (isOk) {
            okCount++;
        } else if (isWaiting) {
            waitingCount++;
        } else {
            emptyCount++;
        }
    });

    const total = allSlots.length;

    return (
        <div className="flex items-center gap-4 text-xs font-semibold text-slate-600 dark:text-slate-300 pointer-events-none">
            <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 dark:bg-emerald-600"></span>
                <span>Done: <span className="text-emerald-600 dark:text-emerald-400 font-bold">{okCount}</span></span>
            </div>
            <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 dark:bg-amber-600"></span>
                <span>Aeration: <span className="text-amber-600 dark:text-amber-400 font-bold">{waitingCount}</span></span>
            </div>
            <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700"></span>
                <span>Empty: <span className="text-slate-500 dark:text-slate-400 font-bold">{emptyCount}</span></span>
            </div>
            <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />
            <div className="flex items-center gap-1">
                <span>Total: <span className="text-indigo-600 dark:text-indigo-400 font-bold">{total}</span></span>
            </div>
        </div>
    );
}
