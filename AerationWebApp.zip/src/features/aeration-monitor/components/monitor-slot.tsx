import {
    Tooltip,
    TooltipContent,
    TooltipTrigger,
} from "@/components/ui/tooltip";
import type { MonitorAerationPositionDto } from "../types/aeration-monitor.types";
import { RiQrCodeLine, RiLoginCircleLine, RiTimerLine, RiStackLine, RiCheckboxCircleFill, RiLoader3Fill } from "@remixicon/react";
import { format } from "date-fns";

interface MonitorSlotProps {
    slot: MonitorAerationPositionDto;
    x: number;
    y: number;
    w: number;
    h: number;
}

export function MonitorSlot({ slot, x, y, w, h }: MonitorSlotProps) {
    const items = slot.batchInAerationPositionDataDtos || [];
    const count = items.length;

    // Handle both string status and object status (e.g. { name: 'Done', value: 2 })
    const getStatusStr = (s: any) => {
        if (!s) return "";
        if (typeof s === 'object' && s.name) return String(s.name).toLowerCase().trim();
        return String(s).toLowerCase().trim();
    };

    const rawStatus = getStatusStr(slot.status);

    let isOk = rawStatus === "done" || rawStatus === "completed" || rawStatus === "2";
    let isWaiting = rawStatus === "inprogress" || rawStatus === "aerating" || rawStatus === "1";

    // Fallback if slot.status is undefined/missing but we have items in the slot
    if (!isOk && !isWaiting && count > 0) {
        const firstStatus = getStatusStr(items[0].batchDto?.status);
        if (firstStatus === "done" || firstStatus === "completed") {
            isOk = true;
        } else {
            isWaiting = true; // Default to waiting if there are items but not done
        }
    }

    const isEmpty = rawStatus === "empty" || rawStatus === "0" || (!isOk && !isWaiting && count === 0);

    // ── Card appearance (flat, clean) ─────────────────────────────────────────────
    const card = isOk
        ? {
            bg: "bg-emerald-50 dark:bg-emerald-950/40",
            border: "border-emerald-300 dark:border-emerald-800/60",
            accent: "bg-emerald-500 dark:bg-emerald-600",
            badge: "bg-emerald-500 text-white dark:bg-emerald-600",
            label: "DONE",
            divider: "border-emerald-200 dark:border-emerald-800/60",
            subtext: "text-emerald-600 dark:text-emerald-400",
        }
        : isWaiting
            ? {
                bg: "bg-amber-50 dark:bg-amber-950/40",
                border: "border-amber-300 dark:border-amber-800/60",
                accent: "bg-amber-500 dark:bg-amber-600",
                badge: "bg-amber-500 text-white dark:bg-amber-600",
                label: "AERATION",
                divider: "border-amber-200 dark:border-amber-800/60",
                subtext: "text-amber-600 dark:text-amber-400",
            }
            : {
                bg: "bg-white dark:bg-slate-900/40",
                border: "border-slate-200 border-dashed dark:border-slate-700/60",
                accent: "bg-slate-300 dark:bg-slate-700",
                badge: "bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-400",
                label: "EMPTY",
                divider: "border-slate-100 dark:border-slate-800/60",
                subtext: "text-slate-400 dark:text-slate-500",
            };

    // ── Tooltip palette ─────────────────────────────────────────────────────────
    const tooltipHeader = isOk
        ? "bg-emerald-500 dark:bg-emerald-600"
        : isWaiting
            ? "bg-amber-500 dark:bg-amber-600"
            : "bg-slate-500 dark:bg-slate-600";

    const tooltipItemBg = "bg-slate-50 border-slate-200 dark:bg-slate-900 dark:border-slate-800";

    const tooltipStatusText = isOk ? "Completed" : isWaiting ? "Aerating" : "Empty";
    const StatusIcon = isOk ? RiCheckboxCircleFill : isWaiting ? RiLoader3Fill : RiStackLine;

    return (
        <Tooltip delayDuration={80}>
            <TooltipTrigger asChild>
                <div
                    className={`absolute rounded-md border cursor-pointer
                        transition-all duration-150
                        hover:shadow-md hover:-translate-y-0.5 hover:z-10
                        ${card.bg} ${card.border}`}
                    style={{ left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` }}
                >
                    {/* Left accent bar */}
                    <div className={`absolute left-0 top-0 bottom-0 w-1 rounded-l-md ${card.accent}`} />

                    {/* Content */}
                    <div className="absolute left-2.5 top-0 right-1.5 bottom-0 flex flex-col justify-evenly">
                        {/* Row 1: position code + status badge */}
                        <div className="flex items-center justify-between">
                            <span className="font-bold text-[13px] text-slate-800 dark:text-slate-200 tracking-wide leading-none">
                                {slot.positionCode}
                            </span>
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded leading-tight ${card.badge}`}>
                                {card.label}
                            </span>
                        </div>

                        {/* Row 2: batch info */}
                        <div className={`border-t pt-1 ${card.divider}`}>
                            {isEmpty ? (
                                <span className={`text-[10px] font-semibold italic ${card.subtext}`}>— Empty —</span>
                            ) : count === 1 ? (
                                <div className="flex flex-col gap-[1px]">
                                    <span
                                        className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate leading-tight"
                                        title={items[0].batchDto?.batchNo}
                                    >
                                        {items[0].batchDto?.batchNo || items[0].batchDto?.qrCode || "N/A"}
                                    </span>
                                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-tight">
                                        {items[0].batchDto?.inputAerationActual
                                            ? format(new Date(items[0].batchDto.inputAerationActual), "dd.MMM.yyyy - HH:mm")
                                            : "--"}
                                    </span>
                                </div>
                            ) : count > 1 ? (
                                <div className="flex items-center gap-1 text-[11px] font-bold text-indigo-700 dark:text-indigo-400">
                                    <RiStackLine className="w-3 h-3" />
                                    {count} batches
                                </div>
                            ) : (
                                <span className={`text-[10px] font-semibold italic ${card.subtext}`}>No Data</span>
                            )}
                        </div>
                    </div>
                </div>
            </TooltipTrigger>

            {/* ── Tooltip ──────────────────────────────────────────────────────── */}
            <TooltipContent
                side="right"
                align="center"
                sideOffset={10}
                className="p-0 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 shadow-xl rounded-xl overflow-hidden w-72 z-50 flex flex-col items-stretch gap-0"
            >
                {/* Header */}
                <div className={`flex items-center justify-between px-4 py-2.5 ${tooltipHeader}`}>
                    <div className="flex items-center gap-2">
                        <StatusIcon className="w-4 h-4 text-white" />
                        <span className="font-bold text-white text-[15px] tracking-wide">
                            {slot.positionCode}
                        </span>
                    </div>
                    <span className="bg-white/25 text-white text-[10px] font-bold px-2.5 py-0.5 rounded uppercase tracking-wider">
                        {tooltipStatusText}
                    </span>
                </div>

                {/* Body */}
                <div className="bg-white dark:bg-slate-950 px-4 py-3">
                    {isEmpty ? (
                        <div className="flex flex-col items-center py-5 gap-2 text-slate-400 dark:text-slate-500">
                            <RiStackLine className="w-9 h-9 opacity-20" />
                            <span className="text-sm font-medium">Empty</span>
                        </div>
                    ) : count === 0 ? (
                        <div className="flex flex-col items-center py-5 gap-2 text-slate-400 dark:text-slate-500">
                            <RiStackLine className="w-9 h-9 opacity-20" />
                            <span className="text-sm font-medium">No Data</span>
                        </div>
                    ) : (
                        <div className="flex flex-col gap-2">
                            {items.map((item, idx) => (
                                <div
                                    key={idx}
                                    className={`rounded-lg border p-2.5 ${tooltipItemBg}`}
                                >
                                    {/* QR / Batch No */}
                                    <div className="flex items-start gap-2 mb-2 pb-2 border-b border-slate-200 dark:border-slate-800">
                                        <RiQrCodeLine className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0 mt-0.5" />
                                        <div className="flex flex-col min-w-0">
                                            <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">
                                                Batch No
                                            </span>
                                            <span className="font-bold text-[13px] text-slate-800 dark:text-slate-200 break-all leading-snug">
                                                {item.batchDto?.batchNo || item.batchDto?.qrCode || "Không rõ"}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Info grid */}
                                    <div className="grid grid-cols-2 gap-x-3 gap-y-2">
                                        <div className="flex flex-col gap-0.5">
                                            <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">
                                                Input Date
                                            </span>
                                            <div className="flex items-center gap-1 text-[12px] font-semibold text-slate-700 dark:text-slate-300">
                                                <RiLoginCircleLine className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
                                                <span>
                                                    {item.batchDto?.inputAerationActual
                                                        ? format(new Date(item.batchDto.inputAerationActual), "dd.MMM.yyyy - HH:mm")
                                                        : "—"}
                                                </span>
                                            </div>
                                        </div>

                                        <div className="flex flex-col gap-0.5">
                                            <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">
                                                Keep
                                            </span>
                                            <div className="flex items-center gap-1 text-[12px] font-semibold text-slate-700 dark:text-slate-300">
                                                <RiTimerLine className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
                                                <span>{item.batchDto?.keep ?? 0} day</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </TooltipContent>
        </Tooltip>
    );
}
