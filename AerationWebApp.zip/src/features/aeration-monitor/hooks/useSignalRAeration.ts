import { useEffect, useState } from "react";
import { HubConnection, HubConnectionBuilder, HubConnectionState } from "@microsoft/signalr";
import { useQueryClient } from "@tanstack/react-query";
import type { MonitorAerationColumnDto } from "../types/aeration-monitor.types";
import { getApiUrl } from "@/services/api-client";

export function useSignalRAeration() {
    const [connection, setConnection] = useState<HubConnection | null>(null);
    const [isConnected, setIsConnected] = useState(false);
    const [liveData, setLiveData] = useState<MonitorAerationColumnDto[] | null>(null);
    const queryClient = useQueryClient();

    useEffect(() => {
        // Lấy địa chỉ API hiện tại (ví dụ: http://localhost:5000/api/v1)
        const apiUrl = getApiUrl();
        // Lấy origin (ví dụ: http://localhost:5000)
        const baseUrl = new URL(apiUrl).origin;
        const url = `${baseUrl}/aerationServiceHub`;

        const newConnection = new HubConnectionBuilder()
            .withUrl(url)
            .withAutomaticReconnect()
            .build();

        setConnection(newConnection);

        return () => {
            newConnection.stop();
        };
    }, []);

    useEffect(() => {
        if (!connection) return;

        connection.on("AerationUpdated", (rawData?: any) => {
            if (rawData) {
                const finalData = rawData?.value?.items || rawData?.value || (Array.isArray(rawData) ? rawData : []);
                if (finalData && finalData.length > 0) {
                    // Dùng React State thuần túy để ép giao diện vẽ lại ngay lập tức
                    setLiveData(finalData);
                }
            }
        });


        connection.onreconnected(() => {
            setIsConnected(true);
            // Khi có kết nối lại, bắt buộc gọi API lấy layout mới nhất phòng trường hợp data cũ bị mất
            queryClient.invalidateQueries({ queryKey: ["aeration-monitor-columns"] });
        });

        connection.onreconnecting(() => {
            setIsConnected(false);
        });

        connection.onclose(() => {
            setIsConnected(false);
            // Khi server restart, session cũ bị mất nên SignalR sẽ đóng kết nối (close).
            // Ta cần thiết lập lại vòng lặp startConnection để cấp lại connection ID mới.
            timeoutId = setTimeout(startConnection, 5000);
        });

        let timeoutId: ReturnType<typeof setTimeout>;

        async function startConnection() {
            try {
                if (connection!.state === HubConnectionState.Disconnected) {
                    await connection!.start();
                }
                setIsConnected(connection!.state === HubConnectionState.Connected);
                // Vừa mới kết nối thành công lần đầu -> Gọi lấy data ngay lập tức để hiện layout
                queryClient.invalidateQueries({ queryKey: ["aeration-monitor-columns"] });
            } catch (err) {
                console.error("SignalR Connection Error: ", err);
                // Thử lại sau 5 giây nếu không kết nối được
                timeoutId = setTimeout(startConnection, 5000);
            }
        }

        startConnection();

        return () => {
            clearTimeout(timeoutId);
            connection.off("AerationUpdated");
            connection.off("reconnected");
            connection.off("reconnecting");
            connection.off("close");
        };
    }, [connection]);

    return { isConnected, liveData };
}
