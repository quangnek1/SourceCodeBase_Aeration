import { useQuery } from "@tanstack/react-query";
import { aerationMonitorApi } from "../api/aeration-monitor.api";
import type { MonitorAerationColumnDto } from "../types/aeration-monitor.types";

export function useAerationMonitorData() {
    return useQuery<MonitorAerationColumnDto[]>({
        queryKey: ["aeration-monitor-columns"],
        queryFn: aerationMonitorApi.getAerationColumns,
        staleTime: 0,
        refetchOnWindowFocus: true,
    });
}
