export const MonitorSlotStatus = {
    Done: 0,
    InProgress: 1,
    Empty: 2,
} as const;

export type MonitorSlotStatus = typeof MonitorSlotStatus[keyof typeof MonitorSlotStatus];

export interface BatchDto {
    id: number;
    qrCode: string;
    qrCodeSvg?: string | null;
    sterilizeDate?: string;
    createdDate?: string;
    batchNo: string;
    keep: number;
    status: string;
    inputAerationActual?: string | null;
    planOutputAeration?: string | null;
    actualOutputAeration?: string | null;
}

export interface BatchInAerationPositionDataDto {
    batchDto: BatchDto;
}

export interface MonitorAerationPositionDto {
    id: number;
    positionCode: string;
    image?: string | null;
    aerationColumnId: number;
    status?: string | null;
    batchInAerationPositionDataDtos?: BatchInAerationPositionDataDto[];
}

export interface MonitorAerationColumnDto {
    id: number;
    columnName: string;
    status: boolean;
    aerationPositionDtos: MonitorAerationPositionDto[];
}
