import { axiosInstance } from "@/lib/axios";
import type { MonitorAerationColumnDto } from "../types/aeration-monitor.types";

export const aerationMonitorApi = {
    getAerationColumns: async (): Promise<MonitorAerationColumnDto[]> => {
        const res = await axiosInstance.get(`/AerationColumn/GetAerationColumnsIncludedData`, {
            params: { pageSize: -1 }
        });
        const data = res.data;
        const finalData = data?.value?.items || data?.value || (Array.isArray(data) ? data : []);
        return finalData;
    }
};
