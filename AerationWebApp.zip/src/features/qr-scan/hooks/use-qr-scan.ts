import { useState, useRef, useEffect, useCallback } from "react";

export interface QrScanResult {
    rawValue: string;
    timestamp: Date;
}

export interface UseQrScanOptions {
    onScanSuccess?: (result: QrScanResult) => void;
    onScanError?: (error: string) => void;
    /** Debounce ms to avoid duplicate scans from the same QR code */
    debounceMs?: number;
}

export function useQrScan(options: UseQrScanOptions = {}) {
    const { onScanSuccess, onScanError, debounceMs = 1500 } = options;

    const [isScanning, setIsScanning] = useState(false);
    const [lastResult, setLastResult] = useState<QrScanResult | null>(null);
    const [error, setError] = useState<string | null>(null);

    const lastValueRef = useRef<string | null>(null);
    const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    const handleScan = useCallback(
        (rawValue: string) => {
            if (!rawValue) return;

            // Deduplicate: skip if same value scanned within debounce window
            if (rawValue === lastValueRef.current) return;

            lastValueRef.current = rawValue;

            // Clear the lock after debounce period
            if (debounceTimerRef.current) {
                clearTimeout(debounceTimerRef.current);
            }
            debounceTimerRef.current = setTimeout(() => {
                lastValueRef.current = null;
            }, debounceMs);

            const result: QrScanResult = { rawValue, timestamp: new Date() };
            setLastResult(result);
            setError(null);
            onScanSuccess?.(result);
        },
        [onScanSuccess, debounceMs]
    );

    const handleError = useCallback(
        (msg: string) => {
            setError(msg);
            onScanError?.(msg);
        },
        [onScanError]
    );

    const startScanning = useCallback(() => setIsScanning(true), []);
    const stopScanning = useCallback(() => setIsScanning(false), []);

    const reset = useCallback(() => {
        setLastResult(null);
        setError(null);
        lastValueRef.current = null;
    }, []);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (debounceTimerRef.current) {
                clearTimeout(debounceTimerRef.current);
            }
        };
    }, []);

    return {
        isScanning,
        lastResult,
        error,
        startScanning,
        stopScanning,
        handleScan,
        handleError,
        reset,
    };
}
