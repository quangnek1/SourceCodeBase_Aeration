import { useQuery } from "@tanstack/react-query";
import { qrScanApi } from "../api/qr-scan.api";
import type { BatchScanQrcodeDto } from "../types/qr-scan.types";

export type BatchLookupState =
    | { status: "idle" }
    | { status: "loading" }
    | { status: "not_found" }
    | { status: "error"; message: string }
    | { status: "found"; batch: BatchScanQrcodeDto };

export function useBatchByQrcode(qrcode: string | null) {
    const query = useQuery({
        queryKey: ["batch-by-qrcode", qrcode],
        queryFn: async () => {
            const res = await qrScanApi.getBatchByQrcode(qrcode!);
            return res;
        },
        enabled: !!qrcode,
        retry: false,
        staleTime: 0,         // always re-fetch for fresh scan
        gcTime: 0,
    });

    let state: BatchLookupState = { status: "idle" };

    if (!qrcode) {
        state = { status: "idle" };
    } else if (query.isLoading || query.isFetching) {
        state = { status: "loading" };
    } else if (query.isError) {
        state = { status: "error", message: (query.error as Error).message };
    } else if (query.data) {
        if (query.data.isFailure || !query.data.value) {
            state = { status: "not_found" };
        } else {
            state = { status: "found", batch: query.data.value };
        }
    }

    return { state, refetch: query.refetch };
}
