import { axiosInstance } from "@/lib/axios";
import type { ApiResponse } from "@/types/dto";
import type { BatchScanQrcodeDto } from "../types/qr-scan.types";

export const qrScanApi = {
    getBatchByQrcode: async (qrcode: string): Promise<ApiResponse<BatchScanQrcodeDto>> => {
        const res = await axiosInstance.get<ApiResponse<BatchScanQrcodeDto>>(
            "/Batch/GetBatchByQrcode",
            { params: { qrcode } }
        );
        return res.data;
    },
};
