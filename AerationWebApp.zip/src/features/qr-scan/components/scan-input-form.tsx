import { useState } from "react";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { RiCalendarLine, RiSearchLine } from "@remixicon/react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAerationPositions } from "@/features/batches/hooks/useAerationPositions";
import { useInputAerationBatch } from "@/features/batches/hooks/useInputAerationBatch";
import type { BatchScanQrcodeDto } from "../types/qr-scan.types";

interface ScanInputFormProps {
    batch: BatchScanQrcodeDto;
    onSuccess: () => void;
}

export function ScanInputForm({ batch, onSuccess }: ScanInputFormProps) {
    const [inputDateObj, setInputDateObj] = useState<Date | undefined>(new Date());
    const [inputHour, setInputHour] = useState<string>(() => format(new Date(), "HH"));
    const [inputMinute, setInputMinute] = useState<string>(() => format(new Date(), "mm"));
    const [searchPosition, setSearchPosition] = useState("");
    const [selectedPositions, setSelectedPositions] = useState<{ id: number; code: string }[]>([]);

    const { data: positionsData } = useAerationPositions();
    const availablePositions = positionsData?.value?.items || [];
    const inputAerationMutation = useInputAerationBatch();

    const handleSubmit = () => {
        if (!inputDateObj || selectedPositions.length === 0) return;
        const dateStr = format(inputDateObj, "yyyy-MM-dd");
        const finalDateIso = new Date(`${dateStr}T${inputHour}:${inputMinute}:00`).toISOString();

        inputAerationMutation.mutate(
            {
                batchId: batch.id,
                positionIds: selectedPositions.map((p) => p.id),
                date: finalDateIso,
                location: selectedPositions.map((p) => p.code),
            },
            { onSuccess }
        );
    };

    const filteredPositions = availablePositions.filter((p: any) =>
        p.positionCode?.toLowerCase().includes(searchPosition.toLowerCase())
    );

    return (
        <div className="flex flex-col gap-4 mt-2">
            {/* Batch info */}
            <div className="rounded-md border bg-muted/30 px-3 py-2 text-sm">
                <span className="text-muted-foreground">Mẻ: </span>
                <strong>{batch.batchNo}</strong>
                <span className="text-muted-foreground ml-3">Trạng thái: </span>
                <span className="text-green-600 font-medium">{batch.status}</span>
            </div>

            {/* Date & time */}
            <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Ngày giờ</label>
                <div className="flex items-center gap-2">
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button
                                variant="outline"
                                className={`flex-1 justify-start text-left font-normal ${!inputDateObj ? "text-muted-foreground" : ""}`}
                            >
                                <RiCalendarLine className="mr-2 h-4 w-4" />
                                {inputDateObj ? format(inputDateObj, "dd/MM/yyyy") : <span>Chọn ngày...</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={inputDateObj} onSelect={setInputDateObj} locale={vi} />
                        </PopoverContent>
                    </Popover>
                    <div className="flex items-center gap-1">
                        <Select value={inputHour} onValueChange={setInputHour}>
                            <SelectTrigger className="w-[68px]">
                                <SelectValue placeholder="Giờ" />
                            </SelectTrigger>
                            <SelectContent>
                                {Array.from({ length: 24 }).map((_, i) => {
                                    const h = i.toString().padStart(2, "0");
                                    return <SelectItem key={h} value={h}>{h}</SelectItem>;
                                })}
                            </SelectContent>
                        </Select>
                        <span className="text-muted-foreground font-medium">:</span>
                        <Select value={inputMinute} onValueChange={setInputMinute}>
                            <SelectTrigger className="w-[68px]">
                                <SelectValue placeholder="Phút" />
                            </SelectTrigger>
                            <SelectContent>
                                {Array.from({ length: 60 }).map((_, i) => {
                                    const m = i.toString().padStart(2, "0");
                                    return <SelectItem key={m} value={m}>{m}</SelectItem>;
                                })}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </div>

            {/* Positions */}
            <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Vị trí</label>
                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal h-10 px-3 truncate">
                            {selectedPositions.length > 0
                                ? selectedPositions.map((p) => p.code).join(", ")
                                : <span className="text-muted-foreground">Chọn positions...</span>}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
                        <div className="flex flex-col">
                            <div className="flex items-center border-b px-3">
                                <RiSearchLine className="h-4 w-4 text-muted-foreground mr-2 shrink-0" />
                                <input
                                    className="flex h-10 w-full bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
                                    placeholder="Tìm positions..."
                                    value={searchPosition}
                                    onChange={(e) => setSearchPosition(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === "Enter" && searchPosition.trim() && filteredPositions.length > 0) {
                                            e.preventDefault();
                                            const first = filteredPositions[0];
                                            if (!selectedPositions.some((sp) => sp.id === first.id)) {
                                                setSelectedPositions([...selectedPositions, { id: first.id, code: first.positionCode }]);
                                            }
                                            setSearchPosition("");
                                        }
                                    }}
                                />
                            </div>
                            <div className="max-h-[200px] overflow-y-auto p-1">
                                {filteredPositions.map((p: any) => (
                                    <div
                                        key={p.id}
                                        className="flex items-center gap-2 px-2 py-1.5 hover:bg-muted cursor-pointer rounded-sm"
                                        onClick={() => {
                                            const isSelected = selectedPositions.some((sp) => sp.id === p.id);
                                            setSelectedPositions(
                                                isSelected
                                                    ? selectedPositions.filter((sp) => sp.id !== p.id)
                                                    : [...selectedPositions, { id: p.id, code: p.positionCode }]
                                            );
                                        }}
                                    >
                                        <input
                                            type="checkbox"
                                            className="w-4 h-4 rounded accent-primary cursor-pointer"
                                            checked={selectedPositions.some((sp) => sp.id === p.id)}
                                            readOnly
                                        />
                                        <span className="text-sm">{p.positionCode}</span>
                                    </div>
                                ))}
                                {filteredPositions.length === 0 && (
                                    <div className="py-6 text-center text-sm text-muted-foreground">Không tìm thấy.</div>
                                )}
                            </div>
                        </div>
                    </PopoverContent>
                </Popover>
            </div>

            <Button
                onClick={handleSubmit}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                disabled={inputAerationMutation.isPending || !inputDateObj || selectedPositions.length === 0}
            >
                {inputAerationMutation.isPending ? "Đang xử lý..." : "Xác nhận nhập"}
            </Button>
        </div>
    );
}
