import { useEffect, useRef } from "react";

interface QrScannerProps {
    isScanning: boolean;
    onScan: (value: string) => void;
    onError: (error: string) => void;
}

export function QrScanner({ isScanning, onScan, onError }: QrScannerProps) {
    const videoRef = useRef<HTMLVideoElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const animFrameRef = useRef<number | null>(null);

    useEffect(() => {
        if (isScanning) {
            startCamera();
        } else {
            stopCamera();
        }

        return () => {
            stopCamera();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isScanning]);

    async function startCamera() {
        if (!("BarcodeDetector" in window)) {
            onError("BarcodeDetector not supported. Use Chrome on Android.");
            return;
        }

        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: "environment" },
            });
            streamRef.current = stream;

            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                await videoRef.current.play();
            }

            const detector = new (window as any).BarcodeDetector({
                formats: ["qr_code"],
            });

            scanLoop(detector);
        } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : "Camera access denied.";
            onError(msg);
        }
    }

    async function scanLoop(detector: any) {
        if (!videoRef.current || !streamRef.current) return;

        try {
            const codes = await detector.detect(videoRef.current);
            if (codes.length > 0) {
                onScan(codes[0].rawValue);
            }
        } catch {
            // Ignore per-frame decode errors
        }

        animFrameRef.current = requestAnimationFrame(() => scanLoop(detector));
    }

    function stopCamera() {
        if (animFrameRef.current) {
            cancelAnimationFrame(animFrameRef.current);
            animFrameRef.current = null;
        }
        if (streamRef.current) {
            streamRef.current.getTracks().forEach((t) => t.stop());
            streamRef.current = null;
        }
        if (videoRef.current) {
            videoRef.current.srcObject = null;
        }
    }

    if (!isScanning) return null;

    return (
        <div className="relative w-full aspect-square rounded-xl overflow-hidden border bg-black">
            <video
                ref={videoRef}
                className="w-full h-full object-cover"
                muted
                playsInline
            />
            {/* Viewfinder */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-48 h-48 border-2 border-white/70 rounded-lg" />
            </div>
        </div>
    );
}
