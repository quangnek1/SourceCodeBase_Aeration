import { useState, useEffect } from "react";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { RiCalendarLine } from "@remixicon/react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useOutputAerationBatch } from "@/features/batches/hooks/useOutputAerationBatch";
import type { BatchItem } from "@/features/batches/types/batches.types";
import type { BatchScanQrcodeDto } from "../types/qr-scan.types";

interface ScanOutputFormProps {
    batch: BatchScanQrcodeDto;
    onSuccess: () => void;
}

export function ScanOutputForm({ batch, onSuccess }: ScanOutputFormProps) {
    const [outputDateObj, setOutputDateObj] = useState<Date | undefined>(new Date());
    const [outputHour, setOutputHour] = useState<string>(() => format(new Date(), "HH"));
    const [outputMinute, setOutputMinute] = useState<string>(() => format(new Date(), "mm"));
    const [selectedItemIds, setSelectedItemIds] = useState<Set<number>>(new Set());

    const outputAerationMutation = useOutputAerationBatch();

    // Auto-select all items when batch loads
    useEffect(() => {
        if (batch.batchItemDtos) {
            setSelectedItemIds(new Set(batch.batchItemDtos.map((item) => item.id)));
        }
    }, [batch]);

    const toggleItem = (id: number) => {
        const next = new Set(selectedItemIds);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        setSelectedItemIds(next);
    };

    const handleSubmit = () => {
        if (!outputDateObj || selectedItemIds.size === 0) return;
        const dateStr = format(outputDateObj, "yyyy-MM-dd");
        const localDate = new Date(`${dateStr}T${outputHour}:${outputMinute}:00`);
        const finalDateIso = format(localDate, "yyyy-MM-dd'T'HH:mm:ssXXX");

        outputAerationMutation.mutate(
            { batchId: batch.id, batchItems: Array.from(selectedItemIds), date: finalDateIso },
            { onSuccess }
        );
    };

    return (
        <div className="flex flex-col gap-4 mt-2">
            {/* Batch info */}
            <div className="rounded-md border bg-muted/30 px-3 py-2 text-sm">
                <span className="text-muted-foreground">Mẻ: </span>
                <strong>{batch.batchNo}</strong>
                <span className="text-muted-foreground ml-3">Trạng thái: </span>
                <span className="text-blue-600 font-medium">{batch.status}</span>
            </div>

            {/* Date & time */}
            <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Output Date &amp; Time</label>
                <div className="flex items-center gap-2">
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button
                                variant="outline"
                                className={`flex-1 justify-start text-left font-normal ${!outputDateObj ? "text-muted-foreground" : ""}`}
                            >
                                <RiCalendarLine className="mr-2 h-4 w-4" />
                                {outputDateObj ? format(outputDateObj, "dd/MM/yyyy") : <span>Chọn ngày...</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={outputDateObj} onSelect={setOutputDateObj} locale={vi} />
                        </PopoverContent>
                    </Popover>
                    <div className="flex items-center gap-1">
                        <Select value={outputHour} onValueChange={setOutputHour}>
                            <SelectTrigger className="w-[68px]">
                                <SelectValue placeholder="Giờ" />
                            </SelectTrigger>
                            <SelectContent>
                                {Array.from({ length: 24 }).map((_, i) => {
                                    const h = i.toString().padStart(2, "0");
                                    return <SelectItem key={h} value={h}>{h}</SelectItem>;
                                })}
                            </SelectContent>
                        </Select>
                        <span className="text-muted-foreground font-medium">:</span>
                        <Select value={outputMinute} onValueChange={setOutputMinute}>
                            <SelectTrigger className="w-[68px]">
                                <SelectValue placeholder="Phút" />
                            </SelectTrigger>
                            <SelectContent>
                                {Array.from({ length: 60 }).map((_, i) => {
                                    const m = i.toString().padStart(2, "0");
                                    return <SelectItem key={m} value={m}>{m}</SelectItem>;
                                })}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </div>

            {/* Item list */}
            <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Item List</label>
                    <span className="text-xs text-muted-foreground">
                        {selectedItemIds.size} / {batch.batchItemDtos?.length || 0} selected
                    </span>
                </div>
                <div className="border rounded-md overflow-hidden">
                    <div className="max-h-[240px] overflow-y-auto p-1 bg-muted/10">
                        {batch.batchItemDtos && batch.batchItemDtos.length > 0 ? (
                            batch.batchItemDtos.map((item: BatchItem) => (
                                <div
                                    key={item.id}
                                    className="flex items-center gap-3 px-3 py-2.5 hover:bg-muted cursor-pointer rounded-sm border-b border-border/50 last:border-0"
                                    onClick={() => toggleItem(item.id)}
                                >
                                    <input
                                        type="checkbox"
                                        className="w-4 h-4 rounded accent-primary cursor-pointer shrink-0"
                                        checked={selectedItemIds.has(item.id)}
                                        readOnly
                                    />
                                    <div className="flex flex-col flex-1 min-w-0">
                                        <span className="text-sm font-medium truncate">{item.itemName || "N/A"}</span>
                                        <div className="flex items-center gap-3 mt-0.5">
                                            <span className="text-xs text-muted-foreground">
                                                Lot: <span className="font-mono">{item.internalLot || "N/A"}</span>
                                            </span>
                                            <span className="text-xs text-muted-foreground">
                                                SL: <span className="font-semibold">{item.qtyInput || 0}</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="py-6 text-center text-sm text-muted-foreground">No items in this batch.</div>
                        )}
                    </div>
                </div>
            </div>

            <Button
                onClick={handleSubmit}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                disabled={outputAerationMutation.isPending || !outputDateObj || selectedItemIds.size === 0}
            >
                {outputAerationMutation.isPending ? "Đang xử lý..." : "Xác nhận xuất"}
            </Button>
        </div>
    );
}
