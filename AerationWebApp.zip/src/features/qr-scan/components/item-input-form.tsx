import { useEffect, useState } from "react";
import type { QrScanResult } from "../hooks/use-qr-scan";

interface ItemInputFormProps {
    scanResult: QrScanResult | null;
    onSubmit: (data: ItemFormData) => void;
    onReset: () => void;
    isSubmitting?: boolean;
}

export interface ItemFormData {
    qrValue: string;
    quantity: number;
    note: string;
}

export function ItemInputForm({
    scanResult,
    onSubmit,
    onReset,
    isSubmitting = false,
}: ItemInputFormProps) {
    const [quantity, setQuantity] = useState<number>(1);
    const [note, setNote] = useState<string>("");

    // Pre-fill / reset whenever a new QR is scanned
    useEffect(() => {
        if (scanResult) {
            setQuantity(1);
            setNote("");
        }
    }, [scanResult]);

    function handleSubmit(e: React.FormEvent) {
        e.preventDefault();
        if (!scanResult) return;
        onSubmit({ qrValue: scanResult.rawValue, quantity, note });
    }

    if (!scanResult) {
        return (
            <p className="text-sm text-muted-foreground text-center mt-4">
                Scan a QR code to fill in the details.
            </p>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-4">
            {/* Scanned value (read-only) */}
            <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    QR Value
                </label>
                <div className="rounded-md border bg-muted px-3 py-2 text-sm font-mono break-all">
                    {scanResult.rawValue}
                </div>
            </div>

            {/* Quantity */}
            <div className="flex flex-col gap-1">
                <label
                    htmlFor="item-quantity"
                    className="text-xs font-medium text-muted-foreground uppercase tracking-wide"
                >
                    Quantity
                </label>
                <input
                    id="item-quantity"
                    type="number"
                    min={1}
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    required
                />
            </div>

            {/* Note */}
            <div className="flex flex-col gap-1">
                <label
                    htmlFor="item-note"
                    className="text-xs font-medium text-muted-foreground uppercase tracking-wide"
                >
                    Note <span className="normal-case">(optional)</span>
                </label>
                <textarea
                    id="item-note"
                    rows={2}
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    className="rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                />
            </div>

            {/* Actions */}
            <div className="flex gap-2">
                <button
                    type="button"
                    onClick={onReset}
                    className="flex-1 rounded-md border px-4 py-2 text-sm font-medium hover:bg-muted transition-colors"
                >
                    Reset
                </button>
                <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
                >
                    {isSubmitting ? "Submitting…" : "Confirm"}
                </button>
            </div>
        </form>
    );
}
