import { useState, useRef } from "react";
import { QrScanner } from "./components/qr-scanner";
import { ScanInputForm } from "./components/scan-input-form";
import { ScanOutputForm } from "./components/scan-output-form";
import { useQrScan } from "./hooks/use-qr-scan";
import { useBatchByQrcode } from "./hooks/use-batch-by-qrcode";

// Statuses that allow INPUT into aeration room
const INPUT_STATUSES = ["Created", "ReCreated"];
// Status that allows OUTPUT from aeration room
const OUTPUT_STATUS = "AerationDone";

export function QrScanPage() {
    const [scannedQr, setScannedQr] = useState<string | null>(null);
    const [pdaInput, setPdaInput] = useState("");
    const pdaInputRef = useRef<HTMLInputElement>(null);

    const { isScanning, startScanning, stopScanning, handleScan, handleError, error: cameraError, reset } =
        useQrScan({
            onScanSuccess: (result) => {
                setScannedQr(result.rawValue);
                stopScanning();
            },
        });

    const { state } = useBatchByQrcode(scannedQr);

    function handleNewScan(value: string) {
        handleScan(value);
        setScannedQr(value);
    }

    /** PDA: scan sends characters then Enter */
    function handlePdaKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
        if (e.key === "Enter") {
            const value = pdaInput.trim();
            if (value) {
                handleNewScan(value);
                setPdaInput("");
            }
        }
    }

    function handleReset() {
        reset();
        setScannedQr(null);
        setPdaInput("");
        pdaInputRef.current?.focus();
    }

    return (
        <div className="flex flex-col gap-4">
            {/* Header row */}
            <div className="flex items-center justify-between">
                <h1 className="text-lg font-semibold">Scan Item</h1>
                <button
                    type="button"
                    onClick={isScanning ? stopScanning : startScanning}
                    className="rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                >
                    {isScanning ? "Stop Camera" : "Open Camera"}
                </button>
            </div>

            {/* PDA input */}
            <div className="flex flex-col gap-1">
                <label
                    htmlFor="pda-scan-input"
                    className="text-xs font-medium text-muted-foreground uppercase tracking-wide"
                >
                    PDA / Barcode Scanner
                </label>
                <input
                    id="pda-scan-input"
                    ref={pdaInputRef}
                    type="text"
                    value={pdaInput}
                    onChange={(e) => setPdaInput(e.target.value)}
                    onKeyDown={handlePdaKeyDown}
                    placeholder="Focus here, then scan with PDA…"
                    className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    autoComplete="off"
                    autoCorrect="off"
                    spellCheck={false}
                />
            </div>

            {/* Camera */}
            <QrScanner isScanning={isScanning} onScan={handleNewScan} onError={handleError} />

            {/* Camera error */}
            {cameraError && (
                <p className="text-sm text-destructive rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2">
                    {cameraError}
                </p>
            )}

            {/* Result area */}
            {state.status === "idle" && (
                <p className="text-sm text-muted-foreground text-center mt-2">
                    Scan a QR code to look up the batch.
                </p>
            )}

            {state.status === "loading" && (
                <div className="flex items-center justify-center py-8">
                    <span className="text-sm text-muted-foreground animate-pulse">Looking up batch…</span>
                </div>
            )}

            {state.status === "not_found" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-6 text-center">
                    <p className="text-sm font-medium text-destructive">Mẻ không tồn tại</p>
                    <p className="text-xs text-muted-foreground mt-1">QR: {scannedQr}</p>
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Scan lại
                    </button>
                </div>
            )}

            {state.status === "error" && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-4 text-center">
                    <p className="text-sm font-medium text-destructive">Lỗi kết nối</p>
                    <p className="text-xs text-muted-foreground mt-1">{state.message}</p>
                    <button
                        type="button"
                        onClick={handleReset}
                        className="mt-4 rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                    >
                        Thử lại
                    </button>
                </div>
            )}

            {state.status === "found" && (() => {
                const { batch } = state;
                const status = batch.status;

                if (INPUT_STATUSES.includes(status)) {
                    return <ScanInputForm batch={batch} onSuccess={handleReset} />;
                }

                if (status === OUTPUT_STATUS) {
                    return <ScanOutputForm batch={batch} onSuccess={handleReset} />;
                }

                // Other statuses — display info only
                return (
                    <div className="rounded-md border bg-muted/20 px-4 py-5 flex flex-col gap-3">
                        {/* Title row */}
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-semibold">{batch.batchNo}</span>
                            <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium">{status}</span>
                        </div>

                        <p className="text-xs text-muted-foreground">
                            Mẻ này không thể nhập/xuất ở trạng thái hiện tại.
                        </p>

                        {/* Aeration position */}
                        {batch.batchInAerationPositionDtos && batch.batchInAerationPositionDtos.length > 0 && (
                            <p className="text-xs text-muted-foreground">
                                Vị trí: {batch.batchInAerationPositionDtos.map((p) => p.aerationPosition.positionCode).join(", ")}
                            </p>
                        )}

                        {/* Aeration timestamps */}
                        <div className="mt-1 rounded-md border border-border/50 divide-y divide-border/50 text-xs">
                            {(
                                [
                                    { label: "Nhập phòng (thực tế)",   value: batch.inputAerationActual },
                                    { label: "Xuất phòng (kế hoạch)",  value: batch.planOutputAeration },
                                    { label: "Xuất phòng (thực tế)",   value: batch.actualOutputAeration },
                                ] as const
                            ).map(({ label, value }) => (
                                <div key={label} className="flex items-center justify-between px-3 py-2 gap-2">
                                    <span className="text-muted-foreground shrink-0">{label}</span>
                                    <span className="font-medium text-right">
                                        {value
                                            ? (() => {
                                                try {
                                                    return new Date(value).toLocaleString("vi-VN", {
                                                        day: "2-digit", month: "2-digit", year: "numeric",
                                                        hour: "2-digit", minute: "2-digit",
                                                    });
                                                } catch {
                                                    return value;
                                                }
                                            })()
                                            : <span className="text-muted-foreground/50">—</span>
                                        }
                                    </span>
                                </div>
                            ))}
                        </div>

                        <button
                            type="button"
                            onClick={handleReset}
                            className="mt-1 self-start rounded-md border px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
                        >
                            Scan lại
                        </button>
                    </div>
                );

            })()}
        </div>
    );
}
