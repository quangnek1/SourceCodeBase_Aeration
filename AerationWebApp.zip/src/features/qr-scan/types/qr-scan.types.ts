import type { BatchItem } from "@/features/batches/types/batches.types";

export interface BatchScanQrcodeDto {
    id: number;
    batchNo: string;
    sterilizeDate: string;
    createdDate: string;
    status: string;
    inputAerationActual?: string | null;
    planOutputAeration?: string | null;
    actualOutputAeration?: string | null;
    batchInAerationPositionDtos?: { aerationPosition: { id: number; positionCode: string } }[];
    batchItemDtos?: BatchItem[];
}
