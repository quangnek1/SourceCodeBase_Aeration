import { useState } from "react";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { RiCalendarLine, RiSearchLine } from "@remixicon/react";
import {
    AlertDialog,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAerationPositions } from "../../hooks/useAerationPositions";
import { useInputAerationBatch } from "../../hooks/useInputAerationBatch";
import type { Batch } from "../../types/batches.types";

interface InputAerationModalProps {
    batch: Batch | null;
    onClose: () => void;
}

export function InputAerationModal({ batch, onClose }: InputAerationModalProps) {
    const [inputDateObj, setInputDateObj] = useState<Date | undefined>(new Date());
    const [inputHour, setInputHour] = useState<string>(() => format(new Date(), "HH"));
    const [inputMinute, setInputMinute] = useState<string>(() => format(new Date(), "mm"));
    const [searchPosition, setSearchPosition] = useState("");
    const [selectedPositions, setSelectedPositions] = useState<{id: number, code: string}[]>([]);

    const { data: positionsData } = useAerationPositions();
    const availablePositions = positionsData?.value?.items || [];
    
    const inputAerationMutation = useInputAerationBatch();

    const handleInputAeration = () => {
        if (batch && inputDateObj && selectedPositions.length > 0) {
            const dateStr = format(inputDateObj, "yyyy-MM-dd");
            const finalDateIso = new Date(`${dateStr}T${inputHour}:${inputMinute}:00`).toISOString();

            inputAerationMutation.mutate({
                batchId: batch.id,
                positionIds: selectedPositions.map(p => p.id),
                date: finalDateIso,
                location: selectedPositions.map(p => p.code)
            }, {
                onSuccess: () => {
                    onClose();
                    setSelectedPositions([]);
                }
            });
        }
    };

    return (
        <AlertDialog open={!!batch} onOpenChange={(open) => !open && onClose()}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Đưa mẻ vào phòng sục khí</AlertDialogTitle>
                    <AlertDialogDescription>
                        Vui lòng chọn ngày giờ và nhập positions cho mẻ <strong className="text-foreground">{batch?.batchNo}</strong>.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                
                <div className="flex flex-col gap-4 py-4">
                    <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Ngày giờ</label>
                        <div className="flex items-center gap-2">
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant={"outline"}
                                        className={`flex-1 justify-start text-left font-normal ${!inputDateObj ? "text-muted-foreground" : ""}`}
                                    >
                                        <RiCalendarLine className="mr-2 h-4 w-4" />
                                        {inputDateObj ? format(inputDateObj, "dd/MM/yyyy") : <span>Chọn ngày...</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        mode="single"
                                        selected={inputDateObj}
                                        onSelect={setInputDateObj}
                                        locale={vi}
                                    />
                                </PopoverContent>
                            </Popover>
                            <div className="flex items-center gap-1">
                                <Select value={inputHour} onValueChange={setInputHour}>
                                    <SelectTrigger className="w-[70px]">
                                        <SelectValue placeholder="Giờ" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {Array.from({ length: 24 }).map((_, i) => {
                                            const hour = i.toString().padStart(2, "0");
                                            return <SelectItem key={hour} value={hour}>{hour}</SelectItem>;
                                        })}
                                    </SelectContent>
                                </Select>
                                <span className="text-muted-foreground font-medium">:</span>
                                <Select value={inputMinute} onValueChange={setInputMinute}>
                                    <SelectTrigger className="w-[70px]">
                                        <SelectValue placeholder="Phút" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {Array.from({ length: 60 }).map((_, i) => {
                                            const minute = i.toString().padStart(2, "0");
                                            return <SelectItem key={minute} value={minute}>{minute}</SelectItem>;
                                        })}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Vị trí</label>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className="w-full justify-start text-left font-normal truncate h-10 px-3">
                                    {selectedPositions.length > 0 
                                        ? selectedPositions.map(p => p.code).join(", ")
                                        : <span className="text-muted-foreground">Chọn positions...</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
                                <div className="flex flex-col">
                                    <div className="flex items-center border-b border-border px-3">
                                        <RiSearchLine className="h-4 w-4 text-muted-foreground mr-2 shrink-0" />
                                        <input 
                                            className="flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
                                            placeholder="Tìm positions..." 
                                            value={searchPosition}
                                            onChange={(e) => setSearchPosition(e.target.value)}
                                            onKeyDown={(e) => {
                                                if (e.key === "Enter") {
                                                    e.preventDefault();
                                                    if (!searchPosition.trim()) return;
                                                    
                                                    const filtered = availablePositions.filter((p: any) => 
                                                        p.positionCode?.toLowerCase().includes(searchPosition.toLowerCase())
                                                    );
                                                    
                                                    if (filtered.length > 0) {
                                                        const firstMatch = filtered[0];
                                                        const isSelected = selectedPositions.some(sp => sp.id === firstMatch.id);
                                                        if (!isSelected) {
                                                            setSelectedPositions([...selectedPositions, { id: firstMatch.id, code: firstMatch.positionCode }]);
                                                        }
                                                        setSearchPosition("");
                                                    }
                                                }
                                            }}
                                        />
                                    </div>
                                    <div className="max-h-[200px] overflow-y-auto p-1">
                                        {availablePositions
                                            .filter((p: any) => p.positionCode?.toLowerCase().includes(searchPosition.toLowerCase()))
                                            .map((p: any) => (
                                            <div 
                                                key={p.id} 
                                                className="flex items-center gap-2 px-2 py-1.5 hover:bg-muted cursor-pointer rounded-sm"
                                                onClick={() => {
                                                    const isSelected = selectedPositions.some(sp => sp.id === p.id);
                                                    if (isSelected) {
                                                        setSelectedPositions(selectedPositions.filter(sp => sp.id !== p.id));
                                                    } else {
                                                        setSelectedPositions([...selectedPositions, { id: p.id, code: p.positionCode }]);
                                                    }
                                                }}
                                            >
                                                <input 
                                                    type="checkbox" 
                                                    className="w-4 h-4 rounded border-border accent-primary cursor-pointer"
                                                    checked={selectedPositions.some(sp => sp.id === p.id)}
                                                    readOnly
                                                />
                                                <span className="text-sm">{p.positionCode}</span>
                                            </div>
                                        ))}
                                        {availablePositions.filter((p: any) => p.positionCode?.toLowerCase().includes(searchPosition.toLowerCase())).length === 0 && (
                                            <div className="py-6 text-center text-sm text-muted-foreground">Không tìm thấy positions.</div>
                                        )}
                                    </div>
                                </div>
                            </PopoverContent>
                        </Popover>
                    </div>
                </div>

                <AlertDialogFooter>
                    <AlertDialogCancel disabled={inputAerationMutation.isPending}>Cancel</AlertDialogCancel>
                    <Button
                        onClick={handleInputAeration}
                        className="bg-green-600 hover:bg-green-700 text-white"
                        disabled={inputAerationMutation.isPending || !inputDateObj || selectedPositions.length === 0}
                    >
                        {inputAerationMutation.isPending ? "Đang xử lý..." : "Xác nhận"}
                    </Button>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}
