import { useState, useEffect } from "react";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { RiCalendarLine } from "@remixicon/react";
import {
    AlertDialog,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useOutputAerationBatch } from "../../hooks/useOutputAerationBatch";
import { useBatchesById } from "../../hooks/useBatches-by-id";
import type { Batch, BatchItem } from "../../types/batches.types";

interface OutputAerationModalProps {
    batch: Batch | null;
    onClose: () => void;
}

export function OutputAerationModal({ batch, onClose }: OutputAerationModalProps) {
    const { data: fullBatch, isLoading } = useBatchesById(batch?.id);
    const displayBatch = fullBatch || batch;

    const [outputDateObj, setOutputDateObj] = useState<Date | undefined>(new Date());
    const [outputHour, setOutputHour] = useState<string>(() => format(new Date(), "HH"));
    const [outputMinute, setOutputMinute] = useState<string>(() => format(new Date(), "mm"));

    // Auto-select all items by default
    const [selectedItemIds, setSelectedItemIds] = useState<Set<number>>(new Set());

    useEffect(() => {
        if (displayBatch && displayBatch.batchItemDtos) {
            setSelectedItemIds(new Set(displayBatch.batchItemDtos.map((item: BatchItem) => item.id)));
        } else {
            setSelectedItemIds(new Set());
        }
    }, [displayBatch]);

    const outputAerationMutation = useOutputAerationBatch();

    const handleOutputAeration = () => {
        if (batch && outputDateObj && selectedItemIds.size > 0) {
            const dateStr = format(outputDateObj, "yyyy-MM-dd");
            const localDate = new Date(`${dateStr}T${outputHour}:${outputMinute}:00`);
            const finalDateIso = format(localDate, "yyyy-MM-dd'T'HH:mm:ssXXX"); // Chuẩn ISO-8601 có múi giờ, ví dụ: 2026-07-09T10:38:00+07:00

            outputAerationMutation.mutate({
                batchId: batch.id,
                batchItems: Array.from(selectedItemIds),
                date: finalDateIso
            }, {
                onSuccess: () => {
                    onClose();
                }
            });
        }
    };

    const toggleItem = (itemId: number) => {
        const newSet = new Set(selectedItemIds);
        if (newSet.has(itemId)) {
            newSet.delete(itemId);
        } else {
            newSet.add(itemId);
        }
        setSelectedItemIds(newSet);
    };

    return (
        <AlertDialog open={!!batch} onOpenChange={(open) => !open && onClose()}>
            <AlertDialogContent className="max-w-xl">
                <AlertDialogHeader>
                    <AlertDialogTitle>Đưa mẻ ra khỏi phòng sục khí</AlertDialogTitle>
                    <AlertDialogDescription>
                        Please confirm the information and select the items to output from the aeration room for batch <strong className="text-foreground">{batch?.batchNo}</strong>.
                    </AlertDialogDescription>
                </AlertDialogHeader>

                <div className="flex flex-col gap-4 py-4">
                    <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Output Date & Time</label>
                        <div className="flex items-center gap-2">
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant={"outline"}
                                        className={`flex-1 justify-start text-left font-normal ${!outputDateObj ? "text-muted-foreground" : ""}`}
                                    >
                                        <RiCalendarLine className="mr-2 h-4 w-4" />
                                        {outputDateObj ? format(outputDateObj, "dd/MM/yyyy") : <span>Chọn ngày...</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        mode="single"
                                        selected={outputDateObj}
                                        onSelect={setOutputDateObj}
                                        locale={vi}
                                    />
                                </PopoverContent>
                            </Popover>
                            <div className="flex items-center gap-1">
                                <Select value={outputHour} onValueChange={setOutputHour}>
                                    <SelectTrigger className="w-[70px]">
                                        <SelectValue placeholder="Giờ" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {Array.from({ length: 24 }).map((_, i) => {
                                            const hour = i.toString().padStart(2, "0");
                                            return <SelectItem key={hour} value={hour}>{hour}</SelectItem>;
                                        })}
                                    </SelectContent>
                                </Select>
                                <span className="text-muted-foreground font-medium">:</span>
                                <Select value={outputMinute} onValueChange={setOutputMinute}>
                                    <SelectTrigger className="w-[70px]">
                                        <SelectValue placeholder="Phút" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {Array.from({ length: 60 }).map((_, i) => {
                                            const minute = i.toString().padStart(2, "0");
                                            return <SelectItem key={minute} value={minute}>{minute}</SelectItem>;
                                        })}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </div>

                    <div className="flex flex-col gap-2 mt-2">
                        <div className="flex items-center justify-between">
                            <label className="text-sm font-medium">Item List</label>
                            <span className="text-xs text-muted-foreground">{selectedItemIds.size} / {displayBatch?.batchItemDtos?.length || 0} selected</span>
                        </div>
                        <div className="border border-border rounded-md overflow-hidden flex flex-col relative">
                            {isLoading && (
                                <div className="absolute inset-0 bg-background/50 backdrop-blur-sm flex items-center justify-center z-10">
                                    <span className="text-sm font-medium animate-pulse">Loading items...</span>
                                </div>
                            )}
                            <div className="max-h-[250px] overflow-y-auto p-1 bg-muted/10">
                                {displayBatch?.batchItemDtos && displayBatch.batchItemDtos.length > 0 ? (
                                    displayBatch.batchItemDtos.map((item: BatchItem) => (
                                        <div
                                            key={item.id}
                                            className="flex items-center gap-3 px-3 py-2.5 hover:bg-muted cursor-pointer rounded-sm border-b border-border/50 last:border-0"
                                            onClick={() => toggleItem(item.id)}
                                        >
                                            <input
                                                type="checkbox"
                                                className="w-4 h-4 rounded border-border accent-primary cursor-pointer shrink-0 mt-0.5"
                                                checked={selectedItemIds.has(item.id)}
                                                readOnly
                                            />
                                            <div className="flex flex-col flex-1 min-w-0">
                                                <span className="text-sm font-medium text-foreground truncate">
                                                    {item.itemName || "N/A"}
                                                </span>
                                                <div className="flex items-center gap-3 mt-1">
                                                    <span className="text-xs text-muted-foreground">
                                                        Lot: <span className="font-mono text-slate-600">{item.internalLot || "N/A"}</span>
                                                    </span>
                                                    <span className="text-xs text-muted-foreground">
                                                        SL: <span className="font-semibold text-slate-600">{item.qtyInput || 0}</span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="py-6 text-center text-sm text-muted-foreground">No items in this batch.</div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                <AlertDialogFooter>
                    <AlertDialogCancel disabled={outputAerationMutation.isPending}>Cancel</AlertDialogCancel>
                    <Button
                        onClick={handleOutputAeration}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                        disabled={outputAerationMutation.isPending || !outputDateObj || selectedItemIds.size === 0}
                    >
                        {outputAerationMutation.isPending ? "Đang xử lý..." : "Xác nhận xuất"}
                    </Button>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}
