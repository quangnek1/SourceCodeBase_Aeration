import { RiPrinterLine, RiCloseLine } from "@remixicon/react";
import { Button } from "@/components/ui/button";

interface PdfModalProps {
    isOpen: boolean;
    pdfUrl: string | null;
    onClose: () => void;
}

export function PdfModal({ isOpen, pdfUrl, onClose }: PdfModalProps) {
    if (!isOpen || !pdfUrl) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 sm:p-6">
            <div className="bg-card w-full max-w-5xl h-[90vh] rounded-xl shadow-xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30">
                    <h3 className="font-semibold flex items-center gap-2 text-foreground">
                        <RiPrinterLine className="h-5 w-5 text-primary" />
                        Details phiếu PDF
                    </h3>
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 w-8 p-0" 
                        onClick={() => {
                            onClose();
                            setTimeout(() => URL.revokeObjectURL(pdfUrl), 100);
                        }}
                    >
                        <RiCloseLine className="h-5 w-5" />
                    </Button>
                </div>
                <div className="flex-1 bg-muted/10 p-2">
                    <iframe 
                        src={pdfUrl} 
                        className="w-full h-full rounded border bg-white" 
                        title="Batch PDF"
                    />
                </div>
            </div>
        </div>
    );
}
