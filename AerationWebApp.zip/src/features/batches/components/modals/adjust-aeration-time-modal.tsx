import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { RiTimeLine, RiLoader4Line, RiCalendarLine } from "@remixicon/react";
import {
    AlertDialog,
    AlertDialogCancel,
    AlertDialogContent,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { batchesApi } from "../../api/batches.api";
import type { ItemProgressDto } from "../../types/batches.types";
import { format, parseISO } from "date-fns";

// ─── Helpers ──────────────────────────────────────────────────────────────────

const ELIGIBLE_STATUSES = ["Aeration", "Done"];

function formatDate(value?: string | null): string {
    if (!value) return "—";
    try { return format(parseISO(value), "dd.MMM.yy HH:mm"); }
    catch { return value; }
}

function getStatusStyle(status?: string | null) {
    if (status === "Aeration") return "bg-sky-500/15 text-sky-400 border-sky-500/30";
    if (status === "Done") return "bg-emerald-500/15 text-emerald-400 border-emerald-500/30";
    return "bg-slate-500/15 text-slate-400 border-slate-500/30";
}

// ─── Props ────────────────────────────────────────────────────────────────────

interface AdjustAerationTimeModalProps {
    open: boolean;
    onClose: () => void;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function AdjustAerationTimeModal({ open, onClose }: AdjustAerationTimeModalProps) {
    const queryClient = useQueryClient();
    const [selectedBatchIds, setSelectedBatchIds] = useState<Set<number>>(new Set());
    const [aerationTime, setAerationTime] = useState<string>("1");

    // Fetch all items, filter eligible on client
    const { data: pageResult, isLoading } = useQuery({
        queryKey: ["lotsForTimeAdjustment"],
        queryFn: batchesApi.getLotsForTimeAdjustment,
        enabled: open,
        select: (res) => {
            const items: ItemProgressDto[] = (res.value?.items ?? []).filter(
                (item) => ELIGIBLE_STATUSES.includes(item.status ?? "")
            );
            return items;
        }
    });

    const items = pageResult ?? [];

    // Derive unique batches for checkboxes (we submit batch IDs to the backend)
    const batchMap = useMemo(() => {
        const map = new Map<number, { batchNo: string; items: ItemProgressDto[] }>();
        items.forEach((item) => {
            const bid = item.batchDto.id;
            if (!map.has(bid)) map.set(bid, { batchNo: item.batchDto.batchNo, items: [] });
            map.get(bid)!.items.push(item);
        });
        return map;
    }, [items]);

    const allBatchIds = Array.from(batchMap.keys());
    const allSelected = allBatchIds.length > 0 && selectedBatchIds.size === allBatchIds.length;

    const adjustMutation = useMutation({
        mutationFn: batchesApi.adjustAerationTime,
        onSuccess: () => {
            toast.success("Aeration time adjusted successfully!");
            queryClient.invalidateQueries({ queryKey: ["batches"] });
            queryClient.invalidateQueries({ queryKey: ["lotsForTimeAdjustment"] });
            onClose();
            setSelectedBatchIds(new Set());
        },
        onError: () => {
            toast.error("Failed to adjust aeration time. Please try again.");
        }
    });

    const handleSelectAll = (checked: boolean) => {
        setSelectedBatchIds(checked ? new Set(allBatchIds) : new Set());
    };

    const toggleBatch = (batchId: number) => {
        const next = new Set(selectedBatchIds);
        if (next.has(batchId)) next.delete(batchId);
        else next.add(batchId);
        setSelectedBatchIds(next);
    };

    const handleAdjust = () => {
        if (selectedBatchIds.size === 0) {
            toast.error("Please select at least one batch.");
            return;
        }
        adjustMutation.mutate({
            batchIds: Array.from(selectedBatchIds),
            aerationTime: parseInt(aerationTime, 10)
        });
    };

    return (
        <AlertDialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
            {/*
                AlertDialogContent mặc định dùng `grid gap-3 p-4`.
                Dùng Tailwind important prefix `!` để override thành flex layout.
            */}
            <AlertDialogContent className="max-w-4xl w-full !flex !flex-col !gap-0 !p-0 overflow-hidden max-h-[90vh]">

                {/* ── Header ─────────────────────────────────────────────── */}
                <div className="px-6 py-5 border-b border-border bg-muted/30 shrink-0 flex flex-col gap-1">
                    <h2 className="flex items-center gap-2 text-xl font-semibold">
                        <RiTimeLine className="w-6 h-6 text-primary" />
                        Adjust Aeration Time
                    </h2>
                    <p className="text-sm text-muted-foreground">
                        Select batches in <span className="text-sky-400 font-medium">Aeration</span> or <span className="text-emerald-400 font-medium">Done</span> status to extend plan output time.
                    </p>
                </div>

                {/* ── Body ───────────────────────────────────────────────── */}
                <div className="flex-1 overflow-hidden flex flex-col p-6 gap-4 min-h-0">

                    {/* Toolbar */}
                    <div className="flex items-center justify-between shrink-0">
                        <h4 className="font-semibold text-sm">
                            Batch List
                            {allBatchIds.length > 0 && (
                                <span className="ml-2 text-xs text-muted-foreground font-normal">
                                    ({allBatchIds.length} eligible)
                                </span>
                            )}
                        </h4>
                        <div className="flex items-center gap-3">
                            <span className="text-sm text-muted-foreground">Add Time:</span>
                            <Select value={aerationTime} onValueChange={setAerationTime}>
                                <SelectTrigger className="w-[130px] h-9">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="1">+ 1 hour</SelectItem>
                                    <SelectItem value="2">+ 2 hours</SelectItem>
                                    <SelectItem value="3">+ 3 hours</SelectItem>
                                    <SelectItem value="4">+ 4 hours</SelectItem>
                                    <SelectItem value="6">+ 6 hours</SelectItem>
                                    <SelectItem value="12">+ 12 hours</SelectItem>
                                    <SelectItem value="24">+ 24 hours</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    {/* Table */}
                    <div className="border border-border rounded-md flex-1 overflow-hidden flex flex-col relative min-h-0">
                        {isLoading && (
                            <div className="absolute inset-0 bg-background/50 backdrop-blur-sm flex items-center justify-center z-10">
                                <RiLoader4Line className="w-8 h-8 animate-spin text-primary" />
                            </div>
                        )}

                        {/* Column Header */}
                        <div className="bg-muted/50 px-3 py-2.5 border-b border-border shrink-0">
                            <div className="flex items-center gap-3">
                                <input
                                    type="checkbox"
                                    className="w-4 h-4 rounded border-border accent-primary cursor-pointer"
                                    checked={allSelected}
                                    onChange={(e) => handleSelectAll(e.target.checked)}
                                />
                                <div className="flex-1 grid grid-cols-[minmax(90px,auto)_minmax(110px,auto)_1fr_minmax(130px,auto)_minmax(100px,auto)] gap-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                                    <span>Batch No</span>
                                    <span>Internal Lot</span>
                                    <span>Item Name</span>
                                    <span>Plan Output</span>
                                    <span className="text-right">Status</span>
                                </div>
                            </div>
                        </div>

                        {/* Rows */}
                        <div className="overflow-y-auto flex-1 p-1">
                            {items.length > 0 ? (
                                items.map((item) => {
                                    const batchId = item.batchDto.id;
                                    const isChecked = selectedBatchIds.has(batchId);
                                    return (
                                        <div
                                            key={item.id}
                                            className={`flex items-center gap-3 px-3 py-2.5 cursor-pointer rounded-sm border-b border-border/50 last:border-0 transition-colors ${isChecked ? "bg-primary/5" : "hover:bg-muted/50"}`}
                                            onClick={() => toggleBatch(batchId)}
                                        >
                                            <input
                                                type="checkbox"
                                                className="w-4 h-4 rounded border-border accent-primary cursor-pointer shrink-0"
                                                checked={isChecked}
                                                readOnly
                                            />
                                            <div className="flex-1 grid grid-cols-[minmax(90px,auto)_minmax(110px,auto)_1fr_minmax(130px,auto)_minmax(100px,auto)] items-center gap-3 text-sm">
                                                {/* Batch No */}
                                                <div className="font-medium whitespace-nowrap">
                                                    {item.batchDto.batchNo}
                                                </div>
                                                {/* Internal Lot */}
                                                <div className="font-mono text-muted-foreground whitespace-nowrap">
                                                    {item.internalLot ?? "—"}
                                                </div>
                                                {/* Item Name (from batchDto for now) */}
                                                <div className="truncate text-muted-foreground">
                                                    {item.batchDto.batchNo}
                                                </div>
                                                {/* Plan Output Aeration Date */}
                                                <div className="flex items-center gap-1 text-xs text-muted-foreground whitespace-nowrap">
                                                    {item.planOutputAerationDate
                                                        ? <><RiCalendarLine className="w-3 h-3 shrink-0" />{formatDate(item.planOutputAerationDate)}</>
                                                        : "—"
                                                    }
                                                </div>
                                                {/* Status */}
                                                <div className="flex justify-end">
                                                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border whitespace-nowrap ${getStatusStyle(item.status)}`}>
                                                        {item.status}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })
                            ) : !isLoading ? (
                                <div className="py-10 text-center text-sm text-muted-foreground">
                                    No batches in Aeration or Done status found.
                                </div>
                            ) : null}
                        </div>
                    </div>
                </div>

                {/* ── Footer ─────────────────────────────────────────────── */}
                <div className="px-6 py-4 border-t border-border bg-muted/10 shrink-0 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                        {selectedBatchIds.size > 0
                            ? <><span className="font-medium text-foreground">{selectedBatchIds.size}</span> batch(es) selected</>
                            : "No batches selected"
                        }
                    </span>
                    <div className="flex items-center gap-2">
                        <AlertDialogCancel onClick={onClose} disabled={adjustMutation.isPending}>
                            Cancel
                        </AlertDialogCancel>
                        <Button
                            onClick={handleAdjust}
                            disabled={selectedBatchIds.size === 0 || adjustMutation.isPending}
                            className="gap-2"
                        >
                            {adjustMutation.isPending && <RiLoader4Line className="w-4 h-4 animate-spin" />}
                            Add {aerationTime}h to {selectedBatchIds.size || ""} batch{selectedBatchIds.size !== 1 ? "es" : ""}
                        </Button>
                    </div>
                </div>

            </AlertDialogContent>
        </AlertDialog>
    );
}
