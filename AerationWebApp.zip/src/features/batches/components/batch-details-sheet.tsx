import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { useBatchesById } from "../hooks/useBatches-by-id";
import { PLAN_STATUS_COLORS, PLAN_STATUS_TRANSLATIONS, DEFAULT_STATUS_COLOR, ProcessStatus } from "../../plans/types/plans.types";

interface BatchDetailsSheetProps {
    batch: any | null;
    onClose: () => void;
}

export function BatchDetailsSheet({ batch, onClose }: BatchDetailsSheetProps) {
    const { data: fullBatch, isLoading } = useBatchesById(batch?.id);
    const displayBatch = fullBatch || batch;

    return (
        <Sheet open={!!batch} onOpenChange={(open) => !open && onClose()}>
            <SheetContent className="w-full sm:max-w-[90vw] overflow-y-auto border-l shadow-2xl p-0">
                <SheetHeader className="p-6 pr-14 pb-5 bg-muted/30 border-b border-border/50">
                    <div className="flex items-center justify-between gap-4">
                        <SheetTitle className="text-xl font-bold font-mono tracking-tight text-foreground">
                            {displayBatch?.batchNo}
                        </SheetTitle>
                        <span className={`shrink-0 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold border ${displayBatch?.status === ProcessStatus.Aeration ? "bg-primary/10 text-primary border-primary/20" :
                            displayBatch?.status === ProcessStatus.AerationDone ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" :
                                "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20"
                            }`}>
                            <span className={`h-1.5 w-1.5 rounded-full ${displayBatch?.status === ProcessStatus.Aeration ? "bg-primary animate-pulse" :
                                displayBatch?.status === ProcessStatus.AerationDone ? "bg-emerald-500" : "bg-amber-500"
                                }`} />
                            {displayBatch?.status === ProcessStatus.Aeration ? "Đang sục" : displayBatch?.status === ProcessStatus.AerationDone ? "Done" : "Chờ xử lý"}
                        </span>
                    </div>
                    <SheetDescription className="mt-1.5 text-xs font-medium">
                        Tạo ngày: <span className="text-foreground">{displayBatch?.createdDate ? format(new Date(displayBatch.createdDate), "dd.MMM.yyyy") : "N/A"}</span> &bull; Khử trùng: <span className="text-foreground">{displayBatch?.sterilizeDate ? format(new Date(displayBatch.sterilizeDate), "dd.MMM.yyyy") : "N/A"}</span>
                    </SheetDescription>
                </SheetHeader>

                <div className="p-6 space-y-6">
                    {/* Quick Stats Grid */}
                    <div className="grid grid-cols-2 gap-3">
                        <div className="bg-card p-4 rounded-xl border shadow-xs flex flex-col justify-center">
                            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Vị trí sục khí</p>
                            <p className="font-mono font-semibold text-base text-foreground">{displayBatch?.batchInAerationPositionDtos?.map((pos: any) => pos.aerationPosition?.positionCode).join(", ") || "Chưa xếp"}</p>
                        </div>
                        <div className="bg-card p-4 rounded-xl border shadow-xs flex flex-col justify-center">
                            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Tổng sản lượng</p>
                            <p className="font-semibold text-base text-foreground">{displayBatch?.qty || "0"}</p>
                        </div>
                    </div>

                    <Separator className="bg-border/60" />

                    {/* List of Items */}
                    <div>
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="font-semibold text-sm text-foreground">Lot List trong Batch {isLoading && <span className="text-xs text-muted-foreground font-normal ml-2">(Loading...)</span>}</h3>
                            <span className="bg-muted text-muted-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">
                                {displayBatch?.batchItemDtos?.length || 0} mục
                            </span>
                        </div>

                        {displayBatch?.batchItemDtos?.length ? (
                            <div className="space-y-3">
                                {displayBatch.batchItemDtos.map((item: any, idx: number) => (
                                    <div key={idx} className="p-3 bg-card rounded-lg border shadow-xs flex flex-col gap-2 relative overflow-hidden">
                                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/40"></div>
                                        <div className="flex justify-between items-start pl-1">
                                            <div>
                                                <div className="font-semibold text-foreground text-sm flex items-center gap-2">
                                                    {item.internalLot || item.InternalLot || "N/A"}
                                                    {(() => {
                                                        const statusDesc = item.statusDescription || item.StatusDescription;
                                                        if (!statusDesc) return null;
                                                        const colorConfig = PLAN_STATUS_COLORS[statusDesc] || DEFAULT_STATUS_COLOR;
                                                        const translatedDesc = PLAN_STATUS_TRANSLATIONS[statusDesc] || statusDesc;

                                                        return (
                                                            <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-1.5 py-0.5 text-[9px] font-medium border ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}>
                                                                <span className={`h-1 w-1 rounded-full ${colorConfig.dot}`} />
                                                                {translatedDesc}
                                                            </span>
                                                        );
                                                    })()}
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <div className="text-xs font-semibold text-primary bg-primary/10 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                                    <span>SL:</span> {item.qtyInput || item.Qty || 0}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-border/50 pl-1">
                                            <div className="flex flex-col">
                                                <span className="text-[10px] uppercase text-muted-foreground font-medium mb-0.5">Vào sục khí</span>
                                                <span className="text-xs font-mono font-medium text-foreground">{(item.inputAerationDate || item.InputAerationDate) ? format(new Date(item.inputAerationDate || item.InputAerationDate), "dd.MMM.yy HH:mm") : "N/A"}</span>
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-[10px] uppercase text-muted-foreground font-medium mb-0.5">Kế hoạch ra</span>
                                                <span className="text-xs font-mono font-medium text-foreground">{(item.planOutputAerationDate || item.PlanOutputAerationDate) ? format(new Date(item.planOutputAerationDate || item.PlanOutputAerationDate), "dd.MMM.yy HH:mm") : "N/A"}</span>
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-[10px] uppercase text-muted-foreground font-medium mb-0.5">Thực tế ra</span>
                                                <span className="text-xs font-mono font-medium text-foreground">{(item.actualOutputAerationDate || item.ActualOutputAerationDate) ? format(new Date(item.actualOutputAerationDate || item.ActualOutputAerationDate), "dd.MMM.yy HH:mm") : "N/A"}</span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center py-12 text-center bg-muted/30 rounded-xl border border-dashed border-border/60">
                                <p className="text-sm font-medium text-muted-foreground mb-1">Chưa có sản phẩm</p>
                                <p className="text-xs text-muted-foreground/70">Lô này chưa được gán sản phẩm nào</p>
                            </div>
                        )}
                    </div>
                </div>
            </SheetContent>
        </Sheet>
    )
}
