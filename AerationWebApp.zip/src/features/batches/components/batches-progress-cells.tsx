import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { RiCalendarLine } from "@remixicon/react";
import { format, parseISO } from "date-fns";

// ─── Constants ────────────────────────────────────────────────────────────────

export const CREATED_STATUSES = ["Created", "Aeration", "Boxing", "Packing", "Done"];

export const STATUS_STYLES: Record<string, string> = {
    Created: "bg-slate-500/15 text-slate-400 border-slate-500/30",
    Aeration: "bg-sky-500/15 text-sky-400 border-sky-500/30",
    Boxing: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    Packing: "bg-violet-500/15 text-violet-400 border-violet-500/30",
    Done: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

export function formatDate(value?: string | null): string {
    if (!value) return "—";
    try {
        return format(parseISO(value), "dd.MMM.yy - HH:mm");
    } catch {
        return value;
    }
}

// ─── Cell Components ──────────────────────────────────────────────────────────

export function DateCell({ value }: { value?: string | null }) {
    if (!value) {
        return <span className="text-muted-foreground/40 text-xs">—</span>;
    }
    return (
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <RiCalendarLine className="h-3 w-3 shrink-0 text-primary/50" />
            {formatDate(value)}
        </span>
    );
}

export function StatusBadge({ status }: { status?: string | null }) {
    const style =
        STATUS_STYLES[status ?? ""] ?? "bg-gray-500/15 text-gray-400 border-gray-500/30";
    return (
        <Badge
            variant="outline"
            className={cn("text-[11px] font-medium px-2 py-0.5 rounded-full border", style)}
        >
            {status ?? "N/A"}
        </Badge>
    );
}

import type { BatchItemInPackingPositionDto } from "../types/batches.types";

export function PackingPositionCell({
    items,
}: {
    items?: BatchItemInPackingPositionDto[];
}) {
    if (!items || items.length === 0) {
        return <span className="text-muted-foreground/40 text-xs">—</span>;
    }
    return (
        <div className="flex flex-wrap gap-1">
            {items.map((item, idx) => (
                <span
                    key={idx}
                    className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[11px] font-medium bg-violet-500/15 text-violet-400 border border-violet-500/30 whitespace-nowrap"
                >
                    {item.packingPosition.positionCode}
                </span>
            ))}
        </div>
    );
}
