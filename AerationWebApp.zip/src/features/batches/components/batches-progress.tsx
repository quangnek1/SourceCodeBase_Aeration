import { useState, useMemo, useRef, useCallback, useEffect } from "react";
import { useSettings } from "@/hooks/useSettings";
import { useBatchProgress } from "../hooks/useBatchProgress";
import type { ItemProgressDto } from "../types/batches.types";
import { DataTablePagination } from "@/components/data-table-pagination";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RiSearchLine, RiLoader4Line, RiFullscreenLine, RiFullscreenExitLine, RiArrowUpSLine, RiArrowDownSLine, RiFilterOffLine } from "@remixicon/react";
import { cn } from "@/lib/utils";
import { COLUMNS, SECTION_SPANS } from "./batches-progress-columns";

// ─── Component ────────────────────────────────────────────────────────────────

export function BatchesProgress() {
    const containerRef = useRef<HTMLDivElement>(null);

    const [pageIndex, setPageIndex] = useState(1);
    const { settings } = useSettings();
    const pageSize = settings.pageSize;
    const [search, setSearch] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [isFullscreen, setIsFullscreen] = useState(false);

    // ── Sort (multi-column) ─────────────────────────────────────────────────────
    type SortState = { key: string; order: "Ascending" | "Descending" };
    const [sortStates, setSortStates] = useState<SortState[]>([]);

    const handleSort = useCallback((key: string) => {
        setSortStates((prev) => {
            const idx = prev.findIndex((s) => s.key === key);
            if (idx === -1) {
                // Cột chưa sort → thêm vào cuối với Ascending
                return [...prev, { key, order: "Ascending" }];
            }
            if (prev[idx].order === "Ascending") {
                // Đang Ascending → chuyển sang Descending
                return prev.map((s, i) => i === idx ? { ...s, order: "Descending" } : s);
            }
            // Đang Descending → xóa khỏi danh sách sort
            return prev.filter((_, i) => i !== idx);
        });
        setPageIndex(1);
    }, []);

    // Build sort string: "batchno:asc,internallot:desc"
    const sortString = useMemo(
        () => sortStates.length
            ? sortStates.map((s) => `${s.key}:${s.order === "Ascending" ? "asc" : "desc"}`).join(",")
            : undefined,
        [sortStates]
    );

    // ── Fullscreen ─────────────────────────────────────────────────────────────
    const toggleFullscreen = useCallback(() => {
        if (!document.fullscreenElement) {
            containerRef.current?.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    }, []);

    // Sync state khi người dùng thoát fullscreen bằng phím Esc
    useEffect(() => {
        const handleChange = () => {
            setIsFullscreen(!!document.fullscreenElement);
        };
        document.addEventListener("fullscreenchange", handleChange);
        return () => document.removeEventListener("fullscreenchange", handleChange);
    }, []);

    // ── Search ─────────────────────────────────────────────────────────────────
    const handleSearch = (value: string) => {
        setSearch(value);
        const t = setTimeout(() => {
            setDebouncedSearch(value);
            setPageIndex(1);
        }, 400);
        return () => clearTimeout(t);
    };

    const { data, isLoading, isFetching } = useBatchProgress({
        searchTerm: debouncedSearch || undefined,
        sort: sortString,
        pageIndex,
        pageSize,
    });

    const rows = useMemo(() => data?.items ?? [], [data]);
    const pagination = data;

    // ── skeleton rows ──────────────────────────────────────
    const skeletonRows = Array.from({ length: pageSize }, (_, i) => i);

    return (
        <div
            ref={containerRef}
            className={cn(
                "flex flex-col gap-4",
                // Khi fullscreen: fill toàn màn hình, có padding và bg riêng
                isFullscreen && "bg-background p-6 overflow-y-auto h-full"
            )}
        >
            {/* Header */}
            <div className="flex flex-col gap-1">
                <h1 className="text-xl font-bold tracking-tight">Tiến độ Lô hàng</h1>
                <p className="text-sm text-muted-foreground">
                    Theo dõi tiến trình từ trạng thái <span className="font-medium text-foreground">Created</span> đến hoàn tất
                </p>
            </div>

            {/* Toolbar */}
            <div className="flex items-center gap-3">
                {/* Search */}
                <div className="relative flex-1 max-w-sm">
                    <RiSearchLine className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                        id="batch-progress-search"
                        placeholder="Tìm kiếm theo batch, lot..."
                        value={search}
                        onChange={(e) => handleSearch(e.target.value)}
                        className="pl-9 h-9 text-sm"
                    />
                </div>

                {/* Fetching spinner */}
                {isFetching && !isLoading && (
                    <RiLoader4Line className="h-4 w-4 animate-spin text-muted-foreground" />
                )}

                {/* Spacer */}
                <div className="flex-1" />

                {/* Reset sort button — chỉ hiện khi đang có sort */}
                {sortStates.length > 0 && (
                    <Button
                        id="batch-progress-reset-sort"
                        variant="outline"
                        size="sm"
                        onClick={() => { setSortStates([]); setPageIndex(1); }}
                        className="h-9 gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
                        title="Bỏ tất cả sort"
                    >
                        <RiFilterOffLine className="h-4 w-4" />
                        Reset sort
                    </Button>
                )}

                {/* Fullscreen button */}
                <Button
                    id="batch-progress-fullscreen"
                    variant="outline"
                    size="sm"
                    onClick={toggleFullscreen}
                    className="h-9 gap-1.5 text-xs font-medium"
                    title={isFullscreen ? "Thoát toàn màn hình" : "Xem toàn màn hình"}
                >
                    {isFullscreen
                        ? <><RiFullscreenExitLine className="h-4 w-4" /> Thoát</>
                        : <><RiFullscreenLine className="h-4 w-4" /> Toàn màn hình</>
                    }
                </Button>
            </div>

            {/* Table */}
            <div className="rounded-xl border border-border/60 bg-card overflow-auto shadow-sm">
                <table className="w-full text-sm min-w-max">
                    <thead>
                        {/* Section header */}
                        <tr className="border-b border-border/40">
                            {SECTION_SPANS.map((sec, i) => (
                                <th
                                    key={i}
                                    colSpan={sec.cols}
                                    className={cn(
                                        "px-3 py-2 text-center text-xs font-semibold tracking-wide border-b-2",
                                        sec.className
                                    )}
                                >
                                    {sec.label}
                                </th>
                            ))}
                        </tr>
                        {/* Column header */}
                        <tr className="border-b border-border/40 bg-muted/40">
                            {COLUMNS.map((col) => {
                                const effectiveKey = col.sortKey ?? col.key;
                                const sortIdx = sortStates.findIndex((s) => s.key === effectiveKey);
                                const isActive = sortIdx !== -1;
                                const colSort = isActive ? sortStates[sortIdx] : null;
                                return (
                                    <th
                                        key={col.key}
                                        onClick={col.sortable ? () => handleSort(effectiveKey) : undefined}
                                        className={cn(
                                            "px-3 py-2.5 text-left text-xs font-medium text-muted-foreground whitespace-nowrap",
                                            col.span,
                                            col.sortable && "cursor-pointer select-none hover:text-foreground hover:bg-muted/60 transition-colors duration-100",
                                            isActive && "text-foreground"
                                        )}
                                    >
                                        <span className="inline-flex items-center gap-0.5">
                                            {col.label}
                                            {isActive && colSort && (
                                                <span className="inline-flex items-center gap-px text-primary">
                                                    {colSort.order === "Ascending"
                                                        ? <RiArrowUpSLine className="h-3.5 w-3.5" />
                                                        : <RiArrowDownSLine className="h-3.5 w-3.5" />
                                                    }
                                                    {sortStates.length > 1 && (
                                                        <span className="text-[9px] font-bold leading-none">{sortIdx + 1}</span>
                                                    )}
                                                </span>
                                            )}
                                        </span>
                                    </th>
                                );
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            skeletonRows.map((i) => (
                                <tr key={i} className="border-b border-border/30">
                                    {COLUMNS.map((col) => (
                                        <td key={col.key} className="px-3 py-3">
                                            <Skeleton className="h-4 w-full max-w-[120px] rounded" />
                                        </td>
                                    ))}
                                </tr>
                            ))
                        ) : rows.length === 0 ? (
                            <tr>
                                <td
                                    colSpan={COLUMNS.length}
                                    className="px-3 py-16 text-center text-sm text-muted-foreground"
                                >
                                    Không có dữ liệu
                                </td>
                            </tr>
                        ) : (
                            rows.map((row: ItemProgressDto, idx: number) => {
                                const no = (pageIndex - 1) * pageSize + idx + 1;
                                return (
                                    <tr
                                        key={row.id}
                                        className="border-b border-border/30 hover:bg-muted/30 transition-colors duration-150"
                                    >
                                        {COLUMNS.map((col) => (
                                            <td
                                                key={col.key}
                                                className={cn("px-3 py-2.5 align-top", col.span)}
                                            >
                                                {col.render(row, no)}
                                            </td>
                                        ))}
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            {pagination && (
                <DataTablePagination
                    pageIndex={pagination.pageIndex}
                    totalPages={pagination.totalPages}
                    totalCount={pagination.totalCount}
                    pageSize={pagination.pageSize}
                    onPageChange={setPageIndex}
                />
            )}
        </div>
    );
}
