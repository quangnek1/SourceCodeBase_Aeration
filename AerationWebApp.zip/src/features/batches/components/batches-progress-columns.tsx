import React from 'react'
import type { ItemProgressDto } from '../types/batches.types'
import {
  DateCell,
  StatusBadge,
  PackingPositionCell,
} from './batches-progress-cells'

// ─── Column Definition ────────────────────────────────────────────────────────

export interface ColDef {
  key: string
  label: string
  span?: string
  sortable?: boolean
  sortKey?: string // Tên property backend expect (nếu khác key)
  render: (row: ItemProgressDto, no: number) => React.ReactNode
}

export const COLUMNS: ColDef[] = [
  {
    key: 'no',
    label: '#',
    span: 'w-10',
    render: (_, no) => (
      <span className="text-xs text-muted-foreground">{no}</span>
    ),
  },
  {
    key: 'batchNo',
    label: 'Batch No',
    span: 'min-w-[120px]',
    sortable: true,
    sortKey: 'batchno',
    render: (row) => (
      <span className="text-sm font-semibold text-foreground">
        {row.batchDto?.batchNo}
      </span>
    ),
  },
  {
    key: 'status',
    label: 'Status',
    span: 'min-w-[110px]',
    sortable: true,
    sortKey: 'status',
    render: (row) => <StatusBadge status={row.status} />,
  },
  {
    key: 'internalLot',
    label: 'Internal Lot',
    span: 'min-w-[130px]',
    sortable: true,
    sortKey: 'internallot',
    render: (row) =>
      row.internalLot ? (
        <span className="text-xs text-foreground/80">{row.internalLot}</span>
      ) : (
        <span className="text-xs text-muted-foreground/40">—</span>
      ),
  },
  {
    key: 'keep',
    label: 'Keep',
    span: 'min-w-[90px]',
    render: (row) =>
      row.keepAeration != null ? (
        <span className="text-xs">{row.keepAeration}</span>
      ) : (
        <span className="text-xs text-muted-foreground/40">—</span>
      ),
  },
  // ── Aeration ──────────────────────────────────────────────────────────────
  {
    key: 'inputAerationDate',
    label: 'Input Aeration',
    span: 'min-w-[130px]',
    sortable: true,
    sortKey: 'inputaerationdate',
    render: (row) => <DateCell value={row.inputAerationDate} />,
  },
  {
    key: 'planOutputAerationDate',
    label: 'Plan Output Aeration',
    span: 'min-w-[150px]',
    sortable: true,
    sortKey: 'planoutputaerationdate',
    render: (row) => <DateCell value={row.planOutputAerationDate} />,
  },
  {
    key: 'actualOutputAerationDate',
    label: 'Actual Output Aeration',
    span: 'min-w-[160px]',
    sortable: true,
    sortKey: 'actualoutputaerationdate',
    render: (row) => <DateCell value={row.actualOutputAerationDate} />,
  },
  // ── Boxing ────────────────────────────────────────────────────────────────
  {
    key: 'inputBoxingDate',
    label: 'Input Boxing',
    span: 'min-w-[120px]',
    sortable: true,
    sortKey: 'inputboxingdate',
    render: (row) => <DateCell value={row.inputBoxingDate} />,
  },

  {
    key: 'outputBoxingDate',
    label: 'Output Boxing',
    span: 'min-w-[120px]',
    sortable: true,
    sortKey: 'outputboxingdate',
    render: (row) =>
      row.outputBoxingDate ? (
        <DateCell value={row.outputBoxingDate} />
      ) : (
        <span className="text-xs text-foreground/80">
          {row.currentQty} / {row.targetQty}
        </span>
      ),
  },
  // ── Packing ───────────────────────────────────────────────────────────────
  {
    key: 'inputPackingDate',
    label: 'Input Packing',
    span: 'min-w-[120px]',
    sortable: true,
    sortKey: 'inputpackingdate',
    render: (row) => <DateCell value={row.inputPackingDate} />,
  },
  {
    key: 'packingPosition',
    label: 'Position',
    span: 'min-w-[140px]',
    render: (row) => (
      <PackingPositionCell items={row.batchItemInPackingPositionDtos} />
    ),
  },
  {
    key: 'outputPackingDate',
    label: 'Output Packing',
    span: 'min-w-[130px]',
    sortable: true,
    sortKey: 'outputpackingdate',
    render: (row) => <DateCell value={row.outputPackingDate} />,
  },
]

// ─── Section header spans ─────────────────────────────────────────────────────

export const SECTION_SPANS = [
  { label: '', cols: 5, className: '' }, // #, Batch, Status, Lot, Keep
  {
    label: '🌬️ Aeration',
    cols: 3,
    className: 'bg-sky-500/10 text-sky-400 border-b-sky-500/30',
  },
  {
    label: '📦 Boxing',
    cols: 2,
    className: 'bg-amber-500/10 text-amber-400 border-b-amber-500/30',
  },
  {
    label: '🎁 Packing',
    cols: 3,
    className: 'bg-violet-500/10 text-violet-400 border-b-violet-500/30',
  }, // Input, Output, Position
]
