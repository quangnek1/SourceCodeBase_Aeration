import { useState } from "react";
import { useSettings } from "@/hooks/useSettings";
import { Button } from "@/components/ui/button";
import { DataTablePagination } from "@/components/data-table-pagination";
import { Skeleton } from "@/components/ui/skeleton";
import { useBatches } from "../hooks/useBatches";
import { RiEyeLine, RiFilterLine, RiSearchLine, RiLoader4Line, RiPrinterLine, RiLoginBoxLine, RiLogoutBoxLine, RiTimeLine } from "@remixicon/react";
import { toast } from "sonner";
import { batchesApi } from "../api/batches.api";
import { BatchDetailsSheet } from "./batch-details-sheet";
import { ProcessStatus } from "../../plans/types/plans.types";
import type { Batch } from "../types/batches.types";
import { PLAN_STATUS_COLORS, PLAN_STATUS_TRANSLATIONS, DEFAULT_STATUS_COLOR } from "../../plans/types/plans.types";
import { useOutputAerationBatch } from "../hooks/useOutputAerationBatch";

import { InputAerationModal } from "./modals/input-aeration-modal";
import { OutputAerationModal } from "./modals/output-aeration-modal";
import { PdfModal } from "./modals/pdf-modal";
import { AdjustAerationTimeModal } from "./modals/adjust-aeration-time-modal";

export function BatchesComponent() {
    const [pageIndex, setPageIndex] = useState(1);
    const { settings } = useSettings();
    const pageSize = settings.pageSize;

    const { data, isLoading } = useBatches(pageIndex, pageSize);
    const batches = data?.items || [];
    const pagination = data;

    const [selectedBatch, setSelectedBatch] = useState<any>(null);
    const [batchToInput, setBatchToInput] = useState<Batch | null>(null);

    const outputAerationMutation = useOutputAerationBatch();

    const [pdfModalOpen, setPdfModalOpen] = useState(false);
    const [pdfUrl, setPdfUrl] = useState<string | null>(null);
    const [isGeneratingPdf, setIsGeneratingPdf] = useState<number | null>(null);

    const [batchToOutput, setBatchToOutput] = useState<Batch | null>(null);
    const [isAdjustTimeModalOpen, setIsAdjustTimeModalOpen] = useState(false);

    const handleViewDetails = (batch: Batch) => {
        setSelectedBatch(batch);
    };


    const handlePrintPdf = async (batch: Batch) => {
        setIsGeneratingPdf(batch.id);
        try {
            const blob = await batchesApi.getBatchPdf(batch.id);
            const url = URL.createObjectURL(blob);
            setPdfUrl(url);
            setPdfModalOpen(true);
        } catch (error) {
            toast.error("Unable to load PDF file");
        } finally {
            setIsGeneratingPdf(null);
        }
    };

    return (
        <div className="space-y-6">
            {/* Page Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-foreground">Batch Management</h2>
                    <p className="text-sm text-muted-foreground mt-1">List of batches being processed in the system</p>
                </div>
                <div className="flex items-center gap-2">
                    <Button
                        className="gap-2 shadow-sm bg-indigo-600 hover:bg-indigo-700 text-white"
                        onClick={() => setIsAdjustTimeModalOpen(true)}
                    >
                        <RiTimeLine className="h-4 w-4" />
                        Adjust Aeration Time
                    </Button>
                </div>
            </div>

            {/* Toolbar / Filters */}
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-card p-3 rounded-xl border border-border shadow-xs">
                <div className="relative w-full sm:max-w-xs">
                    <RiSearchLine className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <input
                        type="text"
                        placeholder="Search batch no, product name..."
                        className="w-full pl-10 pr-4 py-2 border border-border rounded-lg text-sm bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                    />
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="gap-1 text-xs">
                        <RiFilterLine className="h-4 w-4" /> Filter Status
                    </Button>
                    <span className="text-xs text-muted-foreground">Total {pagination?.totalCount || batches.length} results</span>
                </div>
            </div>

            {/* Batches Table Card */}
            <div className="bg-card rounded-xl border border-border shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm border-collapse">
                        <thead>
                            <tr className="bg-muted/40 border-b border-border text-xs text-muted-foreground">
                                <th className="px-3 py-2 font-medium">#</th>
                                <th className="px-3 py-2 font-medium">Batch No</th>
                                <th className="px-3 py-2 font-medium">Ster Date</th>
                                <th className="px-3 py-2 font-medium">Position</th>
                                <th className="px-3 py-2 font-medium">Created Date</th>
                                <th className="px-3 py-2 font-medium">Status</th>
                                <th className="px-3 py-2 font-medium text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border/60">
                            {isLoading ? (
                                Array.from({ length: 5 }).map((_, idx) => (
                                    <tr key={idx} className="hover:bg-muted/20 transition-colors">
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-8" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-32" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-24" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-16" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-4 w-24" /></td>
                                        <td className="px-3 py-2"><Skeleton className="h-5 w-24 rounded-full" /></td>
                                        <td className="px-3 py-2">
                                            <div className="flex items-center justify-end gap-1.5">
                                                <Skeleton className="h-8 w-8 rounded-md" />
                                                <Skeleton className="h-8 w-8 rounded-md" />
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            ) : batches.length > 0 ? (
                                batches.map((batch) => {
                                    return (
                                        <tr key={batch.id} className="hover:bg-muted/20 transition-colors">
                                            <td className="px-3 py-2 font-mono font-medium text-xs text-foreground">{batch.no}</td>
                                            <td className="px-3 py-2 font-medium">{batch.batchNo}</td>
                                            <td className="px-3 py-2 text-muted-foreground">{batch.sterilizeDate}</td>
                                            <td className="px-3 py-2 text-xs font-mono">{batch.position}</td>
                                            <td className="px-3 py-2 text-muted-foreground text-xs">{batch.createdDate}</td>
                                            <td className="px-3 py-2">
                                                {(() => {
                                                    const statusDesc = batch.status || "";

                                                    const colorConfig = PLAN_STATUS_COLORS[statusDesc] || DEFAULT_STATUS_COLOR;
                                                    const translatedDesc = PLAN_STATUS_TRANSLATIONS[statusDesc] || statusDesc || "Plan";

                                                    return (
                                                        <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium border ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}>
                                                            <span className={`h-1.5 w-1.5 rounded-full ${colorConfig.dot}`} />
                                                            {translatedDesc}
                                                        </span>
                                                    );
                                                })()}
                                            </td>
                                            <td className="px-3 py-2 text-right">
                                                <div className="flex items-center justify-end gap-1.5">
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        className="h-8 px-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border-indigo-200"
                                                        title="Print PDF"
                                                        onClick={() => handlePrintPdf(batch)}
                                                        disabled={isGeneratingPdf === batch.id}
                                                    >
                                                        {isGeneratingPdf === batch.id ? <RiLoader4Line className="h-4 w-4 animate-spin" /> : <RiPrinterLine className="h-4 w-4" />}
                                                    </Button>
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        className="h-8 px-2"
                                                        title="Details"
                                                        onClick={() => handleViewDetails(batch)}
                                                    >
                                                        <RiEyeLine className="h-4 w-4" />
                                                    </Button>
                                                    {batch.status === ProcessStatus.AerationDone ? (
                                                        <Button
                                                            variant="default"
                                                            size="sm"
                                                            className="h-8 px-2 bg-blue-600 hover:bg-blue-700"
                                                            title="Move Out Aeration Area"
                                                            onClick={() => {
                                                                setBatchToOutput(batch);
                                                            }}
                                                            disabled={outputAerationMutation.isPending}
                                                        >
                                                            <RiLogoutBoxLine className="h-4 w-4" />
                                                        </Button>
                                                    ) : batch.status === ProcessStatus.Created ? (
                                                        <Button
                                                            variant="default"
                                                            size="sm"
                                                            className="h-8 px-2 bg-green-600 hover:bg-green-700 text-white"
                                                            title="Move To Aeration Area"
                                                            onClick={() => {
                                                                setBatchToInput(batch);
                                                            }}
                                                        >
                                                            <RiLoginBoxLine className="h-4 w-4" />
                                                        </Button>
                                                    ) : null}
                                                </div>
                                            </td>
                                        </tr>
                                    )
                                })
                            ) : (
                                <tr>
                                    <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground text-sm">
                                        No batch data available.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination Controls */}
                {pagination && (
                    <DataTablePagination
                        pageIndex={pageIndex}
                        pageSize={pageSize}
                        totalCount={pagination.totalCount}
                        totalPages={pagination.totalPages}
                        onPageChange={setPageIndex}
                    />
                )}
            </div>

            {/* Batch Details - Slide over panel */}
            <BatchDetailsSheet batch={selectedBatch} onClose={() => setSelectedBatch(null)} />

            {/* Input Aeration Modal */}
            {batchToInput && (
                <InputAerationModal
                    batch={batchToInput}
                    onClose={() => setBatchToInput(null)}
                />
            )}

            {/* Output Aeration Modal */}
            {batchToOutput && (
                <OutputAerationModal
                    batch={batchToOutput}
                    onClose={() => setBatchToOutput(null)}
                />
            )}

            {/* PDF Modal */}
            <PdfModal
                isOpen={pdfModalOpen}
                onClose={() => setPdfModalOpen(false)}
                pdfUrl={pdfUrl}
            />

            {/* Adjust Aeration Time Modal */}
            <AdjustAerationTimeModal
                open={isAdjustTimeModalOpen}
                onClose={() => setIsAdjustTimeModalOpen(false)}
            />
        </div>
    );
}
