import { axiosInstance } from "@/lib/axios";
import type { Batch, BatchPrintPdfDto, ItemProgressDto } from "../types/batches.types";
import type { ApiResponse, PaginatedResponse } from "@/types/dto";
import type { BatchProgressItem } from "../types/batches.types";


export const batchesApi = {
    getAllBatch: async (pageIndex: number = 1, pageSize: number = 10): Promise<PaginatedResponse<Batch>> => {
        const res = await axiosInstance.get<PaginatedResponse<Batch>>("/Batch/get-all-batch", {
            params: { pageIndex, pageSize }
        });
        return res.data;
    },

    getBatchById: async (id: string | number): Promise<ApiResponse<Batch>> => {
        const res = await axiosInstance.get<ApiResponse<Batch>>(`/Batch/${id}`);
        return res.data;
    },

    deleteBatch: async (id: string | number): Promise<ApiResponse<boolean>> => {
        const res = await axiosInstance.delete<ApiResponse<boolean>>(`/Batch/${id}`);
        return res.data;
    },

    inputAeration: async (batchId: number, positionIds: number[], date: string, location: string[]): Promise<ApiResponse<any>> => {
        const res = await axiosInstance.post<ApiResponse<any>>(`/Batch/input-aeration`, { batchId, positionIds, date, location });
        return res.data;
    },

    outputAeration: async (batchId: number, batchItems: number[], date?: string): Promise<ApiResponse<any>> => {
        const payload: any = { batchId, batchItems, date };
        if (date) payload.date = date;
        const res = await axiosInstance.post<ApiResponse<any>>(`/Batch/output-aeration`, payload);
        return res.data;
    },

    getBatchPdf: async (id: number): Promise<Blob> => {
        const res = await axiosInstance.get(`/Batch/get-batch-pdf`, {
            params: { id },
            responseType: 'blob'
        });
        return res.data;
    },

    getPositions: async (searchTerm?: string): Promise<any> => {
        const res = await axiosInstance.get(`/AerationPosition`, {
            params: { searchTerm, pageSize: 100 }
        });
        return res.data;
    },

    getBatchPrint: async (
        searchTerm?: string,
        sortColumn?: string,
        sortOrder: string = "Ascending",
        pageIndex: number = 1,
        pageSize: number = 10
    ): Promise<PaginatedResponse<BatchPrintPdfDto>> => {
        const res = await axiosInstance.get<PaginatedResponse<BatchPrintPdfDto>>("/Batch/get-batch-print", {
            params: { searchTerm, sortColumn, sortOrder, pageIndex, pageSize },
        });
        return res.data;
    },

    printAllBatchPdf: async (ids: number[]): Promise<Blob> => {
        const res = await axiosInstance.post("/Batch/print-all-batch-pdf", ids, {
            responseType: "blob",
        });
        return res.data;
    },

    getLotsForTimeAdjustment: async (): Promise<PaginatedResponse<ItemProgressDto>> => {
        const res = await axiosInstance.get<PaginatedResponse<ItemProgressDto>>("/Batch/get-all-items", {
            params: { pageSize: 200 }
        });
        return res.data;
    },

    adjustAerationTime: async (payload: { batchIds: number[], aerationTime: number }): Promise<ApiResponse<boolean>> => {
        const res = await axiosInstance.post<ApiResponse<boolean>>("/Batch/adjust-aeration-time", {
            BatchId: payload.batchIds,
            AerationTime: payload.aerationTime
        });
        return res.data;
    },

    getAllBatchProgress: async (
        searchTerm?: string,
        sortColumn?: string,
        sortOrder: string = "Ascending",
        pageIndex: number = 1,
        pageSize: number = 10
    ): Promise<PaginatedResponse<BatchProgressItem>> => {
        const res = await axiosInstance.get<PaginatedResponse<BatchProgressItem>>("/Batch/get-all-batch", {
            params: { searchTerm, sortColumn, sortOrder, pageIndex, pageSize },
        });
        return res.data;
    },

    getAllItemsProgress: async (
        searchTerm?: string,
        sort?: string,
        pageIndex: number = 1,
        pageSize: number = 10
    ): Promise<PaginatedResponse<ItemProgressDto>> => {
        const res = await axiosInstance.get<PaginatedResponse<ItemProgressDto>>("/Batch/get-all-items", {
            params: { searchTerm, sort, pageIndex, pageSize },
        });
        return res.data;
    },
};

