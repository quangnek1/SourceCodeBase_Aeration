export interface Batch {
  no: number
  id: number
  batchNo: string
  sterilizeDate: string
  createdDate: string
  status?: string
  inputAerationActual?: string | null
  planOutputAeration?: string | null
  actualOutputAeration?: string | null
  batchInAerationPositionDtos?: BatchInAerationPosition[]
  batchItemDtos?: BatchItem[]
}

export interface BatchPrintPdfDto {
  id: number
  sterilizeDate: string
  createdDate: string
  batchNo: string
  keep: number
  print: number
  status?: string | null
}

export const AerationStatus = {
  // Ví dụ: Pending = 0, Aerating = 1, Completed = 2
  Pending: 2,
  InProgress: 1,
  Done: 0,
} as const

export type AerationStatus =
  (typeof AerationStatus)[keyof typeof AerationStatus]

export const BatchStatus = {
  // Ví dụ: Pending = 0, Aerating = 1, Completed = 2
  Pending: 2,
  InProgress: 1,
  Done: 0,
} as const

export type BatchStatus = (typeof BatchStatus)[keyof typeof BatchStatus]

export interface AerationPosition {
  id: number
  positionCode: string
  image: string
  aerationColumnId: number
}

export interface BatchInAerationPosition {
  aerationPosition: AerationPosition
}

export interface BatchItem {
  id: number
  batchId: number
  dataPlanId: number
  numberRank?: string | null
  material?: string | null
  drawingListNo?: string | null
  itemName?: string | null
  destination?: string | null
  internalLot?: string | null
  externalLot1?: string | null
  qtyInput: number
  a?: string | null
  b?: string | null
  c?: string | null
  d?: string | null
  status?: string | null
  biobudent: number
  endotoxin: number
  particle: number
  qtyOutputSealing: number
  gaugeNoSealing?: string | null
  qtyOutputSterilize: number
  qtyFeaturesTest: number
  keepAeration: number
  keepSample?: string | null
  deliveryDatePlan?: string | null
  group?: string | null
  family: string

  // Aeration
  inputAerationDate?: string | null
  planOutputAerationDate?: string | null
  actualOutputAerationDate?: string | null

  // Boxing
  inputBoxingDate?: string | null
  outputBoxingDate?: string | null

  // Packing
  inputPackingDate?: string | null
  outputPackingDate?: string | null
}

export interface BatchProgressItem {
  id: number
  batchNo: string
  createdDate: string
  sterilizeDate: string
  status?: string | null

  // BatchItem fields (flattened from batchItemDtos)
  internalLot?: string | null
  keepAeration?: number
  keepSample?: string | null

  // Aeration dates
  inputAerationDate?: string | null
  planOutputAerationDate?: string | null
  actualOutputAerationDate?: string | null

  // Boxing dates
  inputBoxingDate?: string | null
  outputBoxingDate?: string | null

  // Packing dates
  inputPackingDate?: string | null
  outputPackingDate?: string | null

  batchItemDtos?: BatchItem[]
}

// ─── Item Progress (from /BatchItem/get-all-items) ────────────────────────────

export interface BatchSummaryDto {
  id: number
  batchNo: string
  sterilizeDate: string
  status?: string | null
}

export interface PackingPosition {
  id: number
  positionCode: string
  image: string
}

export interface BatchItemInPackingPositionDto {
  packingPosition: PackingPosition
}

export interface ItemProgressDto {
  id: number
  batchDto: BatchSummaryDto
  internalLot?: string | null
  keepAeration: number
  status?: string | null

  // Aeration
  inputAerationDate?: string | null
  planOutputAerationDate?: string | null
  actualOutputAerationDate?: string | null

  // Boxing
  inputBoxingDate?: string | null
  outputBoxingDate?: string | null

  // Packing
  inputPackingDate?: string | null
  outputPackingDate?: string | null
  batchItemInPackingPositionDtos?: BatchItemInPackingPositionDto[]

  targetQty: number| null
  currentQty: number | null
}
