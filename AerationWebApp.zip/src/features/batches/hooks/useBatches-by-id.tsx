import { useQuery } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";


export function useBatchesById(id?: number) {
    return useQuery({
        queryKey: ["batch", id],
        queryFn: async () => {
            if (!id) return null;

            const res = await batchesApi.getBatchById(id);

            if (!res.isSuccess || !res.value) {
                return null;
            }

            return res.value;
        },
        enabled: !!id,
    });
}