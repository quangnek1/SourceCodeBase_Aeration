import { useQuery } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";
import type { Batch } from "../types/batches.types";
import { format } from "date-fns";

export function useBatches(pageIndex: number = 1, pageSize: number = 10) {
    return useQuery({
        queryKey: ["batches", pageIndex, pageSize],
        queryFn: async () => {
            const response = await batchesApi.getAllBatch(pageIndex, pageSize);

            // Access items safely, fallback to empty array
            const items = response.value?.items || [];

            const mappedItems = items.map((batch: Batch, index: number) => ({
                no: (pageIndex - 1) * pageSize + index + 1,
                id: batch.id,
                batchNo: batch.batchNo,
                sterilizeDate: format(new Date(batch.sterilizeDate), "dd.MMM.yyyy"),
                createdDate: format(new Date(batch.createdDate), "dd.MMM.yyyy"),
                status: batch.status || (batch as any).Status,
                position: batch.batchInAerationPositionDtos?.map(pos => pos.aerationPosition.positionCode).join(", ") || "N/A",
                batchItemDtos: batch.batchItemDtos,
            }));

            return {
                items: mappedItems,
                pageIndex: response.value?.pageIndex || pageIndex,
                pageSize: response.value?.pageSize || pageSize,
                totalCount: response.value?.totalCount || 0,
                totalPages: response.value?.totalPages || 0,
            };
        },
    });
}