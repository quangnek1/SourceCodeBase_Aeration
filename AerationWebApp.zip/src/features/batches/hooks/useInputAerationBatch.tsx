import { useMutation, useQueryClient } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";
import { toast } from "sonner";

export function useInputAerationBatch() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ batchId, positionIds, date, location }: { batchId: number; positionIds: number[]; date: string; location: string[] }) => {
            const response = await batchesApi.inputAeration(batchId, positionIds, date, location);
            if (!response.isSuccess) {
                throw new Error(response.error?.message || "Error khi nhập mẻ vào phòng sục khí");
            }
            return response;
        },
        onSuccess: () => {
            toast.success("Đã đưa mẻ vào phòng sục khí thành công");
            queryClient.invalidateQueries({ queryKey: ["batches"] });
        },
        onError: (error: any) => {
            toast.error(error.message || "Operation failed, please try again later");
        },
    });
}
