import { useMutation, useQueryClient } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";
import { toast } from "sonner";

export function useDeleteBatch() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (id: number | string) => {
            const response = await batchesApi.deleteBatch(id);
            if (!response.isSuccess) {
                throw new Error(response.error?.message || "Error khi xóa mẻ");
            }
            return response;
        },
        onSuccess: () => {
            toast.success("Đã xóa mẻ thành công");
            queryClient.invalidateQueries({ queryKey: ["batches"] });
        },
        onError: (error: any) => {
            toast.error(error.message || "Không thể xóa mẻ, vui lòng thử lại sau");
        },
    });
}
