import { useMutation, useQueryClient } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";
import { toast } from "sonner";

export function useOutputAerationBatch() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ batchId, batchItems, date }: { batchId: number; batchItems: number[], date?: string }) => {
            const response = await batchesApi.outputAeration(batchId, batchItems, date);
            if (!response.isSuccess) {
                throw new Error(response.error?.message || "Error outputting batch from aeration room");
            }
            return response;
        },
        onSuccess: () => {
            toast.success("Successfully output batch from aeration room");
            queryClient.invalidateQueries({ queryKey: ["batches"] });
        },
        onError: (error: any) => {
            toast.error(error.message || "Operation failed, please try again later");
        },
    });
}
