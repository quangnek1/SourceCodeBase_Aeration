import { useQuery } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";

export function useAerationPositions() {
    return useQuery({
        queryKey: ["positions"],
        queryFn: () => batchesApi.getPositions()
    });
}
