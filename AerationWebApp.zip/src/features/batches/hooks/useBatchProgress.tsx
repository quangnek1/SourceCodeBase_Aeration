import { useQuery } from "@tanstack/react-query";
import { batchesApi } from "../api/batches.api";

export interface UseItemProgressParams {
    searchTerm?: string;
    sort?: string;          // vd: "batchno:asc,internallot:desc"
    pageIndex?: number;
    pageSize?: number;
}

export function useBatchProgress({
    searchTerm,
    sort,
    pageIndex = 1,
    pageSize = 10,
}: UseItemProgressParams = {}) {
    return useQuery({
        queryKey: ["item-progress", searchTerm, sort, pageIndex, pageSize],
        queryFn: async () => {
            const response = await batchesApi.getAllItemsProgress(
                searchTerm,
                sort,
                pageIndex,
                pageSize
            );

            const raw = (response as any)?.value ?? response;
            const items = raw?.items ?? [];

            return {
                items,
                pageIndex: raw?.pageIndex ?? pageIndex,
                pageSize: raw?.pageSize ?? pageSize,
                totalCount: raw?.totalCount ?? 0,
                totalPages: raw?.totalPages ?? 0,
            };
        },
        placeholderData: (prev) => prev,
    });
}
