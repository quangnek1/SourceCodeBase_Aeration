import { createBrowserRouter, Outlet } from "react-router-dom";
import { lazy, Suspense } from "react";

const ScanLayout = lazy(() =>
    import("@/layouts/scan-layout").then((m) => ({ default: m.ScanLayout }))
);
const QrScanPage = lazy(() =>
    import("@/features/qr-scan/qr-scan-page").then((m) => ({ default: m.QrScanPage }))
);

function ScanSuspense() {
    return (
        <Suspense fallback={<div className="flex h-screen items-center justify-center text-sm text-muted-foreground">Loading…</div>}>
            <Outlet />
        </Suspense>
    );
}

import { ProtectedRoute } from "./protected-route";

import { LoginPage } from "@/pages/auth/login-page";
import { ForgotPassword } from "@/features/auth/components/forgot-password";

import { MainLayout } from "@/layouts/main-layout";

import { NotFoundPage } from "@/pages/error/not-found";
import { BatchesComponent } from "@/features/batches/components/batches-component";
import { BatchesProgress } from "@/features/batches/components/batches-progress";

import { PlansComponent } from "@/features/plans/components/plans";
import { PlansPrint } from "@/features/plans/components/plans-print";
import { AmiQ411SyncComponent } from "@/features/plans/components/ami-q411-sync";
import { AerationMonitorPage } from "@/features/aeration-monitor";
import { DashboardView } from "@/features/dashboard";
import { SettingsView } from "@/features/settings";
import { BoxingScanPage } from "@/features/boxing-jobs";

export const router = createBrowserRouter([
    {
        path: "auth/login",
        element: <LoginPage />,
    },
    {
        path: "auth/forgot-password",
        element: <ForgotPassword />,
    },

    {
        element: <ProtectedRoute />,
        children: [
            {
                element: <MainLayout />,
                children: [
                    {
                        path: "/",
                        element: <DashboardView />,
                    },
                    {
                        path: "/batches",
                        element: <BatchesComponent />,
                    },
                    {
                        path: "/batches-progress",
                        element: <BatchesProgress />,
                    },
                    {
                        path: "/aerationroom",
                        element: <AerationMonitorPage />,
                    },
                    {
                        path: "/plan/ptca",
                        element: <PlansComponent filter="ptca" />,
                    },
                    {
                        path: "/plan/cag",
                        element: <PlansComponent filter="cag" />,
                    },
                    {
                        path: "/plan/ami-q411",
                        element: <AmiQ411SyncComponent />,
                    },
                    {
                        path: "/plan/print",
                        element: <PlansPrint />,
                    },
                    {
                        path: "/settings",
                        element: <SettingsView />,
                    },
                    {
                        path: "/system-config",
                        element: <SettingsView />,
                    },
                           {
                        path: "/boxing-jobs",
                        element: <SettingsView />,
                    },
                ],
            },
        ],
    },
    {
        // QR Scan — no auth required, minimal layout
        element: <ScanSuspense />,
        children: [
            {
                element: <ScanLayout />,
                children: [
                    {
                        path: "/scan",
                        element: <QrScanPage />,
                    },
                        {
                        path: "/boxing-scan",
                        element: <BoxingScanPage />,
                    },
                ],
            },
        ],
    },
    {
        path: "*",
        element: <NotFoundPage />,
    },
]);