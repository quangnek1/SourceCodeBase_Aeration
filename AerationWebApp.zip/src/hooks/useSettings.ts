import { useState, useEffect } from "react";

export interface SystemSettings {
    language: "vi" | "en";
    pageSize: number;
    theme: "light" | "dark" | "system";
}

const defaultSettings: SystemSettings = {
    language: "vi",
    pageSize: 10,
    theme: "system",
};

export function useSettings() {
    // Khởi tạo state từ localStorage
    const [settings, setSettingsState] = useState<SystemSettings>(() => {
        try {
            if (typeof window !== "undefined") {
                const item = window.localStorage.getItem("aeration_settings");
                if (item) {
                    const parsed = { ...defaultSettings, ...JSON.parse(item) };
                    // Đồng bộ theme sang key "theme" để ThemeProvider đọc khi refresh
                    window.localStorage.setItem("theme", parsed.theme);
                    return parsed;
                }
            }
        } catch (error) {
            console.error("Lỗi khi đọc settings từ localStorage", error);
        }
        return defaultSettings;
    });

    // Hàm cập nhật settings
    const updateSettings = (newSettings: Partial<SystemSettings>) => {
        setSettingsState((prev) => {
            const updated = { ...prev, ...newSettings };
            try {
                if (typeof window !== "undefined") {
                    window.localStorage.setItem("aeration_settings", JSON.stringify(updated));
                    // Đồng bộ theme sang key "theme" để ThemeProvider áp dụng
                    if (newSettings.theme !== undefined) {
                        window.localStorage.setItem("theme", updated.theme);
                    }
                }
            } catch (error) {
                console.error("Lỗi khi lưu settings vào localStorage", error);
            }
            return updated;
        });
    };


    // (Tùy chọn) Lắng nghe sự thay đổi từ các tab khác
    useEffect(() => {
        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === "aeration_settings" && e.newValue) {
                try {
                    const parsed = JSON.parse(e.newValue);
                    setSettingsState((prev) => ({ ...prev, ...parsed }));
                } catch (error) {
                    // Ignore parsing errors from other tabs
                }
            }
        };

        window.addEventListener("storage", handleStorageChange);
        return () => window.removeEventListener("storage", handleStorageChange);
    }, []);

    return { settings, updateSettings };
}
