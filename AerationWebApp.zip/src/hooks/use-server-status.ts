import { useCallback, useEffect, useRef, useState } from "react";
import { env } from "@/config/env";

export type ServerStatus = "checking" | "online" | "offline";

const HEALTH_ENDPOINT = `${env.API_BASE_URL}/Health`;
const PING_INTERVAL_MS = 10_000; // ping mỗi 10 giây
const TIMEOUT_MS = 3_000;        // timeout sau 3 giây
const FAIL_THRESHOLD = 2;        // số lần thất bại liên tiếp trước khi đổi sang offline

export function useServerStatus() {
    const [status, setStatus] = useState<ServerStatus>("checking");
    const [lastOnlineAt, setLastOnlineAt] = useState<Date | null>(null);
    const failCountRef = useRef(0);

    const ping = useCallback(async () => {
        const controller = new AbortController();
        const timerId = setTimeout(() => controller.abort(), TIMEOUT_MS);

        try {
            // Chỉ cần server phản hồi (bất kể status code) là coi như online.
            // 4xx / 5xx vẫn có nghĩa server đang chạy.
            // Chỉ network error hoặc timeout mới là thực sự offline.
            await fetch(HEALTH_ENDPOINT, {
                method: "GET",
                signal: controller.signal,
                cache: "no-store",
            });

            clearTimeout(timerId);
            failCountRef.current = 0;
            setStatus("online");
            setLastOnlineAt(new Date());

        } catch (err) {
            clearTimeout(timerId);
            failCountRef.current += 1;
            console.debug(`[ServerStatus] ping failed (${failCountRef.current}/${FAIL_THRESHOLD}):`, err);
            if (failCountRef.current >= FAIL_THRESHOLD) {
                setStatus("offline");
            }
        }
    }, []);

    useEffect(() => {
        // Ping ngay khi mount
        ping();

        const interval = setInterval(ping, PING_INTERVAL_MS);
        return () => clearInterval(interval);
    }, [ping]);

    return { status, lastOnlineAt };
}
