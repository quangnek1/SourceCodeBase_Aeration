import { useQuery } from "@tanstack/react-query"
import { apiClient, checkApiConnection } from "@/services/api-client"
import { type ApiResponse, type ProductDto, type DataPlanDto, mockData } from "@/types/dto"

// 1. Connection check hook
export function useApiStatus() {
  return useQuery({
    queryKey: ["api-status"],
    queryFn: checkApiConnection,
    refetchInterval: 10000, // Recheck every 10s
  })
}

// 2. Fetch products hook
export function useProducts() {
  return useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      try {
        const response = await apiClient.get<ApiResponse<{ items: ProductDto[] }>>("/Products")
        if (response.data.isSuccess && response.data.value) {
          // If response format has items property
          return response.data.value.items || response.data.value
        }
        throw new Error("Failed to load products from API")
      } catch (error) {
        console.warn("Products API error, falling back to mock data:", error)
        return mockData.products
      }
    },
  })
}

// 3. Fetch batches hook
export function useBatches(pageIndex = 1, pageSize = 50) {
  return useQuery({
    queryKey: ["batches", pageIndex, pageSize],
    queryFn: async () => {
      try {
        const response = await apiClient.get<any>("/Batch/get-all-batch", { params: { pageIndex, pageSize } })
        if (response.data.isSuccess && response.data.value) {
          return response.data.value.items || response.data.value || []
        }
        throw new Error("Failed to load batches from API")
      } catch (error) {
        console.warn("Batches API error, falling back to mock data:", error)
        return mockData.batches
      }
    },
  })
}

// 4. Fetch plans hook
export function usePlans() {
  return useQuery({
    queryKey: ["plans"],
    queryFn: async () => {
      try {
        const response = await apiClient.get<ApiResponse<DataPlanDto[]>>("/DataPlan/get-all-dataplan")
        if (response.data.isSuccess && response.data.value) {
          return response.data.value
        }
        throw new Error("Failed to load plans from API")
      } catch (error) {
        console.warn("Plans API error, falling back to mock data:", error)
        return mockData.plans
      }
    },
  })
}
