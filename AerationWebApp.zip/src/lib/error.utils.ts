// src/shared/utils/error.utils.ts

import axios from "axios";

export function getErrorMessage(error: unknown): string {
    if (!axios.isAxiosError(error)) {
        return "Đã xảy ra lỗi không xác định.";
    }

    // Server không chạy / mất mạng
    if (!error.response) {
        return "Không thể kết nối tới máy chủ.";
    }

    const status = error.response.status;

    switch (status) {
        case 400:
            console.error("400 Bad Request Details:", error.response.data);
            if (error.response.data?.errors) {
                const errorMessages = Object.values(error.response.data.errors).flat().join(", ");
                if (errorMessages) return errorMessages;
            }
            return error.response.data?.message ?? "Dữ liệu không hợp lệ.";

        case 401:
            return "Email hoặc mật khẩu không đúng.";

        case 403:
            return "Bạn không có quyền truy cập.";

        case 404:
            return "Không tìm thấy dữ liệu.";

        case 500:
            return "Hệ thống đang gặp sự cố.";

        default:
            return error.response.data?.message ?? "Đã xảy ra lỗi.";
    }
}