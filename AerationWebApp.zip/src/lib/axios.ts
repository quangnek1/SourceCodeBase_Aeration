import axios, { AxiosError, type InternalAxiosRequestConfig } from "axios";
import { env } from "@/config/env";
import { tokenUtils } from "@/features/auth/utils/token.utils";
import { useAuthStore } from "@/features/auth";

const REFRESH_ENDPOINT = "/auth/refresh-token";

// ===== Tạo instance với baseURL từ env =====
export const axiosInstance = axios.create({
    baseURL: env.API_BASE_URL, // ← Lấy từ env, 
    withCredentials: true,
    headers: {
        "Content-Type": "application/json",
    },
});

// Dev mode: log baseURL để confirm đúng môi trường
if (env.IS_DEV) {
    console.info(`🚀 API Base URL: ${env.API_BASE_URL}`);
}

// ===== Request Interceptor =====
// Gắn access token vào mọi request (nếu có)
axiosInstance.interceptors.request.use((config) => {
    const accessToken = tokenUtils.getAccessToken();
    if (accessToken) {
        config.headers.Authorization = `Bearer ${accessToken}`;
    }
    return config;
});

// ===== Response Interceptor =====
// Tự động refresh token khi nhận 401
let isRefreshing = false;
let pendingRequests: Array<{
    resolve: (token: string) => void;
    reject: (error: unknown) => void;
}> = [];

axiosInstance.interceptors.response.use(
    (response) => response,

    async (error: AxiosError) => {
        const originalRequest = error.config as InternalAxiosRequestConfig & {
            _retry?: boolean;
        };

        const is401 = error.response?.status === 401;
        const isNotRetried = !originalRequest._retry;
        const isNotRefreshEndpoint = !originalRequest.url?.includes(REFRESH_ENDPOINT);
        const clearUser = useAuthStore.getState().clearUser;

        if (is401 && isNotRetried && isNotRefreshEndpoint) {
            originalRequest._retry = true;

            // Nếu đang refresh rồi thì queue request lại, không gọi refresh nhiều lần
            if (isRefreshing) {
                return new Promise((resolve) => {
                    pendingRequests.push({ resolve: (newToken: string) => {
                        originalRequest.headers.Authorization = `Bearer ${newToken}`;
                        resolve(axiosInstance(originalRequest));
                    }, reject: () => resolve(Promise.reject(error)) });
                });
            }

            isRefreshing = true;

            try {
                const { data } = await axiosInstance.post(REFRESH_ENDPOINT);
                const newAccessToken = data.accessToken;
                tokenUtils.save(data);

                // Thực thi lại tất cả request đang chờ
                pendingRequests.forEach(({ resolve }) => resolve(newAccessToken));
                pendingRequests = [];

                originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
                return axiosInstance(originalRequest);
            } catch {
                // Refresh thất bại → đăng xuất
                tokenUtils.clear();
                clearUser();
                pendingRequests.forEach(({ reject }) => reject(error));
                pendingRequests = [];
                window.location.href = "/auth/login";
                return Promise.reject(error);
            } finally {
                isRefreshing = false;
            }
        }

        return Promise.reject(error);
    }
);