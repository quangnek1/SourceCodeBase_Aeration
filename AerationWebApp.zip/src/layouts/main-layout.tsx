import { AppSidebar } from "@/layouts/components/app-sidebar"
import { Header } from "@/layouts/components/header"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { TooltipProvider } from "@/components/ui/tooltip"

import { Outlet } from "react-router-dom";

export function MainLayout() {
    return (
        <TooltipProvider>
            <SidebarProvider>
                <div className="relative flex min-h-screen w-full">
                    <AppSidebar />

                    <SidebarInset>
                        <Header />

                        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6 lg:p-8 overflow-y-auto">
                            <Outlet />
                        </main>
                    </SidebarInset>
                </div>
            </SidebarProvider>
        </TooltipProvider>
    );
}

