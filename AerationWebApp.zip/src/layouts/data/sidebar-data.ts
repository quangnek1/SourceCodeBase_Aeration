import {
  LayoutDashboard,
  Layers,
  Boxes,
  ClipboardList,
  Settings,
  Bug,
  Lock,
  UserX,
  Wrench,
  Monitor,
  GalleryVertical,
  SquareM,
  ZodiacPisces,
  TableColumnsSplit,
  Printer,
  ClipboardCheck,
  BluetoothConnectedIcon,
  ScanBarcode,
} from 'lucide-react'
export type User = {
  name: string
  email: string
  avatar: string
}

export type Team = {
  name: string
  logo: React.ComponentType<{ className?: string }>
  plan: string
}

export type BaseNavItem = {
  title: string
  badge?: string
  icon?: React.ComponentType<{ className?: string }>
}

export type NavLink = BaseNavItem & {
  url: string
  items?: never
}

export type NavCollapsible = BaseNavItem & {
  items: (BaseNavItem & { url: string })[]
  url?: never
}

export type NavItem = NavCollapsible | NavLink

export type NavGroup = {
  title: string
  items: NavItem[]
}

export type SidebarData = {
  user: User
  teams: Team[]
  navGroups: NavGroup[]
}

export const sidebarData: SidebarData = {
  user: {
    name: 'Admin User',
    email: 'admin@aeration.com',
    avatar: '', // empty so it falls back to initial/letter badge
  },
  teams: [
    {
      name: 'Aeration Plant 01',
      logo: LayoutDashboard,
      plan: 'Production Factory',
    },
  ],
  navGroups: [
    {
      title: 'General',
      items: [
        {
          title: 'Tổng quan',
          url: '/',
          icon: LayoutDashboard,
        },
        {
          title: 'Quản lý Lô hàng',
          url: 'batches',
          icon: Layers,
          badge: 'New',
        },
        {
          title: 'Aeration Room Layout',
          url: 'aerationroom',
          icon: TableColumnsSplit,
        },
      ],
    },
    {
      title: 'Kế hoạch & Tiến độ',
      items: [
        {
          title: 'Tiến độ',
          url: 'batches-progress',
          icon: Boxes,
        },
        {
          title: 'In F-6112',
          url: 'plan/print',
          icon: Printer,
        },
        {
          title: 'Kế hoạch Aeration',
          icon: ClipboardList,
          items: [
            {
              title: 'PTCA Plan',
              url: 'plan/ptca',
              icon: GalleryVertical,
            },
            {
              title: 'CAG Plan',
              url: 'plan/cag',
              icon: SquareM,
            },
            {
              title: 'AMI Q411',
              url: 'plan/ami-q411',
              icon: ZodiacPisces,
            },
          ],
        },
      ],
    },
    {
      title: 'Boxing Job',
      items: [
        {
          title: 'Boxing Layout',
          url: 'scan',
          icon: LayoutDashboard,
        },
        {
          title: 'Boxing Control',
          url: 'scan',
          icon: BluetoothConnectedIcon,
        },
        {
          title: 'Boxing Scan',
          url: 'boxing-scan',
          icon: ScanBarcode,
        },
      ],
    },
    {
      title: 'Scan kế hoạch',
      items: [
        {
          title: 'In/Out Aeration',
          url: 'scan',
          icon: ClipboardCheck,
        },
      ],
    },
    {
      title: 'Hệ thống',
      items: [
        {
          title: 'Cấu hình',
          icon: Settings,
          items: [
            {
              title: 'Cài đặt chung',
              url: 'settings',
              icon: Wrench,
            },
            {
              title: 'Cấu hình hệ thống',
              url: 'system-config',
              icon: Monitor,
            },
          ],
        },
        {
          title: 'Errors Demo',
          icon: Bug,
          items: [
            {
              title: 'Unauthorized',
              url: 'dashboard', // fallback to dashboard for demo
              icon: Lock,
            },
            {
              title: 'Forbidden',
              url: 'dashboard',
              icon: UserX,
            },
          ],
        },
      ],
    },
  ],
}
