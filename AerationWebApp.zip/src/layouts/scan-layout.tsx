import { Outlet } from "react-router-dom";
import { useServerStatus } from "@/hooks/use-server-status";
import { ServerStatusBadge } from "@/components/server-status-badge";

export function ScanLayout() {
    const { status, lastOnlineAt } = useServerStatus();

    return (
        <div className="min-h-screen w-full bg-background flex flex-col items-center justify-start">
            <header className="w-full border-b px-4 py-3 flex items-center gap-2">
                <span className="text-sm font-semibold tracking-wide text-foreground">
                    QR Scan for Aeration Monitor
                </span>

                <div className="ml-auto">
                    <ServerStatusBadge status={status} lastOnlineAt={lastOnlineAt} />
                </div>
            </header>

            <main className="flex-1 w-full max-w-lg px-4 py-6">
                <Outlet />
            </main>
        </div>
    );
}
