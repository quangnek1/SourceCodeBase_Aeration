import React from 'react'
import { Leaf } from 'lucide-react'


interface AuthLayoutProps {
    children: React.ReactNode
}

export function AuthLayout({ children }: AuthLayoutProps) {
    return (
        <div className="relative min-h-screen w-full grid grid-cols-1 lg:grid-cols-2 overflow-hidden bg-background">
            {/* Left side: Premium Branding Panel (visible on desktop) */}
            <div className="relative hidden lg:flex flex-col justify-between p-10 text-white bg-zinc-950 dark:bg-zinc-900 border-r border-border/10 overflow-hidden">
                {/* Decorative Grid and Gradients */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />
                <div className="absolute top-[-20%] left-[-20%] h-[60%] w-[60%] rounded-full bg-emerald-500/10 blur-[120px]" />
                <div className="absolute bottom-[-20%] right-[-20%] h-[60%] w-[60%] rounded-full bg-emerald-500/10 blur-[120px]" />

                {/* Brand Logo & Name */}
                <div className="relative z-10 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500 text-white shadow-lg shadow-emerald-500/20">
                        <Leaf className="h-5.5 w-5.5 animate-pulse" />
                    </div>
                    <div>
                        <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent">
                            Aeration App
                        </h1>
                        <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold">
                            Management System
                        </p>
                    </div>
                </div>

                {/* Testimonial / Visual Element */}
                <div className="relative z-10 max-w-md space-y-6">
                    <blockquote className="space-y-2">
                        <p className="text-lg leading-relaxed text-zinc-300 font-medium italic">
                            "Tối ưu hóa quy trình, tăng hiệu quả vận hành và kiểm soát chất lượng mẻ ủ một cách toàn diện."
                        </p>
                        <footer className="text-sm text-emerald-400 font-medium">
                            — Hệ thống Giám sát & Quản lý Thông minh
                        </footer>
                    </blockquote>
                </div>

                {/* Footer info */}
                <div className="relative z-10 text-xs text-zinc-600 dark:text-zinc-500">
                    © {new Date().getFullYear()} Aeration App. All rights reserved.
                </div>
            </div>

            {/* Right side: Login Form Panel */}
            <div className="relative flex items-center justify-center p-6 sm:p-10 lg:p-16">
                {/* Decorative elements for mobile login */}
                <div className="absolute top-[-10%] right-[-10%] h-[40%] w-[40%] rounded-full bg-emerald-500/5 dark:bg-emerald-500/10 blur-[80px] lg:hidden" />
                <div className="absolute bottom-[-10%] left-[-10%] h-[40%] w-[40%] rounded-full bg-emerald-500/5 dark:bg-emerald-500/10 blur-[80px] lg:hidden" />

                <div className="relative w-full max-w-sm flex flex-col items-center">
                    {/* Mobile-only logo */}
                    <div className="flex flex-col items-center gap-2 mb-8 lg:hidden">
                        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500 text-white shadow-lg shadow-emerald-500/20">
                            <Leaf className="h-6 w-6" />
                        </div>
                        <h1 className="text-xl font-bold tracking-tight text-foreground">
                            Aeration App
                        </h1>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">
                            Management System
                        </p>
                    </div>

                    <div className="w-full">
                        {children}
                    </div>
                </div>
            </div>
        </div>
    )
}
