import type { ComponentProps } from "react"
import { Menu, X, Leaf } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { sidebarData } from "@/layouts/data/sidebar-data"

export function AppTitle() {
  const { state } = useSidebar()
  const isCollapsed = state === "collapsed"

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <SidebarMenuButton
          size="lg"
          className="gap-0 py-0 hover:bg-transparent active:bg-transparent cursor-default"
          asChild
        >
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-3 flex-1 text-start overflow-hidden">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-xs">
                <Leaf className="h-5 w-5" />
              </div>
              {!isCollapsed && (
                <div className="flex flex-col leading-tight animate-in fade-in duration-200">
                  <span className="font-bold tracking-tight text-sm text-foreground whitespace-nowrap">
                    {sidebarData.teams[0]?.name || "Aeration App"}
                  </span>
                  <span className="text-[10px] text-muted-foreground truncate">
                    {sidebarData.teams[0]?.plan || "Management System"}
                  </span>
                </div>
              )}
            </div>
            {!isCollapsed && <ToggleSidebar className="ml-2" />}
          </div>
        </SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  )
}

function ToggleSidebar({
  className,
  onClick,
  ...props
}: ComponentProps<typeof Button>) {
  const { toggleSidebar } = useSidebar()

  return (
    <Button
      data-sidebar="trigger"
      data-slot="sidebar-trigger"
      variant="ghost"
      size="icon"
      className={cn("aspect-square size-8 shrink-0 cursor-pointer", className)}
      onClick={(event) => {
        onClick?.(event)
        toggleSidebar()
      }}
      {...props}
    >
      <X className="h-4 w-4 md:hidden" />
      <Menu className="h-4 w-4 max-md:hidden" />
      <span className="sr-only">Toggle Sidebar</span>
    </Button>
  )
}
