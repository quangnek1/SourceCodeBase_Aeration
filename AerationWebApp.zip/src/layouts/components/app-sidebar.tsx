import { sidebarData } from "../data/sidebar-data"
import { AppTitle } from "./app-title"
import { NavGroup } from "./nav-group"
import { NavUser } from "./nav-user"

import {
    Sidebar as ShadcnSidebar,
    SidebarContent,
    SidebarFooter,
    SidebarHeader,
    SidebarRail,
} from "@/components/ui/sidebar"

export function AppSidebar() {
    return (
        <ShadcnSidebar collapsible="icon">
            <SidebarHeader>
                <AppTitle />
            </SidebarHeader>

            <SidebarContent>
                {sidebarData.navGroups.map((group, index) => (
                    <NavGroup
                        key={index}
                        {...group}
                    />
                ))}
            </SidebarContent>

            <SidebarFooter>
                <NavUser user={sidebarData.user} />
            </SidebarFooter>

            <SidebarRail />
        </ShadcnSidebar>
    )
}