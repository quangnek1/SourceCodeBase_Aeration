import { ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarMenuBadge,
  useSidebar,
} from "@/components/ui/sidebar"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import type {
  NavGroup as NavGroupType,
  NavLink as NavLinkItem,
  NavCollapsible
} from "@/layouts/data/sidebar-data"

import { Link, useLocation } from "react-router-dom"

interface NavGroupProps extends NavGroupType { }

export function NavGroup({ title, items }: NavGroupProps) {
  const { state, isMobile } = useSidebar()
  const isCollapsed = state === "collapsed"

  return (
    <SidebarGroup>
      {!isCollapsed && <SidebarGroupLabel>{title}</SidebarGroupLabel>}
      <SidebarMenu>
        {items.map((item, index) => {
          const key = `${item.title}-${index}`

          if (!item.items) {
            const linkItem = item as NavLinkItem
            return (
              <SidebarMenuLink
                key={key}
                item={linkItem}
              />
            )
          }

          if (isCollapsed && !isMobile) {
            const collapsibleItem = item as NavCollapsible
            return (
              <SidebarMenuCollapsedDropdown
                key={key}
                item={collapsibleItem}
              />
            )
          }

          const collapsibleItem = item as NavCollapsible
          return (
            <SidebarMenuCollapsible
              key={key}
              item={collapsibleItem}
            />
          )
        })}
      </SidebarMenu>
    </SidebarGroup>
  )
}

// 1. Sidebar Menu Link Component (Simple items)
interface LinkItemProps {
  item: NavLinkItem
}

function SidebarMenuLink({ item }: LinkItemProps) {
  const { setOpenMobile } = useSidebar()
  const location = useLocation()
  const targetUrl = item.url.startsWith('/') ? item.url : `/${item.url}`
  const isActive = location.pathname === targetUrl
  const Icon = item.icon

  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        isActive={isActive}
        tooltip={item.title}
        className="cursor-pointer"
        asChild
      >
        <Link to={item.url} onClick={() => setOpenMobile(false)}>
          {Icon && <Icon />}
          <span>{item.title}</span>
          {item.badge && <SidebarMenuBadge>{item.badge}</SidebarMenuBadge>}
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  )
}

// 2. Sidebar Menu Collapsible Component (Sub-menus for expanded sidebar)
interface CollapsibleItemProps {
  item: NavCollapsible
}

function SidebarMenuCollapsible({ item }: CollapsibleItemProps) {
  const { setOpenMobile } = useSidebar()
  const location = useLocation()
  const isChildActive = item.items.some((sub) => {
    const targetUrl = sub.url.startsWith('/') ? sub.url : `/${sub.url}`
    return location.pathname === targetUrl || location.pathname.startsWith(`${targetUrl}/`)
  })
  const Icon = item.icon

  return (
    <Collapsible asChild defaultOpen={isChildActive} className="group/collapsible">
      <SidebarMenuItem>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton tooltip={item.title} className="cursor-pointer">
            {Icon && <Icon />}
            <span>{item.title}</span>
            {item.badge && <SidebarMenuBadge>{item.badge}</SidebarMenuBadge>}
            <ChevronRight className="ms-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
          </SidebarMenuButton>
        </CollapsibleTrigger>
        <CollapsibleContent className="CollapsibleContent">
          <SidebarMenuSub>
            {item.items.map((sub, idx) => {
              const targetUrl = sub.url.startsWith('/') ? sub.url : `/${sub.url}`
              const isSubActive = location.pathname === targetUrl
              const SubIcon = sub.icon
              return (
                <SidebarMenuSubItem key={idx}>
                  <SidebarMenuSubButton
                    isActive={isSubActive}
                    className="cursor-pointer"
                    asChild
                  >
                    <Link to={sub.url} onClick={() => setOpenMobile(false)}>
                      {SubIcon && <SubIcon />}
                      <span>{sub.title}</span>
                      {sub.badge && <SidebarMenuBadge>{sub.badge}</SidebarMenuBadge>}
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
              )
            })}
          </SidebarMenuSub>
        </CollapsibleContent>
      </SidebarMenuItem>
    </Collapsible>
  )
}

// 3. Sidebar Menu Collapsed Dropdown Component (Sub-menus for collapsed sidebar)
interface CollapsedDropdownProps {
  item: NavCollapsible
}

function SidebarMenuCollapsedDropdown({ item }: CollapsedDropdownProps) {
  const { setOpenMobile } = useSidebar()
  const location = useLocation()
  const isChildActive = item.items.some((sub) => {
    const targetUrl = sub.url.startsWith('/') ? sub.url : `/${sub.url}`
    return location.pathname === targetUrl || location.pathname.startsWith(`${targetUrl}/`)
  })
  const Icon = item.icon

  return (
    <SidebarMenuItem>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <SidebarMenuButton
            tooltip={item.title}
            isActive={isChildActive}
            className="cursor-pointer"
          >
            {Icon && <Icon />}
            <span>{item.title}</span>
            {item.badge && <SidebarMenuBadge>{item.badge}</SidebarMenuBadge>}
            <ChevronRight className="ms-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
          </SidebarMenuButton>
        </DropdownMenuTrigger>
        <DropdownMenuContent side="right" align="start" sideOffset={4} className="min-w-48">
          <DropdownMenuLabel>
            {item.title} {item.badge ? `(${item.badge})` : ""}
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          {item.items.map((sub, idx) => {
            const targetUrl = sub.url.startsWith('/') ? sub.url : `/${sub.url}`
            const isSubActive = location.pathname === targetUrl
            const SubIcon = sub.icon
            return (
              <DropdownMenuItem
                key={idx}
                asChild
              >
                <Link
                  to={sub.url}
                  onClick={() => setOpenMobile(false)}
                  className={cn("cursor-pointer", isSubActive ? "bg-accent text-accent-foreground font-medium" : "")}
                >
                  {SubIcon && <SubIcon className="mr-2 h-4 w-4 shrink-0" />}
                  <span className="max-w-52 text-wrap">{sub.title}</span>
                  {sub.badge && <span className="ms-auto text-[10px] rounded-full bg-primary/10 px-1.5 py-0.5 font-semibold text-primary">{sub.badge}</span>}
                </Link>
              </DropdownMenuItem>
            )
          }
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </SidebarMenuItem>
  )
}
