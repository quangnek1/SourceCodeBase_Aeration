import { useState, useRef, useEffect } from "react"
import {
  RiSunLine,
  RiMoonLine,
  RiArrowDownSLine,
  RiLogoutBoxRLine,
  RiUserLine,
  RiSettings2Line,
} from "@remixicon/react"
import { useTheme } from "@/components/theme-provider"
import { useLocation } from "react-router-dom"
import { useServerStatus } from "@/hooks/use-server-status"
import { sidebarData } from "@/layouts/data/sidebar-data"

import { SidebarTrigger } from "@/components/ui/sidebar"

export function Header() {
  const { theme, setTheme } = useTheme()
  const { status: serverStatus } = useServerStatus()
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  const location = useLocation()

  // Find current title from sidebarData
  let currentTitle = "Aeration System"
  for (const group of sidebarData.navGroups) {
    for (const item of group.items) {
      if (item.url && (item.url === location.pathname || `/${item.url}` === location.pathname)) {
        currentTitle = item.title
      }
      if (item.items) {
        for (const sub of item.items) {
          if (sub.url && (sub.url === location.pathname || `/${sub.url}` === location.pathname)) {
            currentTitle = sub.title
          }
        }
      }
    }
  }

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-border bg-background/95 px-4 backdrop-blur-md">
      {/* Left side: Toggle button (mobile/desktop) and title */}
      <div className="flex items-center gap-3">
        <SidebarTrigger className="mr-1 text-muted-foreground" />
        <h2 className="text-base font-semibold md:text-lg text-foreground transition-all duration-200 animate-in fade-in slide-in-from-left-2 duration-300">
          {currentTitle}
        </h2>
      </div>

      {/* Right side: Actions */}
      <div className="flex items-center gap-2">
        {/* Connection Status Badge */}
        {{
          checking: (
            <div className="hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-yellow-400" />
              </span>
              <span>Connecting…</span>
            </div>
          ),
          online: (
            <div className="hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500" />
              </span>
              <span>Connected</span>
            </div>
          ),
          offline: (
            <div className="hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20">
              <span className="h-1.5 w-1.5 rounded-full bg-red-500" />
              <span>Disconnect</span>
            </div>
          ),
        }[serverStatus]}

        {/* Theme Toggle Button */}
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="rounded-lg p-2 text-muted-foreground hover:bg-accent hover:text-foreground outline-hidden transition-colors"
          title="Chuyển chế độ tối/sáng (Phím tắt: D)"
        >
          {theme === "dark" ? (
            <RiSunLine className="h-5 w-5 animate-in spin-in-12 duration-300" />
          ) : (
            <RiMoonLine className="h-5 w-5 animate-in spin-in-12 duration-300" />
          )}
        </button>

        <div className="h-6 w-px bg-border mx-1" />

        {/* User Profile Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center gap-2 rounded-lg p-1 hover:bg-accent outline-hidden transition-all duration-200"
          >
            {/* User Avatar */}
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary font-medium text-sm border border-primary/20 shadow-xs">
              AD
            </div>

            <div className="hidden text-left md:block">
              <p className="text-xs font-semibold text-foreground leading-none">Admin User</p>
              <p className="text-[10px] text-muted-foreground mt-0.5 leading-none">Quản trị viên</p>
            </div>

            <RiArrowDownSLine className={`h-4 w-4 text-muted-foreground transition-transform duration-200 ${isProfileOpen ? "rotate-180" : ""}`} />
          </button>

          {/* Profile Dropdown Menu */}
          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-56 origin-top-right rounded-xl border border-border bg-popover p-1.5 text-popover-foreground shadow-lg focus:outline-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-2 py-2 border-b border-border mb-1 md:hidden">
                <p className="text-sm font-semibold text-foreground">Admin User</p>
                <p className="text-xs text-muted-foreground">Quản trị viên</p>
              </div>

              <button
                onClick={() => {
                  alert("Xem thông tin tài khoản")
                  setIsProfileOpen(false)
                }}
                className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-left hover:bg-accent hover:text-foreground transition-colors outline-hidden"
              >
                <RiUserLine className="h-4 w-4 text-muted-foreground" />
                <span>Hồ sơ cá nhân</span>
              </button>

              <button
                onClick={() => {
                  alert("Đi tới Cài đặt tài khoản")
                  setIsProfileOpen(false)
                }}
                className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-left hover:bg-accent hover:text-foreground transition-colors outline-hidden"
              >
                <RiSettings2Line className="h-4 w-4 text-muted-foreground" />
                <span>Cài đặt cá nhân</span>
              </button>

              <div className="h-px bg-border my-1" />

              <button
                onClick={() => {
                  alert("Đăng xuất hệ thống")
                  setIsProfileOpen(false)
                }}
                className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-left text-destructive hover:bg-destructive/10 transition-colors outline-hidden"
              >
                <RiLogoutBoxRLine className="h-4 w-4" />
                <span className="font-medium">Đăng xuất</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
