// Custom interface for backend API wrap responses
export interface ApiResponse<T> {
    isSuccess: boolean
    isFailure: boolean
    error: {
        code: string
        message: string
    } | null
    value: T
}

export interface PaginatedResponse<T> {
    isSuccess: boolean
    isFailure: boolean
    error: {
        code: string
        message: string
    } | null
    value: {
        items: T[]
        pageIndex: number
        pageSize: number
        totalCount: number
        totalPages: number
    }
}

// Interfaces for Typescript DTO structures
export interface ProductDto {
    id: string
    name: string
    price: number
    description: string
}

export interface BatchDto {
    qrCode: string
    qrCodeSvg?: string
    sterilizeDate: string
    batchNo: string
    aerationStatus?: number
    batchStatus?: number
    batchInAerationPositionDtos?: any[]
    batchItemDtos?: any[]
}

export interface DataPlanDto {
    poNo?: string
    tt?: string
    materialTypeC?: string
    pldOrd?: string
    material: string
    itemCode?: string
    itemName?: string
    internalLot?: string
    qty?: number
    keepAeration: number
    completeDate?: string
}

// Local mock data store to fallback if backend is offline
export const mockData = {
    products: [
        { id: "1", name: "Gạo Jasmine thơm lài", price: 18000, description: "Yêu cầu sục khí liên tục 24h để duy trì độ ẩm tối ưu." },
        { id: "2", name: "Gạo Nếp cái hoa vàng", price: 22000, description: "Hạt gạo dẻo, dễ ẩm mốc, cần theo dõi độ ẩm sát sao." },
        { id: "3", name: "Gạo ST25 xuất khẩu", price: 32000, description: "Hạt gạo dài, quy trình xử lý nhiệt độ sục khí khắt khe." },
        { id: "4", name: "Đậu xanh nguyên vỏ", price: 25000, description: "Độ ẩm lưu trữ thấp, thích hợp sục khí gián đoạn." },
        { id: "5", name: "Hạt điều sấy khô", price: 150000, description: "Hạt điều giòn, cần khử trùng kỹ trước khi đóng gói." }
    ] as ProductDto[],

    batches: [
        { qrCode: "LOT-2026-0601", sterilizeDate: "2026-06-25T00:00:00Z", batchNo: "LOT-2026-0601", aerationStatus: 1, batchStatus: 1 },
        { qrCode: "LOT-2026-0602", sterilizeDate: "2026-06-24T00:00:00Z", batchNo: "LOT-2026-0602", aerationStatus: 2, batchStatus: 2 },
        { qrCode: "LOT-2026-0603", sterilizeDate: "2026-06-25T00:00:00Z", batchNo: "LOT-2026-0603", aerationStatus: 0, batchStatus: 0 },
        { qrCode: "LOT-2026-0604", sterilizeDate: "2026-06-23T00:00:00Z", batchNo: "LOT-2026-0604", aerationStatus: 2, batchStatus: 2 },
        { qrCode: "LOT-2026-0605", sterilizeDate: "2026-06-25T00:00:00Z", batchNo: "LOT-2026-0605", aerationStatus: 1, batchStatus: 1 }
    ] as BatchDto[],

    plans: [
        { poNo: "PLAN-001", material: "Gạo Jasmine thơm lài", qty: 25, keepAeration: 24, completeDate: "2026-06-26T18:00:00Z", itemName: "Sục khí chống ẩm vụ Hè Thu" },
        { poNo: "PLAN-002", material: "Hạt điều sấy khô", qty: 8, keepAeration: 12, completeDate: "2026-06-26T12:00:00Z", itemName: "Khử trùng chống mối mọt hạt điều" },
        { poNo: "PLAN-003", material: "Gạo Nếp cái hoa vàng", qty: 18, keepAeration: 36, completeDate: "2026-06-27T08:00:00Z", itemName: "Ủ ấm sục khí nếp cái hoa vàng" }
    ] as DataPlanDto[]
}



