import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export function NotFoundPage() {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4 text-center">
            <h1 className="text-9xl font-extrabold text-muted-foreground/30 tracking-widest">
                404
            </h1>
            <div className="absolute rotate-12 bg-primary text-primary-foreground px-2 text-sm rounded shadow-md font-medium">
                Page Not Found
            </div>
            <p className="text-muted-foreground mt-4 max-w-md text-sm sm:text-base leading-relaxed">
                Sorry, the page you are looking for does not exist or has been moved to another location.
            </p>
            <Button
                onClick={() => window.history.back()}
                className="mt-6 gap-2 cursor-pointer"
                variant="outline"
            >
                <ArrowLeft className="w-4 h-4" /> Back to previous page
            </Button>
        </div>
    )
}