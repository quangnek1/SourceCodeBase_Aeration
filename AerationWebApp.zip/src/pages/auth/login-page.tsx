import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from '@/components/ui/card'
import { AuthLayout } from '@/layouts/auth-layout'
import { LoginForm } from '@/features/auth/components/login-form'

export function LoginPage() {
    return (
        <AuthLayout>
            <Card className='w-full border-none sm:border sm:border-border/50 bg-background/50 backdrop-blur-md shadow-xl'>
                <CardHeader className="space-y-1">
                    <CardTitle className='text-2xl font-bold tracking-tight text-center sm:text-left'>Sign in</CardTitle>
                    <CardDescription className="text-center sm:text-left">
                        Enter your CodeID and password below to <br />
                        log into your account
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <LoginForm />
                </CardContent>
                <CardFooter>
                    <p className='w-full px-4 text-center text-xs text-muted-foreground leading-relaxed'>
                        By clicking sign in, you agree to our{' '}
                        <a
                            href='/terms'
                            onClick={(e) => e.preventDefault()}
                            className='underline underline-offset-4 hover:text-primary'
                        >
                            Terms of Service
                        </a>{' '}
                        and{' '}
                        <a
                            href='/privacy'
                            onClick={(e) => e.preventDefault()}
                            className='underline underline-offset-4 hover:text-primary'
                        >
                            Privacy Policy
                        </a>
                        .
                    </p>
                </CardFooter>
            </Card>
        </AuthLayout>
    )
}

