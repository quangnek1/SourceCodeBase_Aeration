import { Button } from "@/components/ui/button";
import { RiArrowLeftSLine, RiArrowRightSLine } from "@remixicon/react";

interface DataTablePaginationProps {
    pageIndex: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
    onPageChange: (newPageIndex: number) => void;
}

export function DataTablePagination({
    pageIndex,
    pageSize,
    totalCount,
    totalPages,
    onPageChange,
}: DataTablePaginationProps) {
    if (totalPages <= 1) return null;

    return (
        <div className="flex items-center justify-between px-4 py-3 border-t border-border bg-muted/20">
            <div className="text-xs text-muted-foreground">
                Showing {(pageIndex - 1) * pageSize + 1} to {Math.min(pageIndex * pageSize, totalCount)} of {totalCount} results
            </div>
            <div className="flex items-center gap-2">
                <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => onPageChange(Math.max(1, pageIndex - 1))}
                    disabled={pageIndex <= 1}
                >
                    <RiArrowLeftSLine className="h-4 w-4" />
                </Button>
                <span className="text-xs font-medium">Page {pageIndex} / {totalPages}</span>
                <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => onPageChange(Math.min(totalPages, pageIndex + 1))}
                    disabled={pageIndex >= totalPages}
                >
                    <RiArrowRightSLine className="h-4 w-4" />
                </Button>
            </div>
        </div>
    );
}
