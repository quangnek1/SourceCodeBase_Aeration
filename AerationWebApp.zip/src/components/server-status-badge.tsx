import type { ServerStatus } from "@/hooks/use-server-status";

interface ServerStatusBadgeProps {
    status: ServerStatus;
    lastOnlineAt: Date | null;
}

const config: Record<
    ServerStatus,
    { dot: string; text: string; label: string; pulse: boolean }
> = {
    checking: {
        dot: "bg-yellow-400",
        text: "text-yellow-400",
        label: "Đang kiểm tra…",
        pulse: true,
    },
    online: {
        dot: "bg-emerald-400",
        text: "text-emerald-400",
        label: "Kết nối tốt",
        pulse: true,
    },
    offline: {
        dot: "bg-red-500",
        text: "text-red-400",
        label: "Mất kết nối",
        pulse: false,
    },
};

export function ServerStatusBadge({ status, lastOnlineAt }: ServerStatusBadgeProps) {
    const { dot, text, label, pulse } = config[status];

    return (
        <div className="flex items-center gap-1.5" title={
            status === "offline" && lastOnlineAt
                ? `Lần cuối online: ${lastOnlineAt.toLocaleTimeString("vi-VN")}`
                : label
        }>
            {/* Dot with optional pulse */}
            <span className="relative flex h-2.5 w-2.5">
                {pulse && (
                    <span
                        className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${dot}`}
                    />
                )}
                <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${dot}`} />
            </span>

            {/* Label */}
            <span className={`text-xs font-medium ${text}`}>{label}</span>

            {/* Last online hint when offline */}
            {status === "offline" && lastOnlineAt && (
                <span className="text-xs text-muted-foreground">
                    ({lastOnlineAt.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })})
                </span>
            )}
        </div>
    );
}
