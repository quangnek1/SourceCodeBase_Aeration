const requiredEnvVars = {
    VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
} as const;

// Kiểm tra tất cả required env vars
Object.entries(requiredEnvVars).forEach(([key, value]) => {
    if (!value) {
        throw new Error(`
      ❌ Missing required environment variable: ${key}
      👉 Check your .env file
    `);
    }
});

export const env = {
    API_BASE_URL: requiredEnvVars.VITE_API_BASE_URL,
    IS_DEV: import.meta.env.DEV,
    IS_PROD: import.meta.env.PROD,
    MODE: import.meta.env.MODE, // "development" | "production" | "staging"
} as const;