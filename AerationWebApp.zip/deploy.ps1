﻿# ============================================================
# Deploy Script - AerationWebApp
# Tu dong build va deploy len \\172.16.33.120\publish\AerationPlanClient
# ============================================================

param(
    [string]$DeployPath = "\\172.16.33.120\publish\AerationPlanClient"
)

$ErrorActionPreference = "Stop"

function Write-Step($msg) {
    Write-Host ""
    Write-Host "==> $msg" -ForegroundColor Cyan
}

function Write-Success($msg) {
    Write-Host "[OK] $msg" -ForegroundColor Green
}

function Write-Fail($msg) {
    Write-Host "[FAIL] $msg" -ForegroundColor Red
}

# ----------------------------
# 1. Build
# ----------------------------
Write-Step "Dang build AerationWebApp..."
Set-Location $PSScriptRoot

try {
    pnpm run build
    if ($LASTEXITCODE -ne 0) { throw "Build that bai voi exit code $LASTEXITCODE" }
    Write-Success "Build thanh cong"
}
catch {
    Write-Fail "Build that bai: $_"
    exit 1
}

# ----------------------------
# 2. Kiem tra network share
# ----------------------------
Write-Step "Kiem tra ket noi den $DeployPath ..."

if (-not (Test-Path $DeployPath)) {
    Write-Fail "Khong the truy cap '$DeployPath'. Kiem tra lai ket noi mang hoac quyen truy cap."
    exit 1
}
Write-Success "Ket noi OK"

# ----------------------------
# 3. Xoa file cu tren server
# ----------------------------
Write-Step "Xoa noi dung cu tai $DeployPath ..."
try {
    Get-ChildItem -Path $DeployPath -Recurse | Remove-Item -Recurse -Force
    Write-Success "Da xoa noi dung cu"
}
catch {
    Write-Fail "Xoa that bai: $_"
    exit 1
}

# ----------------------------
# 4. Copy dist len server
# ----------------------------
$distPath = Join-Path $PSScriptRoot "dist"
Write-Step "Copying '$distPath' -> '$DeployPath' ..."

try {
    Copy-Item -Path "$distPath\*" -Destination $DeployPath -Recurse -Force
    Write-Success "Copy thanh cong"
}
catch {
    Write-Fail "Copy that bai: $_"
    exit 1
}

# ----------------------------
# Ket qua
# ----------------------------
Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  DEPLOY THANH CONG!" -ForegroundColor Green
Write-Host "  $DeployPath" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
