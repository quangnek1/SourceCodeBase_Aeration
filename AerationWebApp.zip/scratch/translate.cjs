// const fs = require('fs');
// const path = require('path');

// const featuresDir = path.join('d:/12. .NET CleanCode/SourceCodeBase/MyApp/src/WebApp/AerationWebApp/src/features');

// const dictionary = {
//   // Common
//   "Lưu cấu hình": "Save Settings",
//   "Thành công": "Success",
//   "Lỗi": "Error",
//   "Không thể thao tác, vui lòng thử lại sau": "Operation failed, please try again later",
//   "Khôi phục mặc định": "Restore Defaults",
//   "Xóa": "Delete",
//   "Sửa": "Edit",
//   "Chi tiết": "Details",
//   "Hủy": "Cancel",
//   "Đóng": "Close",

//   // settings-view.tsx
//   "Cấu hình Hệ thống & Cá nhân": "System & User Settings",
//   "Quản lý thông số vận hành chung, kết nối API backend và cấu hình hiển thị cá nhân.": "Manage operational parameters, backend API connections, and personal display settings.",
//   "Cài đặt Cá nhân": "User Preferences",
//   "Ngôn ngữ hiển thị": "Display Language",
//   "Tiếng Việt": "Vietnamese",
//   "English": "English",
//   "Số lượng mục trên 1 trang": "Items per page",
//   "dòng": "rows",
//   "Giao diện (Theme)": "Theme",
//   "Hệ thống (Tự động)": "System (Auto)",
//   "Sáng (Light)": "Light",
//   "Tối (Dark)": "Dark",
//   "* Thay đổi được tự động lưu cục bộ trên trình duyệt.": "* Changes are automatically saved locally in the browser.",
//   "Kết nối API Backend": "Backend API Connection",
//   "Đường dẫn API (Cổng RESTful)": "API Endpoint (RESTful)",
//   "Địa chỉ WebSocket (Realtime telemetry)": "WebSocket Address (Realtime telemetry)",
//   "Lưu cấu hình & Kết nối": "Save & Connect",
//   "Đã lưu cấu hình API mới và kích hoạt kiểm tra kết nối realtime!": "Saved API configuration and activated realtime connection check!",
//   "Ngưỡng Cảnh báo An toàn": "Safety Warning Thresholds",
//   "Nhiệt độ tối đa (°C)": "Max Temperature (°C)",
//   "Nhiệt độ tối thiểu (°C)": "Min Temperature (°C)",
//   "Độ ẩm tối đa (%)": "Max Humidity (%)",
//   "Chu kỳ đọc cảm biến (giây)": "Sensor Reading Cycle (seconds)",

//   // batches-component.tsx / Modals
//   "Batch Management": "Batch Management",
//   "List of batches being processed in the system": "List of batches being processed in the system",
//   "Chỉnh sửa thời gian Aeration": "Adjust Aeration Time",
//   "Chỉnh sửa thời gian": "Adjust Time",
//   "Thêm thời gian": "Add Time",
//   "Xác nhận thêm": "Confirm Add",
//   "Chọn các mẻ/lot đang ở trạng thái Aeration hoặc Done để thêm thời gian.": "Select batches/lots in Aeration or Done status to add time.",
//   "Danh sách Lot": "Lot List",
//   "Chọn tất cả": "Select All",
//   "Không có Lot nào phù hợp.": "No matching lots found.",
//   "Nhập kho Aeration": "Input to Aeration",
//   "Vui lòng chọn vị trí": "Please select a position",
//   "Đưa ra khỏi phòng sục khí": "Output from Aeration",
//   "Danh sách hạng mục (Items)": "Item List",
//   "đã chọn": "selected",
//   "Không có hạng mục nào trong mẻ này.": "No items in this batch.",
//   "Biên bản": "Document",
//   "Chi tiết mẻ": "Batch Details",
//   "Thông tin chung": "General Information",
//   "Mã lô nội bộ": "Internal Lot",
//   "Tên sản phẩm": "Product Name",
//   "Số lượng": "Quantity",
//   "Trạng thái": "Status",
//   "Ngày tạo": "Created Date",
//   "Xóa mẻ": "Delete Batch",
//   "Hành động": "Actions",

//   // dashboard-view.tsx & dashboard-stats.tsx
//   "Tổng quan": "Overview",
//   "Theo dõi và quản lý toàn bộ hệ thống phòng sục khí": "Monitor and manage the entire aeration room system",
//   "Mẻ đang xử lý": "Processing Batches",
//   "Tổng số": "Total",
//   "Công suất sử dụng": "Capacity Usage",
//   "Cảnh báo": "Warnings",
//   "Mức an toàn": "Safety Level",

//   // recent-batches.tsx & aeration-summary.tsx
//   "Lô hàng đang xử lý gần đây": "Recent Processing Batches",
//   "Tình trạng phòng sục khí": "Aeration Room Status",
//   "Sức chứa": "Capacity",
//   "vị trí": "positions",
//   "Đầy": "Full",
//   "Trống hoàn toàn": "Completely Empty",
//   "Đang dùng": "In Use",
//   "Chưa có dữ liệu phòng sục khí": "No aeration room data available",
//   "Mở Sơ đồ trực quan": "Open Visual Map",

//   // plans.tsx & plans-view.tsx
//   "Kế hoạch sản xuất": "Production Plans",
//   "Quản lý danh sách kế hoạch từ hệ thống ERP": "Manage plan list from ERP system",
//   "Đồng bộ": "Sync",
//   "Từ chối": "Reject",
//   "Chấp nhận": "Accept",
//   "Tìm kiếm...": "Search...",

//   // products-view.tsx
//   "Danh mục Sản phẩm": "Products Catalog",
//   "Định nghĩa cấu hình vật lý, giới hạn độ ẩm và công thức sục khí cho từng nông sản.": "Define physical configuration, humidity limits, and aeration formulas for each product.",
//   "Thêm sản phẩm": "Add Product",
//   "Chưa có thông tin mô tả kỹ thuật.": "No technical description available.",
//   "Tỷ trọng hạt": "Grain Density",
//   "Cấu hình sục": "Aeration Config",

//   // auth
//   "Đăng nhập": "Login",
//   "Mật khẩu": "Password",
//   "Vui lòng đăng nhập để tiếp tục": "Please login to continue",

//   // Toasts
//   "Đã đưa mẻ ra khỏi phòng sục khí thành công": "Successfully output batch from aeration room",
//   "Lỗi khi xuất mẻ khỏi phòng sục khí": "Error outputting batch from aeration room",
//   "Điều chỉnh thời gian thành công!": "Time adjusted successfully!",
//   "Có lỗi xảy ra khi điều chỉnh thời gian.": "An error occurred while adjusting time.",
//   "Vui lòng chọn ít nhất một lot.": "Please select at least one lot.",

//   // Plan Types Translations
//   '"Khởi tạo": "Khởi tạo",': '"Khởi tạo": "Initial",',
//   '"Đã tạo": "Đã tạo",': '"Đã tạo": "Created",',
//   '"Đã tái tạo": "Đã tái tạo",': '"Đã tái tạo": "ReCreated",',
//   '"Đang sục khí": "Đang sục khí",': '"Đang sục khí": "Aeration",',
//   '"Sục khí hoàn thành": "Sục khí hoàn thành",': '"Sục khí hoàn thành": "AerationDone",',
//   '"Đang đóng hộp": "Đang đóng hộp",': '"Đang đóng hộp": "Boxing",',
//   '"Đóng hộp hoàn thành": "Đóng hộp hoàn thành",': '"Đóng hộp hoàn thành": "BoxingDone",',
//   '"Đang đóng gói": "Đang đóng gói",': '"Đang đóng gói": "Packing",',
//   '"Đóng gói hoàn thành": "Đóng gói hoàn thành",': '"Đóng gói hoàn thành": "PackingDone",',
//   '"Hoàn thành": "Hoàn thành",': '"Hoàn thành": "Done",',

//   '"Khởi tạo"': '"Initial"',
//   '"Đã tạo"': '"Created"',
//   '"Đã tái tạo"': '"ReCreated"',
//   '"Đang sục khí"': '"Aeration"',
//   '"Sục khí hoàn thành"': '"AerationDone"',
//   '"Đang đóng hộp"': '"Boxing"',
//   '"Đóng hộp hoàn thành"': '"BoxingDone"',
//   '"Đang đóng gói"': '"Packing"',
//   '"Đóng gói hoàn thành"': '"PackingDone"',
//   '"Hoàn thành"': '"Done"',
  
//   // Modals specific
//   "Vui lòng xác nhận thông tin và chọn các hạng mục cần đưa ra khỏi phòng sục khí cho mẻ": "Please confirm the information and select the items to output from the aeration room for batch",
//   "Ngày giờ xuất": "Output Date & Time",
//   "Chọn vị trí sục khí": "Select Aeration Position",
//   "Xác nhận nhập kho": "Confirm Input",
//   "Bạn chưa chọn vị trí nào!": "You haven't selected any position!",
//   "Đã nhập kho thành công!": "Input successful!",
  
//   "Đang tải...": "Loading...",
//   "Lấy dữ liệu...": "Fetching data...",
  
//   "Cột": "Column",
  
//   "tiếng": "hours",
//   "1 tiếng": "1 hour",
  
//   // Dashboard additions
//   "Lô hàng": "Batches",
//   "Phòng": "Room",
// };

// // Sort keys by length descending to prevent partial replacements
// const keys = Object.keys(dictionary).sort((a, b) => b.length - a.length);

// function replaceInFile(filePath) {
//   let content = fs.readFileSync(filePath, 'utf8');
//   let originalContent = content;
//   let changed = false;

//   keys.forEach(key => {
//     // Escaping regex special characters if needed, but we can just use replaceAll or split/join
//     if (content.includes(key)) {
//       content = content.split(key).join(dictionary[key]);
//       changed = true;
//     }
//   });

//   if (changed) {
//     fs.writeFileSync(filePath, content, 'utf8');
//     console.log(`Updated: ${filePath}`);
//   }
// }

// function processDirectory(dir) {
//   const files = fs.readdirSync(dir);
//   for (const file of files) {
//     const fullPath = path.join(dir, file);
//     if (fs.statSync(fullPath).isDirectory()) {
//       processDirectory(fullPath);
//     } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
//       replaceInFile(fullPath);
//     }
//   }
// }

// processDirectory(featuresDir);
// console.log("Translation complete.");
